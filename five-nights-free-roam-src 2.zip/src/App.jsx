/* eslint-disable tailwindcss/no-custom-classname */
import { useEffect, useRef, useState, useCallback } from "react";
import { ROOMS, CAMS, CAM_NAMES } from "./game/map.js";

const FONTS = "https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Display:wght@700;900&family=Big+Shoulders+Text:wght@500;700;800&family=VT323&display=swap";
const SWATCH = {
  shirt: [0x8e3fbf, 0x3f5fbf, 0x2f7a4a, 0xa8322c, 0x2a2a30, 0xc9a13a],
  pants: [0x2f5bc0, 0x1e2433, 0x4a3a2a, 0x5a5a60, 0x23303f],
  skin: [0xf2d2b6, 0xe8c4a0, 0xc99a74, 0xa0714f, 0x7a5236, 0x523622],
  hair: [0xc9a050, 0x2a1d14, 0x6b3f1e, 0xa8401e, 0x1a1a1c, 0xd8d0c0],
};
const hex = (n) => "#" + n.toString(16).padStart(6, "0");
const KNAMES = { freddy: "Freddy", bonnie: "Bonnie", chica: "Chica", foxy: "Foxy" };
const fmtHour = (h) => (h === 0 ? "12" : String(h));

const CSS = `
:root{
  --ink: oklch(92% 0.02 85); --ink-2: oklch(74% 0.02 80); --ink-3: oklch(52% 0.015 70);
  --bg: oklch(13% 0.008 40); --bg-2: oklch(18% 0.01 40); --line: oklch(30% 0.012 50);
  --amber: oklch(80% 0.15 78); --amber-d: oklch(58% 0.12 70); --red: oklch(62% 0.21 27); --red-d: oklch(40% 0.14 27); --green: oklch(78% 0.14 150);
  --ease: cubic-bezier(0.22,1,0.36,1);
}
*{box-sizing:border-box} html,body,#root{margin:0;height:100%;background:var(--bg);overflow:hidden}
.app{position:fixed;inset:0;color:var(--ink);font-family:"Big Shoulders Text",system-ui,sans-serif;letter-spacing:.01em;user-select:none}
.stage{position:absolute;inset:0}
.px{font-family:"VT323",ui-monospace,monospace;letter-spacing:.02em}
.stencil{font-family:"Big Shoulders Stencil Display",Impact,sans-serif}
button{font:inherit;color:inherit;background:none;border:0;cursor:pointer}
button:focus-visible{outline:2px solid var(--amber);outline-offset:3px}

/* menu */
.menu{position:absolute;inset:0;display:grid;grid-template-columns:minmax(360px,520px) 1fr;background:linear-gradient(90deg,oklch(10% 0.008 40 / .96) 0%,oklch(10% 0.008 40 / .82) 32%,transparent 62%)}
.menu-col{padding:40px 48px 28px 56px;display:flex;flex-direction:column;gap:0;min-height:0;overflow:auto}
.eyebrow{font-size:.8rem;letter-spacing:.22em;text-transform:uppercase;color:var(--amber);font-weight:800}
.title{font-size:clamp(3rem,min(6vw,9vh),5.4rem);line-height:.86;margin:14px 0 0;font-weight:900;color:var(--ink);text-wrap:balance}
.title span{display:block;color:var(--amber)}
.sub{margin:18px 0 0;color:var(--ink-2);font-size:1.05rem;line-height:1.5;max-width:36ch;font-weight:500}
.modes{margin-top:20px;display:flex;flex-direction:column;border-top:1px solid var(--line)}
.mode{display:grid;grid-template-columns:40px 1fr auto;align-items:baseline;gap:0 12px;padding:9px 4px;border-bottom:1px solid var(--line);text-align:left;transition:background .2s var(--ease),padding .25s var(--ease)}
.mode .n{font-family:"VT323",monospace;font-size:1.35rem;color:var(--ink-3)}
.mode .t{font-size:1.5rem;font-weight:800;letter-spacing:.02em;text-transform:uppercase}
.mode .d{grid-column:2/4;color:var(--ink-2);font-size:.92rem;font-weight:500;margin-top:2px}
.mode .go{font-family:"VT323",monospace;color:var(--ink-3);font-size:1.2rem;transition:transform .25s var(--ease),color .2s}
.mode:hover,.mode:focus-visible{background:oklch(20% 0.02 70 / .55);padding-left:14px}
.mode:hover .t{color:var(--amber)} .mode:hover .go{color:var(--amber);transform:translateX(4px)}
.mode:active{background:oklch(24% 0.03 70 / .6)}
.row{display:flex;gap:28px;align-items:center;margin-top:10px;flex-wrap:wrap}
.lbl{font-size:.74rem;letter-spacing:.2em;text-transform:uppercase;color:var(--ink-3);font-weight:800}
.seg{display:flex;gap:4px;margin-top:8px}
.seg button{padding:8px 12px;border:1px solid var(--line);font-weight:700;font-size:.95rem;color:var(--ink-2);transition:all .15s}
.seg button[aria-pressed=true]{background:var(--amber);color:oklch(18% 0.02 70);border-color:var(--amber)}
.seg button:hover{border-color:var(--amber-d);color:var(--ink)}
.link{min-height:40px;display:inline-flex;align-items:center;font-weight:800;text-transform:uppercase;letter-spacing:.14em;font-size:.82rem;color:var(--ink-2);border-bottom:1px solid var(--line);padding:4px 0}
@media (max-height:780px){.foot{display:none}}
.link:hover{color:var(--amber);border-color:var(--amber)}
.foot{margin-top:auto;padding-bottom:8px;padding-top:18px;color:var(--ink-3);font-size:.85rem;font-weight:500;line-height:1.5;max-width:44ch}
.custom{margin-top:26px;display:grid;gap:14px}
.sw{display:flex;gap:6px;margin-top:6px}
.sw button{width:30px;height:30px;border-radius:50%;border:2px solid transparent;box-shadow:inset 0 0 0 1px oklch(0% 0 0 / .4);transition:transform .15s var(--ease)}
.sw button[aria-pressed=true]{border-color:var(--ink);transform:scale(1.1)}
.sw button:hover{transform:scale(1.12)}
.controls{margin-top:26px;display:grid;grid-template-columns:auto 1fr;gap:6px 18px;font-size:.95rem;color:var(--ink-2);font-weight:500}
.controls h4{grid-column:1/3;margin:12px 0 2px;font-size:.74rem;letter-spacing:.2em;text-transform:uppercase;color:var(--amber);font-weight:800}
kbd{font-family:"VT323",monospace;font-size:1.05rem;color:var(--ink);background:var(--bg-2);border:1px solid var(--line);border-bottom-width:2px;padding:0 6px;border-radius:3px;white-space:nowrap}
.loading{position:absolute;inset:0;display:grid;place-items:center;background:var(--bg);z-index:30}
.loading .px{font-size:1.6rem;color:var(--amber)}
.blink{animation:blink 1s steps(2) infinite}@keyframes blink{50%{opacity:0}}

/* hud */
.vp{position:absolute;top:0;bottom:0;overflow:hidden;pointer-events:none}
.vp.split-l{box-shadow:inset -1px 0 0 oklch(0% 0 0)}
.clock{position:absolute;top:22px;right:28px;text-align:right}
.clock .h{font-family:"VT323",monospace;font-size:3.4rem;line-height:.8;color:var(--ink)}
.clock .h small{font-size:1.8rem;margin-left:6px;color:var(--ink-2)}
.clock .n{font-size:.78rem;letter-spacing:.22em;text-transform:uppercase;color:var(--ink-3);font-weight:800;margin-top:8px}
.room{position:absolute;top:26px;left:28px;font-size:.76rem;letter-spacing:.22em;text-transform:uppercase;font-weight:800;color:var(--ink-3)}
.power{position:absolute;left:28px;bottom:26px}
.power .v{font-family:"VT323",monospace;font-size:2.6rem;line-height:.9}
.power .v.low{color:var(--red)}
.bars{display:flex;gap:3px;margin-top:6px}
.bars i{width:12px;height:18px;background:oklch(30% 0.01 60)}
.bars i.on{background:var(--green)} .bars i.on.w{background:var(--amber)} .bars i.on.r{background:var(--red)}
.meters{position:absolute;right:28px;bottom:26px;display:grid;gap:10px;width:170px}
.meter .top{display:flex;justify-content:space-between;font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;font-weight:800;color:var(--ink-3)}
.meter .top b{font-family:"VT323",monospace;font-size:1.15rem;letter-spacing:.02em;color:var(--ink-2);font-weight:400}
.track{height:5px;background:oklch(26% 0.01 60);margin-top:4px;overflow:hidden}
.track div{height:100%;background:var(--ink-2);transform-origin:left;transition:transform .12s linear}
.track.amber div{background:var(--amber)} .track.red div{background:var(--red)}
.cross{position:absolute;left:50%;top:50%;width:4px;height:4px;margin:-2px 0 0 -2px;border-radius:50%;background:oklch(92% 0.02 85 / .6)}
.prompt{position:absolute;left:50%;top:calc(50% + 34px);transform:translateX(-50%);font-weight:800;font-size:1.05rem;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap;text-shadow:0 1px 8px oklch(0% 0 0)}
.hold{position:absolute;left:50%;top:50%;width:54px;height:54px;margin:-27px 0 0 -27px}
.feed{position:absolute;top:24px;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:6px}
.feed div{font-weight:800;font-size:1.05rem;letter-spacing:.08em;text-transform:uppercase;padding:4px 12px;background:oklch(10% 0.01 40 / .7);animation:in .4s var(--ease)}
@keyframes in{from{opacity:0;transform:translateY(-6px)}}
.doors{position:absolute;left:50%;bottom:26px;transform:translateX(-50%);display:flex;gap:18px;font-size:.74rem;letter-spacing:.2em;text-transform:uppercase;font-weight:800;color:var(--ink-3)}
.doors span{display:flex;align-items:center;gap:6px} .doors i{width:10px;height:10px;background:oklch(30% 0.01 60)} .doors i.on{background:var(--red)}
.intro{position:absolute;inset:0;display:grid;place-items:center;background:oklch(6% 0.005 40);text-align:center;transition:opacity .6s var(--ease)}
.intro .t{font-family:"VT323",monospace;font-size:clamp(3rem,7vw,5.5rem);line-height:.9}
.intro .s{font-size:.9rem;letter-spacing:.3em;text-transform:uppercase;color:var(--ink-2);font-weight:800;margin-top:10px}
.intro .g{margin-top:26px;color:var(--ink-3);font-weight:500;font-size:1rem}
.camui{position:absolute;inset:0}
.camui .name{position:absolute;top:24px;left:28px;font-family:"VT323",monospace;font-size:2rem;line-height:1}
.camui .name small{display:block;font-size:1.2rem;color:var(--ink-2)}
.rec{position:absolute;top:30px;left:50%;transform:translateX(-50%);font-family:"VT323",monospace;font-size:1.4rem;color:var(--red);display:flex;gap:8px;align-items:center}
.rec i{width:10px;height:10px;border-radius:50%;background:var(--red)}
.map{position:absolute;right:24px;bottom:24px;width:min(34%,300px);pointer-events:auto;background:oklch(8% 0.01 150 / .72);padding:10px;border:1px solid oklch(40% 0.03 150 / .6)}
.map svg{display:block;width:100%;height:auto}
.map .camhint{font-family:"VT323",monospace;color:var(--ink-2);font-size:1rem;margin-top:6px;display:flex;justify-content:space-between}
.pause{position:absolute;inset:0;display:grid;place-items:center;background:oklch(8% 0.006 40 / .72);pointer-events:auto;cursor:pointer}
.pause .t{font-size:2rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase}
.pause .s{color:var(--ink-2);margin-top:8px;font-weight:500}
/* anim hud */
.roster{position:absolute;top:22px;left:24px;display:flex;flex-direction:column;gap:2px}
.roster .r{display:flex;align-items:baseline;gap:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-3);font-size:.95rem}
.roster .r .k{font-family:"VT323",monospace;font-size:1.1rem;width:18px}
.roster .r.on{color:var(--red);font-size:1.5rem}
.roster .r .st{font-weight:600;letter-spacing:.02em;text-transform:none;font-size:.85rem;color:var(--ink-3)}
.ability{position:absolute;left:50%;bottom:26px;transform:translateX(-50%);text-align:center;width:260px}
.ability .n{font-size:1.4rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
.ability .d{font-size:.9rem;color:var(--ink-2);font-weight:500;margin-top:2px}
.ability .track{margin-top:8px}
.status{position:absolute;left:50%;top:calc(50% + 60px);transform:translateX(-50%);font-weight:900;letter-spacing:.18em;text-transform:uppercase;font-size:1.1rem}
.compass{position:absolute;left:50%;top:50%;width:220px;height:220px;margin:-110px 0 0 -110px}
.watched{position:absolute;top:26px;right:28px;margin-top:90px;font-weight:900;letter-spacing:.16em;text-transform:uppercase;color:var(--red);font-size:.95rem}
.end{position:absolute;inset:0;display:grid;place-items:center;background:oklch(6% 0.006 30 / .88);pointer-events:auto;text-align:center}
.end .big{font-family:"VT323",monospace;font-size:clamp(4rem,11vw,9rem);line-height:.85}
.end .who{font-size:.9rem;letter-spacing:.3em;text-transform:uppercase;font-weight:800;color:var(--ink-2);margin-top:10px}
.end .stats{margin-top:22px;color:var(--ink-3);font-weight:500}
.end .btns{display:flex;gap:12px;justify-content:center;margin-top:30px}
.btn{padding:12px 22px;border:1px solid var(--line);font-weight:800;letter-spacing:.14em;text-transform:uppercase;font-size:.9rem;transition:all .15s}
.btn.pri{background:var(--amber);color:oklch(16% 0.02 70);border-color:var(--amber)}
.btn:hover{border-color:var(--amber)} .btn.pri:hover{background:oklch(86% 0.14 80)}
.hint{position:absolute;left:28px;bottom:96px;color:var(--ink-3);font-size:.85rem;font-weight:500;line-height:1.5}
@media (max-width: 820px){ .menu{grid-template-columns:1fr;background:oklch(10% 0.008 40 / .9)} .menu-col{padding:32px 24px} }
`;

function Meter({ label, value, text, tone }) {
  return (<div className="meter"><div className="top">{label}<b>{text}</b></div><div className={"track " + (tone || "")}><div style={{ transform: `scaleX(${Math.max(0, Math.min(1, value))})` }} /></div></div>);
}

function CamMap({ cam, onPick, watched }) {
  return (
    <svg viewBox="-0.5 -0.5 43 51">
      {ROOMS.map((r) => (<rect key={r.id} x={r.r[0]} y={r.r[1]} width={r.r[2] - r.r[0]} height={r.r[3] - r.r[1]} fill={r.id === "office" ? "oklch(40% 0.08 80)" : "oklch(24% 0.03 150)"} stroke="oklch(62% 0.06 150)" strokeWidth="0.25" />))}
      <text x={20} y={47.2} fontSize="1.5" fill="oklch(92% 0.02 85)" textAnchor="middle" fontFamily="VT323">YOU</text>
      {Object.entries(CAMS).map(([id, c]) => {
        const n = Number(id), on = n === cam;
        return (<g key={id} onClick={() => onPick(n)} style={{ cursor: "pointer" }}>
          <rect x={c[0] - 1.6} y={c[1] - 1.1} width={3.2} height={2.2} fill={on ? "oklch(80% 0.15 78)" : "oklch(16% 0.02 150)"} stroke="oklch(80% 0.05 150)" strokeWidth="0.2" />
          <text x={c[0]} y={c[1] + 0.65} fontSize="1.8" textAnchor="middle" fill={on ? "oklch(16% 0.02 70)" : "oklch(90% 0.03 150)"} fontFamily="VT323">{String(n).padStart(2, "0")}</text>
        </g>);
      })}
    </svg>
  );
}

function Compass({ pings, reveal }) {
  const R = 100;
  return (
    <svg className="compass" viewBox="-110 -110 220 220">
      <circle r={R} fill="none" stroke="oklch(92% 0.02 85 / .12)" strokeWidth="1" />
      {pings.map((p, i) => { const a = -p.ang; const x = Math.sin(a) * R, y = -Math.cos(a) * R; const op = Math.max(0, 1 - p.age / 2.5); const s = p.kind === "breaker" ? 9 : 6;
        return <g key={i} transform={`translate(${x},${y}) rotate(${(a * 180) / Math.PI})`} opacity={op}><path d={`M0,${-s} L${s * 0.8},${s * 0.6} L${-s * 0.8},${s * 0.6}Z`} fill={p.kind === "breaker" ? "oklch(80% 0.15 78)" : "oklch(92% 0.02 85)"} /></g>; })}
      {reveal && (() => { const a = -reveal.ang; const x = Math.sin(a) * (R - 14), y = -Math.cos(a) * (R - 14); return <g transform={`translate(${x},${y})`}><circle r="8" fill="none" stroke="oklch(62% 0.21 27)" strokeWidth="2.5" /><text y="24" textAnchor="middle" fontFamily="VT323" fontSize="16" fill="oklch(62% 0.21 27)">{Math.round(reveal.dist)}m</text></g>; })()}
    </svg>
  );
}

function GuardHUD({ h, split, onPick }) {
  const g = h.guard; const pw = Math.max(0, g.power);
  const hourFrac = (h.clock % (h.nightLen / 6)) / (h.nightLen / 6);
  const mine = h.messages.filter((m) => m.who !== "anim").slice(-3);
  return (<>
    {g.onCams ? (
      <div className="camui">
        <div className="name">CAM {String(g.cam).padStart(2, "0")}<small>{g.camName}</small></div>
        <div className="rec"><i className="blink" />REC</div>
        <div className="map"><CamMap cam={g.cam} onPick={onPick} /><div className="camhint"><span>A / D  cycle</span><span>E  close</span></div></div>
      </div>
    ) : (<>
      <div className="cross" />
      {g.prompt && <div className="prompt">{g.prompt}</div>}
      {g.hold > 0 && (<svg className="hold" viewBox="0 0 54 54"><circle cx="27" cy="27" r="22" fill="none" stroke="oklch(92% 0.02 85 / .2)" strokeWidth="4" /><circle cx="27" cy="27" r="22" fill="none" stroke="oklch(80% 0.15 78)" strokeWidth="4" strokeDasharray={`${g.hold * 138} 200`} transform="rotate(-90 27 27)" /></svg>)}
      <div className="room">{g.room}</div>
      {g.inOffice && <div className="doors"><span><i className={g.doors.L ? "on" : ""} />Left door</span><span><i className={g.doors.R ? "on" : ""} />Right door</span></div>}
    </>)}
    <div className="clock"><div className="h">{fmtHour(h.hour)}<small>AM</small></div><div className="n">Night {h.night}</div></div>
    <div className="power">
      <div className="lbl">{g.powerOut ? "Power out" : "Office power"}</div>
      <div className={"v px " + (pw < 20 ? "low" : "")}>{Math.ceil(pw)}%</div>
      <div className="bars">{[0, 1, 2, 3, 4].map((i) => <i key={i} className={i < g.usage ? "on " + (i >= 3 ? "r" : i >= 2 ? "w" : "") : ""} />)}</div>
    </div>
    {!g.onCams && <div className="meters">
      <Meter label="Flashlight" value={g.battery / 100} text={g.blackout > 0 ? "DEAD" : Math.ceil(g.battery) + "%"} tone={g.battery < 20 || g.blackout > 0 ? "red" : "amber"} />
      <Meter label="Stamina" value={g.stamina} text={g.exhausted ? "WINDED" : ""} tone={g.exhausted ? "red" : ""} />
    </div>}
    <div className="feed">{mine.map((m, i) => <div key={m.t + i}>{m.t}</div>)}</div>
  </>);
}

function AnimHUD({ h }) {
  const a = h.anim; const mine = h.messages.filter((m) => m.who !== "guard").slice(-3);
  const ready = a.abilityCd <= 0;
  return (<>
    <div className="cross" />
    <Compass pings={a.pings} reveal={a.reveal} />
    <div className="roster">
      {a.list.map((x, i) => (<div key={x.k} className={"r " + (x.k === a.active ? "on" : "")}><span className="k">{i + 1}</span>{x.name}<span className="st">{x.stun ? "stunned" : x.room}</span></div>))}
      <div className="lbl" style={{ marginTop: 10 }}>{a.switchCd > 0 ? `Switch in ${Math.ceil(a.switchCd)}s` : "Switch ready"}</div>
    </div>
    <div className="clock"><div className="h">{fmtHour(h.hour)}<small>AM</small></div><div className="n">Hunt ends at 6</div></div>
    {a.watched && <div className="watched">On camera</div>}
    {(a.stun > 0 || a.lit) && <div className="status" style={{ color: "var(--red)" }}>{a.stun > 0 ? "Stunned" : "In the light"}</div>}
    {a.dash && <div className="status" style={{ color: "var(--amber)" }}>Dashing</div>}
    <div className="ability">
      <div className="n" style={{ color: ready ? "var(--ink)" : "var(--ink-3)" }}>{a.ability}</div>
      <div className="d">{a.abilityDesc}</div>
      <div className={"track " + (ready ? "amber" : "")}><div style={{ transform: `scaleX(${ready ? 1 : 1 - a.abilityCd / a.abilityMax})` }} /></div>
    </div>
    <div className="feed">{mine.map((m, i) => <div key={m.t + i}>{m.t}</div>)}</div>
  </>);
}

export default function App() {
  const stageRef = useRef(); const engRef = useRef();
  const [ready, setReady] = useState(false); const [hud, setHud] = useState(null);
  const [panel, setPanel] = useState(null); const [nightLen, setNightLen] = useState(360);
  const [colors, setColors] = useState({ shirt: 0x8e3fbf, pants: 0x2f5bc0, skin: 0xe8c4a0, hair: 0xc9a050 });
  const lastMode = useRef("soloGuard");

  useEffect(() => {
    const link = document.createElement("link"); link.rel = "stylesheet"; link.href = FONTS; document.head.appendChild(link);
    let eng; const t = setTimeout(async () => {
      const { Engine } = await import("./game/engine.js");
      eng = new Engine(stageRef.current, (h) => setHud(h)); engRef.current = eng; setReady(true);
    }, 50);
    return () => { clearTimeout(t); eng && eng.dispose(); };
  }, []);
  useEffect(() => { engRef.current?.setColors(colors); }, [colors, ready]);
  useEffect(() => { engRef.current?.setMenuView(panel === "custom" ? "guard" : "stage"); }, [panel, ready]);

  const start = (mode) => { lastMode.current = mode; setPanel(null); engRef.current.start({ mode, nightLen }); };
  const pickCam = useCallback((n) => { const e = engRef.current; if (e) { e.guard.cam = n; e.camStatic = 0.35; e.audio.staticBurst(0.25, 0.06); } }, []);
  const state = hud?.state || "menu";

  return (
    <div className="app">
      <style>{CSS}</style>
      <div className="stage" ref={stageRef} onClick={() => { const e = engRef.current; if (e && e.state === "play" && !(e.guard.onCams && e.humanRole() === "guard")) e.input.lock(); }} />
      {!ready && <div className="loading"><div className="px">POWERING UP THE FAZZERIA<span className="blink">_</span></div></div>}

      {ready && state === "menu" && (
        <div className="menu">
          <div className="menu-col">
            <div className="eyebrow">Fredbear's Fazzeria · 1984</div>
            <h1 className="title stencil">Five Nights<span>Free Roam</span></h1>
            <p className="sub">One guard. Four animatronics. The pizzeria is open all night, and nothing stays on stage.</p>
            {panel === "custom" ? (
              <div className="custom">
                {Object.entries(SWATCH).map(([k, list]) => (
                  <div key={k}><div className="lbl">{k === "shirt" ? "Uniform" : k}</div>
                    <div className="sw">{list.map((c) => <button key={c} aria-label={`${k} ${hex(c)}`} aria-pressed={colors[k] === c} style={{ background: hex(c) }} onClick={() => setColors((o) => ({ ...o, [k]: c }))} />)}</div></div>
                ))}
                <div className="row" style={{ marginTop: 8 }}><button className="link" onClick={() => setPanel(null)}>Done</button></div>
              </div>
            ) : panel === "controls" ? (
              <div className="controls">
                <h4>Guard</h4>
                <span><kbd>WASD</kbd> <kbd>Mouse</kbd></span><span>Move and look</span>
                <span><kbd>Shift</kbd></span><span>Sprint, faster than any animatronic until you're winded</span>
                <span><kbd>F</kbd> / <kbd>Click</kbd></span><span>Flashlight. Hold the beam on the hunter to stun it</span>
                <span><kbd>E</kbd></span><span>Doors, cameras, hold to reset breakers (+power)</span>
                <span><kbd>Q</kbd></span><span>Hall light, at the office door panel</span>
                <span><kbd>A</kbd> <kbd>D</kbd> <kbd>1-0</kbd></span><span>Switch cameras</span>
                <h4>Animatronic (solo)</h4>
                <span><kbd>WASD</kbd> <kbd>Mouse</kbd></span><span>Move and turn</span>
                <span><kbd>1-4</kbd> <kbd>Tab</kbd></span><span>Possess Freddy, Bonnie, Chica or Foxy</span>
                <span><kbd>Q</kbd> / <kbd>Click</kbd></span><span>Ability</span>
                <h4>Animatronic (player 2, split screen)</h4>
                <span><kbd>↑↓←→</kbd> <kbd>, .</kbd></span><span>Move, turn, strafe (or a gamepad)</span>
                <span><kbd>7 8 9 0</kbd> <kbd>R-Shift</kbd></span><span>Possess / cycle</span>
                <span><kbd>Enter</kbd></span><span>Ability</span>
                <div style={{ gridColumn: "1/3", marginTop: 14 }}><button className="link" onClick={() => setPanel(null)}>Back</button></div>
              </div>
            ) : (<>
              <div className="modes">
                {[["soloGuard", "Night guard", "Survive until 6 AM against an AI animatronic hunter."], ["soloAnim", "Animatronic", "Possess the band and catch an AI guard before sunrise."], ["split", "Two players", "Split screen. Guard on keyboard and mouse, animatronics on arrows or a gamepad."]].map(([m, t, d], i) => (
                  <button key={m} className="mode" onClick={() => start(m)}><span className="n">0{i + 1}</span><span className="t">{t}</span><span className="go">→</span><span className="d">{d}</span></button>
                ))}
              </div>
              <div className="row">
                <div><div className="lbl">Night length</div><div className="seg">{[[240, "4 min"], [360, "6 min"], [480, "8 min"]].map(([v, l]) => <button key={v} aria-pressed={nightLen === v} onClick={() => setNightLen(v)}>{l}</button>)}</div></div>
              </div>
              <div className="row"><button className="link" onClick={() => setPanel("custom")}>Customize guard</button><button className="link" onClick={() => setPanel("controls")}>Controls</button></div>
              <p className="foot">Sprinting is loud. Doors drain power. Breakers around the building restore it. Only one animatronic hunts at a time, and it can be any of them.</p>
            </>)}
          </div>
        </div>
      )}

      {ready && hud && state !== "menu" && hud.viewports.map((vp, i) => (
        <div key={i} className={"vp " + (hud.viewports.length > 1 && i === 0 ? "split-l" : "")} style={{ left: vp.x, width: vp.w }}>
          {(state === "play" || state === "intro") && (vp.role === "guard" ? <GuardHUD h={hud} split={hud.viewports.length > 1} onPick={pickCam} /> : <AnimHUD h={hud} />)}
          {state === "intro" && (
            <div className="intro" style={{ opacity: Math.min(1, hud.introT / 0.8) }}>
              <div><div className="t">12:00 AM</div><div className="s">Night {hud.night} · {vp.role === "guard" ? "Night guard" : "Animatronic"}</div>
                <div className="g">{vp.role === "guard" ? "Survive until 6. Reset breakers to keep the office powered." : "Catch the guard. Possess whoever is closest."}</div></div>
            </div>
          )}
        </div>
      ))}
      {ready && hud && state === "play" && hud.paused && (<div className="pause" onClick={() => engRef.current.input.lock()}><div style={{ textAlign: "center" }}><div className="t">Paused</div><div className="s">Click to resume · Esc releases the mouse</div></div></div>)}
      {ready && hud && state === "end" && (
        <div className="end">
          <div>
            <div className="big" style={{ color: hud.result.winner === "guard" ? "var(--amber)" : "var(--red)" }}>{hud.result.winner === "guard" ? "6 AM" : "CAUGHT"}</div>
            <div className="who">{hud.result.winner === "guard" ? "The guard survived the night" : "The animatronics win"}</div>
            <div className="stats px" style={{ fontSize: "1.3rem" }}>Reached {fmtHour(Math.min(5, hud.result.hour))} AM · Power {hud.result.power}%</div>
            <div className="btns"><button className="btn pri" onClick={() => start(lastMode.current)}>Play again</button><button className="btn" onClick={() => engRef.current.toMenu()}>Menu</button></div>
          </div>
        </div>
      )}
    </div>
  );
}
