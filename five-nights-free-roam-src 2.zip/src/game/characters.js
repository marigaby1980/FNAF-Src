import * as THREE from "three";
import { RoundedBoxGeometry } from "./RoundedBox.js";

const G = {};
const geo = (k, f) => G[k] || (G[k] = f());
const SPH = () => geo("sph", () => new THREE.SphereGeometry(1, 40, 28));
const SPHL = () => geo("sphl", () => new THREE.SphereGeometry(1, 18, 12));
const CAP = (r, l) => geo(`cap${r}_${l}`, () => new THREE.CapsuleGeometry(r, l, 8, 20));
const CYL = (rt, rb, h, s = 20) => geo(`cyl${rt}_${rb}_${h}_${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s));
const RBOX = (w, h, d, r) => geo(`rb${w}_${h}_${d}_${r}`, () => new RoundedBoxGeometry(w, h, d, 4, r));
const CONE = (r, h) => geo(`cone${r}_${h}`, () => new THREE.ConeGeometry(r, h, 16));
const CIRC = (r) => geo(`circ${r}`, () => new THREE.CircleGeometry(r, 24));
const LID = () => geo("lid", () => new THREE.SphereGeometry(1, 24, 12, 0, Math.PI * 2, 0, Math.PI * 0.42));

function M(geom, mat, parent, p = [0, 0, 0], s = null, r = null) {
  const m = new THREE.Mesh(geom, mat); m.position.set(p[0], p[1], p[2]); if (s) m.scale.set(s[0], s[1], s[2]); if (r) m.rotation.set(r[0], r[1], r[2]);
  m.castShadow = true; m.receiveShadow = true; parent.add(m); return m;
}
function Gp(parent, p = [0, 0, 0]) { const g = new THREE.Group(); g.position.set(p[0], p[1], p[2]); parent.add(g); return g; }

export const SPECS = {
  freddy: { name: "Freddy", body: 0x6b4022, belly: 0xb88c5c, muzzle: 0xc49a6a, eye: 0x3a6fe0, speed: 3.5, ability: "Showtime", abilityDesc: "Reveal the guard through walls" },
  bonnie: { name: "Bonnie", body: 0x6056a6, belly: 0xb4acc8, muzzle: 0x9a90c4, eye: 0xd8344e, speed: 3.95, ability: "Blackout", abilityDesc: "Kill nearby lights and the flashlight" },
  chica: { name: "Chica", body: 0xc9a82c, belly: 0xdcc66a, muzzle: 0xe07c22, eye: 0x6a3aa8, speed: 3.8, ability: "Sabotage", abilityDesc: "Jam a breaker, drain office power" },
  foxy: { name: "Foxy", body: 0x8c3022, belly: 0xc98a7c, muzzle: 0xb24a38, eye: 0xf0c420, speed: 3.35, ability: "Dash", abilityDesc: "Burst of speed" },
  fredbear: { name: "Fredbear", body: 0xb88a2a, belly: 0xdcc27a, muzzle: 0xd8b870, eye: 0x2d5fd0 },
};

const matCache = {};
export function charMaterials(T) {
  if (matCache.ok) return matCache;
  const furCache = {};
  const fur = (hex, rep = 2) => {
    const key = hex + "_" + rep; if (furCache[key]) return furCache[key];
    const m = T.fur.map.clone(); m.repeat.set(rep, rep); m.needsUpdate = true; const n = T.fur.normalMap.clone(); n.repeat.set(rep, rep); n.needsUpdate = true;
    const c = new THREE.Color(hex);
    return (furCache[key] = new THREE.MeshPhysicalMaterial({ color: c, map: m, normalMap: n, normalScale: new THREE.Vector2(0.9, 0.9), roughness: 0.82, sheen: 0.7, sheenRoughness: 0.5, sheenColor: c.clone().lerp(new THREE.Color(0xffffff), 0.35), envMapIntensity: 0.4 }));
  };
  matCache.fur = fur;
  matCache.endo = new THREE.MeshStandardMaterial({ ...T.metal, color: 0x4a484c, metalness: 0.7, roughness: 0.9 });
  matCache.steel = new THREE.MeshStandardMaterial({ ...T.metal, color: 0xd4d4d8, metalness: 0.55, roughness: 0.7 });
  matCache.black = new THREE.MeshPhysicalMaterial({ color: 0x0e0c0c, roughness: 0.35, clearcoat: 0.5 });
  matCache.mouth = new THREE.MeshStandardMaterial({ color: 0x140a08, roughness: 0.9 });
  matCache.sclera = new THREE.MeshPhysicalMaterial({ color: 0xeeeae2, roughness: 0.15, clearcoat: 1 });
  matCache.teeth = new THREE.MeshStandardMaterial({ color: 0xe6dfcc, roughness: 0.35 });
  matCache.pupil = new THREE.MeshBasicMaterial({ color: 0x050505 });
  matCache.glow = new THREE.MeshBasicMaterial({ color: new THREE.Color(7, 7, 6.5) });
  matCache.bib = new THREE.MeshStandardMaterial({ map: T.bib, roughness: 0.8, side: THREE.DoubleSide, alphaTest: 0.5 });
  matCache.collar = new THREE.MeshStandardMaterial({ color: 0xece6d8, roughness: 0.8 });
  matCache.logo = new THREE.MeshStandardMaterial({ map: T.logo, roughness: 0.8 });
  matCache.ok = true; return matCache;
}

function eye(parent, x, y, z, irisHex, C, lidMat, scale = 1, lidAngle = 0.35) {
  const g = Gp(parent, [x, y, z]); g.scale.setScalar(scale);
  M(SPH(), C.sclera, g, [0, 0, 0], [0.05, 0.055, 0.04]);
  const iris = M(CIRC(0.026), new THREE.MeshStandardMaterial({ color: irisHex, roughness: 0.2, emissive: irisHex, emissiveIntensity: 0.25 }), g, [0, 0, 0.0405]);
  M(CIRC(0.012), C.pupil, g, [0, 0, 0.0412]);
  const glow = M(SPHL(), C.glow, g, [0, 0, 0.042], [0.009, 0.009, 0.004]); glow.castShadow = false;
  const lid = M(LID(), lidMat, g, [0, 0, 0], [0.056, 0.06, 0.047], [-Math.PI / 2 + 0.2 + lidAngle, 0, 0]);
  g.userData = { iris, glow, lid };
  return g;
}
// teeth row following an elliptical muzzle front
function teethRow(parent, C, n, halfW, y, zc, depth, h, flip = false, cone = false) {
  for (let i = 0; i < n; i++) {
    const t = n === 1 ? 0 : i / (n - 1) * 2 - 1; const x = t * halfW; const z = zc + depth * Math.sqrt(Math.max(0, 1 - t * t * 0.85));
    if (cone) M(CONE(0.013, h), C.teeth, parent, [x, y, z], null, [flip ? Math.PI : 0, 0, 0]);
    else M(RBOX(halfW * 2 / n * 0.8, h, 0.02, 0.005), C.teeth, parent, [x, y, z], null, [0, Math.atan2(x, depth) * 0.9, 0]);
  }
}

export function buildAnimatronic(kind, T) {
  const C = charMaterials(T); const S = SPECS[kind];
  const body = C.fur(S.body), belly = C.fur(S.belly, 1.5), muzzle = C.fur(S.muzzle, 1.5);
  const root = new THREE.Group(); root.name = kind;
  const R = { root, kind, eyes: [], phase: Math.random() * 6, jitter: 0, jitterT: 0 };
  const isFoxy = kind === "foxy", isChica = kind === "chica", isBonnie = kind === "bonnie", isBear = kind === "freddy" || kind === "fredbear";
  const legMat = isFoxy ? C.fur(0x7a3a1e) : body;
  const shinMat = isChica ? C.fur(0xa8602e) : legMat;
  const hips = Gp(root, [0, 0.95, 0]); R.hips = hips;
  // pelvis
  M(SPH(), legMat, hips, [0, -0.02, 0], [isFoxy ? 0.25 : 0.29, 0.13, 0.22]);
  M(CYL(0.07, 0.09, 0.14), C.endo, hips, [0, 0.1, 0]);
  const torso = Gp(hips, [0, 0.1, 0]); R.torso = torso;
  const tw = isFoxy ? 0.29 : isChica ? 0.335 : 0.31;
  const tz = isFoxy ? 0.22 : 0.265, txs = tw / 0.24;
  // barrel torso (flat-sided capsule) with a chest plate
  M(CAP(0.24, 0.28), body, torso, [0, 0.38, 0], [txs, 1, tz / 0.24]);
  M(SPH(), body, torso, [0, 0.6, 0.02], [tw * 0.92, 0.16, tz * 0.98]);
  if (isBear || isBonnie) M(SPH(), belly, torso, [0, 0.33, 0.075], [tw * 0.78, 0.33, tz * 0.8]);
  if (isFoxy) { // torn pale chest, endo showing through
    M(SPH(), C.fur(0x4a1810, 1), torso, [0, 0.38, 0.05], [tw * 0.8, 0.38, 0.18]);
    M(SPH(), belly, torso, [0, 0.38, 0.056], [tw * 0.76, 0.36, 0.18]);
    M(RBOX(0.05, 0.2, 0.03, 0.02), C.fur(0x2a0c08, 1), torso, [0.07, 0.44, 0.225], null, [0.2, 0, -0.6]);
    M(CYL(0.012, 0.012, 0.12, 8), C.endo, torso, [0.07, 0.44, 0.235], null, [0, 0, -0.6]);
    M(RBOX(0.1, 0.05, 0.03, 0.02), C.fur(0x2a0c08, 1), torso, [-0.06, 0.2, 0.21], null, [0.3, 0, 0.3]);

  }
  if (isChica) {
    M(SPH(), belly, torso, [0, 0.28, 0.07], [tw * 0.7, 0.26, tz * 0.8]);
    const bibG = new THREE.CylinderGeometry(1, 1, 0.5, 40, 1, true, -1.2, 2.4);
    const bib = new THREE.Mesh(bibG, C.bib); bib.position.set(0, 0.46, 0.0); bib.scale.set(tw * 1.1, 1, tz * 1.22); torso.add(bib);
    M(new THREE.TorusGeometry(0.11, 0.032, 10, 28), C.collar, torso, [0, 0.72, 0], [1.1, 1, 0.8], [Math.PI / 2, 0, 0]);
  }
  // bowtie
  if (isBear || isBonnie) {
    const bt = Gp(torso, [0, 0.71, 0.2]); const btm = isBonnie ? C.fur(0xc0281e, 1) : kind === "fredbear" ? C.fur(0x5a2a78, 1) : C.black;
    M(CONE(0.06, 0.11), btm, bt, [-0.055, 0, 0], null, [0, 0, -Math.PI / 2]); M(CONE(0.06, 0.11), btm, bt, [0.055, 0, 0], null, [0, 0, Math.PI / 2]); M(SPH(), btm, bt, [0, 0, 0.01], [0.03, 0.03, 0.026]);
  }
  // neck + head
  const neck = Gp(torso, [0, 0.74, 0]); M(CYL(0.045, 0.055, 0.14), C.endo, neck, [0, 0.05, 0]);
  const head = Gp(neck, [0, 0.12, 0.01]); R.head = head;
  const headMat = body;
  const jaw = Gp(head, [0, 0.05, 0.02]); R.jaw = jaw;
  if (isBear) {
    head.scale.setScalar(1.08);
    M(SPH(), headMat, head, [0, 0.16, 0], [0.25, 0.22, 0.22]);
    M(SPH(), headMat, head, [0, 0.07, 0.04], [0.23, 0.12, 0.19]); // cheeks
    M(SPH(), muzzle, head, [0, 0.08, 0.16], [0.2, 0.095, 0.165]);
    M(SPH(), C.black, head, [0, 0.145, 0.29], [0.06, 0.04, 0.036]);
    M(SPH(), C.mouth, head, [0, 0.03, 0.13], [0.13, 0.035, 0.1]);
    teethRow(head, C, 6, 0.1, 0.025, 0.13, 0.095, 0.035);
    for (const s of [-1, 1]) { const e = Gp(head, [s * 0.2, 0.33, -0.02]); M(CYL(0.098, 0.098, 0.05, 24), headMat, e, [0, 0, 0], null, [Math.PI / 2, 0, 0]); M(CYL(0.06, 0.06, 0.052, 20), muzzle, e, [0, 0, 0.004], null, [Math.PI / 2, 0, 0]); }
    const hatMat = kind === "fredbear" ? C.fur(0x5a2a78, 1) : C.black;
    const hat = Gp(head, [0.0, 0.365, 0]); hat.rotation.z = -0.05;
    M(CYL(0.115, 0.115, 0.014, 28), hatMat, hat, [0, 0, 0]); M(CYL(0.072, 0.076, 0.15, 28), hatMat, hat, [0, 0.075, 0]);
    R.eyes.push(eye(head, -0.085, 0.205, 0.172, S.eye, C, headMat, 1.05, 0.38), eye(head, 0.085, 0.205, 0.172, S.eye, C, headMat, 1.05, 0.38));
    for (const s of [-1, 1]) M(RBOX(0.1, 0.024, 0.03, 0.01), C.black, head, [s * 0.09, 0.29, 0.175], null, [-0.5, 0, s * 0.18]);
    M(SPH(), muzzle, jaw, [0, -0.03, 0.1], [0.14, 0.05, 0.11]);
    teethRow(jaw, C, 5, 0.085, 0.0, 0.1, 0.085, 0.03);
  } else if (isBonnie) {
    M(SPH(), headMat, head, [0, 0.17, -0.01], [0.23, 0.22, 0.22]);
    M(SPH(), headMat, head, [0, 0.08, 0.05], [0.22, 0.13, 0.2]);
    M(SPH(), muzzle, head, [0, 0.085, 0.155], [0.18, 0.09, 0.15]);
    M(SPH(), C.black, head, [0, 0.145, 0.28], [0.034, 0.022, 0.022]);
    M(SPH(), C.mouth, head, [0, 0.03, 0.15], [0.12, 0.035, 0.11]);
    teethRow(head, C, 6, 0.1, 0.025, 0.15, 0.11, 0.04);
    for (const s of [-1, 1]) { // two-segment rabbit ears
      const e = Gp(head, [s * 0.09, 0.35, -0.05]); e.rotation.z = -s * 0.12; e.rotation.x = -0.12;
      M(CAP(0.05, 0.08), headMat, e, [0, 0.05, 0], [1, 1, 0.8]); M(CYL(0.02, 0.02, 0.05, 8), C.endo, e, [0, 0.13, 0]);
      M(CAP(0.055, 0.1), headMat, e, [0, 0.24, 0], [1.3, 1, 0.55]); M(CYL(0.018, 0.018, 0.05, 8), C.endo, e, [0, 0.34, 0]);
      M(CAP(0.055, 0.1), headMat, e, [0, 0.44, 0], [1.3, 1, 0.55]); M(CONE(0.07, 0.09), headMat, e, [0, 0.575, 0], [1, 1, 0.45]);
    }
    R.eyes.push(eye(head, -0.085, 0.21, 0.165, S.eye, C, headMat, 1.1, 0.34), eye(head, 0.085, 0.21, 0.165, S.eye, C, headMat, 1.1, 0.34));
    M(SPH(), muzzle, jaw, [0, -0.03, 0.12], [0.13, 0.05, 0.12]);
    teethRow(jaw, C, 5, 0.08, 0.0, 0.12, 0.1, 0.03);
  } else if (isChica) {
    M(SPH(), headMat, head, [0, 0.16, 0], [0.235, 0.245, 0.22]);
    M(SPH(), headMat, head, [0, 0.07, 0.04], [0.22, 0.13, 0.19]);
    M(SPH(), C.mouth, head, [0, 0.055, 0.14], [0.12, 0.03, 0.1]);
    M(SPH(), C.fur(0xd9782a, 1), head, [0, 0.09, 0.18], [0.115, 0.055, 0.15]);
    teethRow(head, C, 6, 0.09, 0.05, 0.14, 0.1, 0.028);
    for (const [a, sx, h] of [[-0.8, -1, 0.085], [0.0, 0, 0.07], [0.8, 1, 0.085]]) M(SPH(), C.fur(0xd8b030, 1), head, [sx * 0.05, 0.43 + (sx ? 0 : 0.02), -0.01], [0.035, h, 0.02], [0, 0, a]);
    const lidM = C.fur(0x4a2e4a, 1);
    R.eyes.push(eye(head, -0.088, 0.21, 0.168, S.eye, C, lidM, 1.2, 0.55), eye(head, 0.088, 0.21, 0.168, S.eye, C, lidM, 1.2, 0.55));
    const cj = Gp(jaw, [0, 0, 0]); cj.rotation.x = 0.3; M(SPH(), C.fur(0xd9782a, 1), cj, [0, -0.028, 0.16], [0.1, 0.045, 0.13]);
  } else if (isFoxy) {
    M(SPH(), headMat, head, [0, 0.17, -0.02], [0.2, 0.2, 0.2]);
    M(SPH(), headMat, head, [0, 0.1, 0.03], [0.19, 0.12, 0.18]);
    M(SPH(), muzzle, head, [0, 0.11, 0.22], [0.125, 0.08, 0.25]);
    M(SPH(), C.black, head, [0, 0.155, 0.45], [0.04, 0.03, 0.03]);
    M(SPH(), C.mouth, head, [0, 0.05, 0.22], [0.095, 0.05, 0.22]);
    for (const s of [-1, 1]) for (let i = 0; i < 5; i++) M(CONE(0.014, 0.045), C.teeth, head, [s * (0.082 - i * 0.009), 0.03, 0.2 + i * 0.05], null, [Math.PI, 0, 0]);
    for (const s of [-1, 1]) { const e = Gp(head, [s * 0.12, 0.33, -0.04]); e.rotation.z = -s * 0.3; M(CONE(0.115, 0.3), headMat, e, [0, 0.12, 0], [1, 1, 0.55]); M(CONE(0.075, 0.21), C.fur(0x2e1410, 1), e, [0, 0.1, 0.035], [1, 1, 0.4]); }
    const l = eye(head, -0.075, 0.21, 0.155, S.eye, C, headMat, 1.1, 0.3); R.eyes.push(l); l.visible = false;
    R.eyes.push(eye(head, 0.075, 0.21, 0.155, S.eye, C, headMat, 1.1, 0.3));
    M(RBOX(0.14, 0.11, 0.03, 0.04), C.black, head, [-0.075, 0.215, 0.19], null, [-0.3, -0.35, 0]);
    M(new THREE.TorusGeometry(0.205, 0.024, 8, 40), C.black, head, [0, 0.21, -0.01], null, [0.35, 0, -0.35]);
    M(RBOX(0.1, 0.022, 0.03, 0.008), C.black, head, [0.075, 0.29, 0.17], null, [-0.5, 0, 0.3]);
    const jo = Gp(jaw, [0, 0, 0]); jo.rotation.x = 0.28;
    M(SPH(), muzzle, jo, [0, -0.04, 0.2], [0.11, 0.06, 0.22]);
    for (const s of [-1, 1]) for (let i = 0; i < 5; i++) M(CONE(0.014, 0.045), C.teeth, jo, [s * (0.072 - i * 0.008), 0.012, 0.18 + i * 0.045]);
  }
  // arms
  const armSide = (s) => {
    const sh = Gp(torso, [s * (tw + 0.03), 0.6, 0]); M(SPH(), body, sh, [0, 0, 0], [0.11, 0.11, 0.11]);
    M(CYL(0.03, 0.03, 0.08, 10), C.endo, sh, [0, -0.08, 0]);
    M(CAP(0.098, 0.095), body, sh, [0, -0.2, 0]);
    const el = Gp(sh, [0, -0.33, 0]); M(CYL(0.03, 0.03, 0.07, 10), C.endo, el, [0, 0, 0], null, [0, 0, Math.PI / 2]);
    const isHook = isFoxy && s < 0;
    M(CAP(0.09, 0.085), body, el, [0, -0.14, 0]);
    const hand = Gp(el, [0, -0.29, 0]);
    if (isHook) {
      hand.scale.setScalar(1.5); M(CYL(0.02, 0.026, 0.12, 10), C.steel, hand, [0, 0.02, 0]); M(CYL(0.062, 0.062, 0.06, 16), C.endo, hand, [0, 0.06, 0]);
      M(CYL(0.016, 0.016, 0.08, 10), C.steel, hand, [0, -0.07, 0]); M(new THREE.TorusGeometry(0.085, 0.018, 10, 28, Math.PI * 1.3), C.steel, hand, [0.085 * s * -1, -0.12, 0], null, [0, 0, s < 0 ? -Math.PI * 0.35 : Math.PI * 0.05]); M(CONE(0.018, 0.04), C.steel, hand, [-0.17 * s * -1 * 0 + 0.0, -0.2, 0], [1,1,1]);
    } else {
      const hm = body;
      M(RBOX(0.09, 0.15, 0.17, 0.04), hm, hand, [0, -0.04, 0]);
      for (let f = 0; f < 3; f++) M(CAP(0.032, 0.07), hm, hand, [0, -0.17, -0.05 + f * 0.05]);
      M(CAP(0.027, 0.06), hm, hand, [s * -0.03, -0.06, 0.085], null, [0.7, 0, 0]);
    }
    return { sh, el, hand };
  };
  const aL = armSide(-1), aR = armSide(1); R.shL = aL.sh; R.elL = aL.el; R.shR = aR.sh; R.elR = aR.el; R.handL = aL.hand; R.handR = aR.hand;
  if (isBonnie) { // red flying-V on a strap at his side
    const gt = Gp(torso, [-0.64, -0.42, 0.04]); gt.rotation.set(0, 0.25, 0.05);
    const gm = new THREE.MeshPhysicalMaterial({ color: 0xb3161c, roughness: 0.25, clearcoat: 1, clearcoatRoughness: 0.15 });
    for (const s of [-1, 1]) M(RBOX(0.12, 0.5, 0.05, 0.03), gm, gt, [s * 0.1, -0.33, 0], null, [0, 0, s * 0.4]);
    M(RBOX(0.17, 0.14, 0.05, 0.04), gm, gt, [0, -0.13, 0]);
    M(RBOX(0.14, 0.06, 0.012, 0.004), C.black, gt, [0, -0.2, 0.026]);
    M(RBOX(0.045, 0.6, 0.03, 0.008), C.fur(0x3a2418, 1), gt, [0, 0.2, 0.004]);
    M(RBOX(0.08, 0.13, 0.03, 0.01), C.fur(0x3a2418, 1), gt, [0, 0.55, 0.004], null, [0, 0, 0.0]);
    for (const s of [-1, 1]) for (let i = 0; i < 3; i++) M(CYL(0.008, 0.008, 0.03, 6), C.steel, gt, [s * 0.045, 0.52 + i * 0.035, 0.004], null, [0, 0, Math.PI / 2]);
  }
  if (isFoxy) { // ragged tail stub
    const tl = Gp(hips, [0, 0.02, -0.18]); tl.rotation.x = -0.9;
    M(CAP(0.06, 0.16), body, tl, [0, -0.14, 0]); M(CONE(0.06, 0.1), belly, tl, [0, -0.3, 0], null, [Math.PI, 0, 0]);
  }
  if (kind === "freddy") { const mic = Gp(aR.hand, [0, -0.12, 0.07]); M(CYL(0.018, 0.014, 0.16, 12), C.black, mic, [0, 0, 0], null, [0.2, 0, 0]); M(SPH(), C.endo, mic, [0, 0.1, 0.02], [0.035, 0.035, 0.035]); }
  if (isChica) {
    const cc = Gp(aL.hand, [0, -0.1, 0.12]); cc.scale.setScalar(1.1);
    M(CYL(0.05, 0.04, 0.06, 18), C.fur(0x6ab0d8, 1), cc, [0, 0, 0]); M(SPH(), C.fur(0xe07aa8, 1), cc, [0, 0.05, 0], [0.058, 0.045, 0.058]);
    M(CYL(0.005, 0.005, 0.05, 6), C.fur(0xf0e8d0, 1), cc, [0, 0.11, 0]); const fl = M(SPHL(), C.glow, cc, [0, 0.14, 0], [0.006, 0.01, 0.006]); fl.castShadow = false;
    for (const s of [-1, 1]) M(SPH(), C.sclera, cc, [s * 0.018, 0.06, 0.05], [0.012, 0.014, 0.008]);
  }
  // legs
  const legSide = (s) => {
    const th = Gp(hips, [s * 0.155, -0.05, 0]);
    M(SPH(), legMat, th, [0, 0, 0], [0.125, 0.11, 0.125]);
    M(CAP(0.135, 0.15), legMat, th, [0, -0.2, 0]);
    const kn = Gp(th, [0, -0.42, 0]); M(CYL(0.04, 0.04, 0.1, 10), C.endo, kn, [0, 0, 0], null, [0, 0, Math.PI / 2]);
    if (isFoxy) { M(CYL(0.038, 0.038, 0.34, 12), C.steel, kn, [0, -0.18, 0]); M(CYL(0.016, 0.016, 0.3, 6), C.steel, kn, [0.05, -0.18, 0.015]); for (const y of [-0.06, -0.3]) M(CYL(0.05, 0.05, 0.035, 14), C.endo, kn, [0, y, 0]); }
    else M(CAP(0.115, 0.17), shinMat, kn, [0, -0.19, 0]);
    const an = Gp(kn, [0, -0.38, 0]);
    const fm = isFoxy ? C.steel : shinMat; an.scale.set(isFoxy ? 1.2 : 1.15, 1.1, isFoxy ? 1.2 : 1.12);
    M(RBOX(0.24, 0.11, 0.33, 0.05), fm, an, [0, -0.045, 0.04]);
    if (isBear) M(RBOX(0.25, 0.025, 0.34, 0.012), muzzle, an, [0, -0.095, 0.04]);
    for (let t = -1; t <= 1; t++) {
      if (isChica) { M(SPH(), fm, an, [t * 0.065, -0.05, 0.2], [0.04, 0.04, 0.06]); M(CONE(0.036, 0.1), C.steel, an, [t * 0.075, -0.075, 0.27], null, [Math.PI / 2 + 0.35, 0, 0]); }
      else M(SPH(), fm, an, [t * 0.072, -0.05, 0.21], [0.048, 0.048, 0.07]);
    }
    return { th, kn, an };
  };
  const lL = legSide(-1), lR = legSide(1); R.thL = lL.th; R.knL = lL.kn; R.thR = lR.th; R.knR = lR.kn;
  const sc = isBonnie ? 0.97 : isFoxy ? 0.98 : 0.95; root.scale.setScalar(sc);
  R.height = 2.0 * sc;
  root.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  R.setGlow = (v) => R.eyes.forEach((e) => { e.userData.glow.visible = v; });
  R.setGlow(false);
  return R;
}

/* --------------- GUARD --------------- */
export function buildGuard(T, colors) {
  const C = charMaterials(T);
  const shirt = new THREE.MeshStandardMaterial({ color: colors.shirt, roughness: 0.85, normalMap: T.cloth.normalMap, normalScale: new THREE.Vector2(0.6, 0.6) });
  const pants = new THREE.MeshStandardMaterial({ color: colors.pants, roughness: 0.9, normalMap: T.cloth.normalMap });
  const skin = new THREE.MeshPhysicalMaterial({ color: colors.skin, roughness: 0.55, sheen: 0.3, sheenColor: 0xffcfb0 });
  const hair = new THREE.MeshStandardMaterial({ color: colors.hair, roughness: 0.7, normalMap: T.fur.normalMap });
  const shoe = new THREE.MeshStandardMaterial({ color: 0x5a3018, roughness: 0.45 });
  const sole = new THREE.MeshStandardMaterial({ color: 0x2a1a10, roughness: 0.7 });
  const sock = new THREE.MeshStandardMaterial({ color: 0xece8e0, roughness: 0.9 });
  const root = new THREE.Group(); const R = { root, kind: "guard", phase: 0, mats: { shirt, pants, skin, hair } };
  const hips = Gp(root, [0, 0.93, 0]); R.hips = hips;
  M(RBOX(0.38, 0.2, 0.23, 0.07), pants, hips, [0, 0, 0]);
  const torso = Gp(hips, [0, 0.08, 0]); R.torso = torso;
  M(RBOX(0.38, 0.5, 0.21, 0.08), shirt, torso, [0, 0.27, 0]);
  M(RBOX(0.395, 0.06, 0.225, 0.025), shirt, torso, [0, 0.04, 0]); // hem
  M(SPH(), shirt, torso, [0, 0.46, 0], [0.25, 0.085, 0.115]);
  const vneck = M(CIRC(0.06), skin, torso, [0, 0.45, 0.113], [0.9, 1.4, 1]); vneck.geometry = new THREE.CircleGeometry(0.06, 3); vneck.rotation.set(-0.35, 0, -Math.PI / 2); vneck.castShadow = false;
  const logo = M(CIRC(0.105), C.logo, torso, [0, 0.27, 0.107]); logo.castShadow = false;
  M(CYL(0.045, 0.05, 0.1, 14), skin, torso, [0, 0.55, 0]);
  const head = Gp(torso, [0, 0.6, 0]); R.head = head; head.scale.setScalar(1.18);
  M(SPH(), skin, head, [0, 0.11, 0.005], [0.095, 0.125, 0.105]);
  M(SPH(), skin, head, [0, 0.05, 0.02], [0.075, 0.07, 0.085]); // jaw
  M(SPH(), hair, head, [0, 0.16, -0.015], [0.103, 0.1, 0.105]);
  for (const s of [-1, 1]) { M(SPH(), hair, head, [s * 0.09, 0.14, -0.02], [0.03, 0.06, 0.06], [0, 0, s * 0.3]); M(SPH(), hair, head, [s * 0.1, 0.115, -0.04], [0.025, 0.035, 0.04]); }
  for (const s of [-1, 1]) {
    M(SPH(), skin, head, [s * 0.095, 0.1, 0], [0.018, 0.03, 0.015]);
    M(SPH(), C.sclera, head, [s * 0.036, 0.13, 0.092], [0.024, 0.019, 0.011]);
    M(SPH(), C.pupil, head, [s * 0.036, 0.13, 0.101], [0.01, 0.01, 0.004]);
    M(RBOX(0.036, 0.007, 0.01, 0.002), hair, head, [s * 0.036, 0.155, 0.098], null, [0, 0, s * -0.1]);
  }
  M(SPH(), skin, head, [0, 0.1, 0.108], [0.014, 0.024, 0.02]);
  M(RBOX(0.035, 0.005, 0.006, 0.001), new THREE.MeshStandardMaterial({ color: 0x6a3a30 }), head, [0, 0.058, 0.1]);
  const cap = Gp(head, [0, 0.2, 0]); const capMat = new THREE.MeshStandardMaterial({ color: colors.shirt, roughness: 0.8 }); R.mats.cap = capMat;
  M(CYL(0.1, 0.108, 0.13, 28), capMat, cap, [0, 0.05, 0]); M(new THREE.CylinderGeometry(0.112, 0.17, 0.045, 32, 1, true), capMat, cap, [0, -0.02, 0]); M(CYL(0.111, 0.111, 0.025, 28), new THREE.MeshStandardMaterial({ color: 0x2a1a30, roughness: 0.8 }), cap, [0, 0.0, 0]);
  const cl = M(CIRC(0.045), C.logo, cap, [0, 0.06, 0.107], null, [-0.06, 0, 0]); capMat.side = THREE.DoubleSide; cl.castShadow = false;
  const armSide = (s) => {
    const sh = Gp(torso, [s * 0.22, 0.43, 0]); M(SPH(), shirt, sh, [0, 0, 0], [0.075, 0.075, 0.075]); M(CYL(0.066, 0.078, 0.22, 16), shirt, sh, [0, -0.1, 0]);
    M(CAP(0.042, 0.1), skin, sh, [0, -0.2, 0]);
    const el = Gp(sh, [0, -0.28, 0]); M(CAP(0.042, 0.18), skin, el, [0, -0.12, 0]);
    const hand = Gp(el, [0, -0.26, 0]); M(RBOX(0.065, 0.09, 0.035, 0.016), skin, hand, [0, -0.02, 0]);
    M(CAP(0.013, 0.03), skin, hand, [s * -0.035, -0.02, 0.015], null, [0, 0, s * 0.5]);
    return { sh, el, hand };
  };
  const aL = armSide(-1), aR = armSide(1); R.shL = aL.sh; R.elL = aL.el; R.shR = aR.sh; R.elR = aR.el;
  const fl = Gp(aR.hand, [0, -0.04, 0.04]); M(CYL(0.018, 0.022, 0.16, 12), C.black, fl, [0, 0, 0.05], null, [Math.PI / 2, 0, 0]);
  R.lens = M(CIRC(0.02), new THREE.MeshBasicMaterial({ color: new THREE.Color(4, 3.8, 3.2) }), fl, [0, 0, 0.131]);
  const legSide = (s) => {
    const th = Gp(hips, [s * 0.095, -0.05, 0]); M(CYL(0.098, 0.1, 0.46, 18), pants, th, [0, -0.2, 0]);
    const kn = Gp(th, [0, -0.43, 0]); M(SPH(), pants, kn, [0, 0, 0], [0.1, 0.07, 0.1]); M(CYL(0.1, 0.112, 0.32, 18), pants, kn, [0, -0.16, 0]);
    M(CYL(0.05, 0.05, 0.1, 12), sock, kn, [0, -0.37, 0]);
    const an = Gp(kn, [0, -0.42, 0]); an.scale.set(1.25, 1.1, 1.25); M(RBOX(0.13, 0.08, 0.3, 0.035), shoe, an, [0, -0.01, 0.06]); M(SPH(), shoe, an, [0, 0.0, 0.17], [0.07, 0.045, 0.06]); M(RBOX(0.14, 0.024, 0.32, 0.008), sole, an, [0, -0.048, 0.06]);
    return { th, kn };
  };
  const lL = legSide(-1), lR = legSide(1); R.thL = lL.th; R.knL = lL.kn; R.thR = lR.th; R.knR = lR.kn;
  R.height = 1.78;
  root.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  R.setColors = (c) => { shirt.color.set(c.shirt); capMat.color.set(c.shirt); pants.color.set(c.pants); skin.color.set(c.skin); hair.color.set(c.hair); };
  return R;
}

/* --------------- ANIMATION --------------- */
const lerp = (a, b, t) => a + (b - a) * t;
export function animateRig(R, dt, s) {
  const anim = R.kind !== "guard";
  const speed = s.speed || 0; const amp = Math.min(1.25, speed / (anim ? 3.6 : 3.0));
  R.phase += dt * (speed / (anim ? 1.25 : 1.5)) * Math.PI;
  const p = R.phase; const k = 1 - Math.exp(-dt * 12);
  let thL = -Math.sin(p) * 0.55 * amp, thR = Math.sin(p) * 0.55 * amp;
  let knL = Math.max(0, Math.sin(p + 1.4)) * 0.95 * amp + 0.05, knR = Math.max(0, Math.sin(p + 1.4 + Math.PI)) * 0.95 * amp + 0.05;
  let shL = Math.sin(p) * (anim ? 0.3 : 0.45) * amp, shR = -Math.sin(p) * (anim ? 0.3 : 0.45) * amp;
  let elL = -0.25 - amp * 0.2, elR = -0.25 - amp * 0.2, shZ = anim ? 0.04 : 0.05;
  let hipY = (anim ? 0.95 : 0.93) + Math.abs(Math.cos(p)) * 0.035 * amp - amp * 0.02;
  let headX = 0, headY = s.lookYaw || 0, jaw = s.jaw || 0, torsoX = amp * 0.08, torsoZ = Math.sin(p) * 0.04 * amp;
  if (s.state === "jumpscare") {
    const t = s.t || 0; shL = shR = -2.0; elL = elR = -0.7; shZ = 0.45; jaw = 0.6 + Math.sin(t * 60) * 0.08; headX = 0.12 + Math.sin(t * 45) * 0.06; headY = Math.sin(t * 38) * 0.1; torsoX = 0.42;
    thL = -0.3; thR = 0.2; knL = 0.4; knR = 0.3;
  } else if (s.state === "stunned") {
    headX = 0.55; shL = shR = 0.05; elL = elR = -0.05; shZ = 0.02; torsoX = 0.2; jaw = 0.2; hipY -= 0.03;
  } else if (s.state === "slumped") {
    hipY = 0.35; thL = thR = -1.5; knL = knR = 1.3; torsoX = -0.25; headX = 0.6; headY = 0.3; shL = shR = 0.1; elL = elR = -0.1; shZ = 0.3; jaw = 0.25;
  } else if (s.state === "pose") {
    shL = 0.1; shR = -0.6; elR = -1.1; elL = -0.3;
  } else if (s.state === "run" && !anim) {
    torsoX = 0.2;
  }
  // animatronic servo twitch
  if (anim) {
    R.jitterT -= dt; if (R.jitterT <= 0) { R.jitterT = 0.6 + Math.random() * 2.4; R.jitter = (Math.random() - 0.5) * 0.35; }
    headY += R.jitter * (s.state === "idle" || !speed ? 1 : 0.4);
    if (s.state !== "jumpscare") headX += Math.sin(p * 2) * 0.03 * amp;
  }
  const set = (o, prop, v, kk = k) => { o.rotation[prop] = lerp(o.rotation[prop], v, kk); };
  set(R.thL, "x", thL); set(R.thR, "x", thR); set(R.knL, "x", knL); set(R.knR, "x", knR);
  set(R.shL, "x", shL); set(R.shR, "x", shR); set(R.elL, "x", elL); set(R.elR, "x", elR);
  set(R.shL, "z", -shZ); set(R.shR, "z", shZ);
  set(R.torso, "x", torsoX); set(R.torso, "z", torsoZ);
  const hk = anim ? 1 - Math.exp(-dt * 20) : k; set(R.head, "x", headX, hk); set(R.head, "y", headY, hk);
  if (R.jaw) set(R.jaw, "x", jaw, 1 - Math.exp(-dt * 25));
  R.hips.position.y = lerp(R.hips.position.y, hipY, k);
}
