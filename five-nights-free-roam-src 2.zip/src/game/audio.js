// Procedural WebAudio: no samples, everything synthesized.
export class Audio {
  constructor() { this.ctx = null; this.enabled = false; }
  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    const c = (this.ctx = new AC()); this.master = c.createGain(); this.master.gain.value = 0.8;
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; this.master.connect(comp); comp.connect(c.destination);
    this.enabled = true;
    const len = c.sampleRate * 2; this.noise = c.createBuffer(1, len, c.sampleRate); const d = this.noise.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    // ambience: electrical hum + air
    const hum = c.createOscillator(); hum.type = "sawtooth"; hum.frequency.value = 60; const hf = c.createBiquadFilter(); hf.type = "lowpass"; hf.frequency.value = 180; const hg = c.createGain(); hg.gain.value = 0.022; hum.connect(hf).connect(hg).connect(this.master); hum.start();
    const air = this.src(true); const af = c.createBiquadFilter(); af.type = "lowpass"; af.frequency.value = 400; this.airGain = c.createGain(); this.airGain.gain.value = 0.05; air.connect(af).connect(this.airGain).connect(this.master); air.start();
    // office fan (volume set by distance)
    const fan = this.src(true); const ff = c.createBiquadFilter(); ff.type = "bandpass"; ff.frequency.value = 900; ff.Q.value = 0.6; const lfo = c.createOscillator(); lfo.frequency.value = 11; const lg = c.createGain(); lg.gain.value = 0.3; this.fanGain = c.createGain(); this.fanGain.gain.value = 0;
    const fm = c.createGain(); fm.gain.value = 0.7; lfo.connect(lg).connect(fm.gain); fan.connect(ff).connect(fm).connect(this.fanGain).connect(this.master); fan.start(); lfo.start();
    // heartbeat bus
    this.heartT = 0;
  }
  src(loop = false) { const s = this.ctx.createBufferSource(); s.buffer = this.noise; s.loop = loop; return s; }
  panner(x, z) {
    const p = this.ctx.createPanner(); p.panningModel = "HRTF"; p.distanceModel = "inverse"; p.refDistance = 1.5; p.rolloffFactor = 1.4; p.maxDistance = 40;
    p.positionX.value = x; p.positionY.value = 1; p.positionZ.value = z; p.connect(this.master); return p;
  }
  listener(x, z, yaw) {
    if (!this.enabled) return; const L = this.ctx.listener; const t = this.ctx.currentTime;
    if (L.positionX) { L.positionX.setTargetAtTime(x, t, 0.02); L.positionY.value = 1.6; L.positionZ.setTargetAtTime(z, t, 0.02); L.forwardX.value = Math.sin(yaw); L.forwardY.value = 0; L.forwardZ.value = Math.cos(yaw); L.upX.value = 0; L.upY.value = 1; L.upZ.value = 0; }
    else { L.setPosition(x, 1.6, z); L.setOrientation(Math.sin(yaw), 0, Math.cos(yaw), 0, 1, 0); }
  }
  env(g, t, a, peak, dec) { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + dec); }
  // heavy servo footstep
  clank(x, z, vol = 1, heavy = 1) {
    if (!this.enabled) return; const c = this.ctx, t = c.currentTime; const out = this.panner(x, z);
    const n = this.src(); const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 1800 + Math.random() * 1400; bp.Q.value = 4; const g = c.createGain(); this.env(g, t, 0.002, 0.35 * vol, 0.09); n.connect(bp).connect(g).connect(out); n.start(t, Math.random()); n.stop(t + 0.2);
    const o = c.createOscillator(); o.type = "sine"; o.frequency.setValueAtTime(95 * heavy, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.15); const og = c.createGain(); this.env(og, t, 0.003, 0.7 * vol, 0.18); o.connect(og).connect(out); o.start(t); o.stop(t + 0.25);
    const s = c.createOscillator(); s.type = "square"; s.frequency.setValueAtTime(520 + Math.random() * 200, t); s.frequency.linearRampToValueAtTime(380, t + 0.12); const sf = c.createBiquadFilter(); sf.type = "lowpass"; sf.frequency.value = 1200; const sg = c.createGain(); this.env(sg, t + 0.01, 0.01, 0.04 * vol, 0.12); s.connect(sf).connect(sg).connect(out); s.start(t); s.stop(t + 0.2);
  }
  step(x, z, vol = 0.4) {
    if (!this.enabled) return; const c = this.ctx, t = c.currentTime; const out = this.panner(x, z);
    const n = this.src(); const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 700; const g = c.createGain(); this.env(g, t, 0.003, vol, 0.08); n.connect(lp).connect(g).connect(out); n.start(t, Math.random()); n.stop(t + 0.15);
  }
  thud(vol = 1) { // door slam
    if (!this.enabled) return; const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator(); o.frequency.setValueAtTime(70, t); o.frequency.exponentialRampToValueAtTime(30, t + 0.4); const g = c.createGain(); this.env(g, t, 0.005, 0.9 * vol, 0.5); o.connect(g).connect(this.master); o.start(t); o.stop(t + 0.6);
    const n = this.src(); const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 600; const ng = c.createGain(); this.env(ng, t, 0.003, 0.5 * vol, 0.3); n.connect(bp).connect(ng).connect(this.master); n.start(t); n.stop(t + 0.4);
  }
  click() { if (!this.enabled) return; const c = this.ctx, t = c.currentTime; const o = c.createOscillator(); o.type = "square"; o.frequency.value = 1400; const g = c.createGain(); this.env(g, t, 0.001, 0.08, 0.03); o.connect(g).connect(this.master); o.start(t); o.stop(t + 0.05); }
  buzz(x, z, dur = 0.5) {
    if (!this.enabled) return; const c = this.ctx, t = c.currentTime; const out = x == null ? this.master : this.panner(x, z);
    const o = c.createOscillator(); o.type = "sawtooth"; o.frequency.value = 120; const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.15, t + 0.02); g.gain.setValueAtTime(0.15, t + dur); g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.1); o.connect(g).connect(out); o.start(t); o.stop(t + dur + 0.2);
  }
  zap() { if (!this.enabled) return; const c = this.ctx, t = c.currentTime; const n = this.src(); const hp = c.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 2500; const g = c.createGain(); this.env(g, t, 0.002, 0.25, 0.25); n.connect(hp).connect(g).connect(this.master); n.start(t); n.stop(t + 0.3); this.buzz(null, null, 0.2); }
  scream() {
    if (!this.enabled) return; const c = this.ctx, t = c.currentTime; const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.9, t + 0.03); g.gain.setValueAtTime(0.9, t + 1.1); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
    const ws = c.createWaveShaper(); const curve = new Float32Array(1024); for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; curve[i] = Math.tanh(x * 6); } ws.curve = curve; ws.connect(g); g.connect(this.master);
    for (const f of [310, 447, 623, 890]) { const o = c.createOscillator(); o.type = "sawtooth"; o.frequency.setValueAtTime(f, t); o.frequency.linearRampToValueAtTime(f * 0.7, t + 1.5); const lf = c.createOscillator(); lf.frequency.value = 23 + Math.random() * 10; const lg = c.createGain(); lg.gain.value = f * 0.08; lf.connect(lg).connect(o.frequency); const og = c.createGain(); og.gain.value = 0.18; o.connect(og).connect(ws); o.start(t); o.stop(t + 1.7); lf.start(t); lf.stop(t + 1.7); }
    const n = this.src(); const ng = c.createGain(); ng.gain.value = 0.5; n.connect(ng).connect(ws); n.start(t); n.stop(t + 1.7);
  }
  laugh(x, z) { // Freddy laugh: low formant pulses
    if (!this.enabled) return; const c = this.ctx, t0 = c.currentTime; const out = this.panner(x, z);
    for (let k = 0; k < 5; k++) { const t = t0 + k * 0.17; const o = c.createOscillator(); o.type = "sawtooth"; o.frequency.setValueAtTime(150 - k * 8, t); o.frequency.linearRampToValueAtTime(110 - k * 6, t + 0.14); const f = c.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = 650; f.Q.value = 3; const g = c.createGain(); this.env(g, t, 0.02, 0.5, 0.12); o.connect(f).connect(g).connect(out); o.start(t); o.stop(t + 0.2); }
  }
  chime() {
    if (!this.enabled) return; const c = this.ctx, t0 = c.currentTime;
    [0, 0.5, 1.0, 1.5, 2.0, 2.5].forEach((dt, i) => { for (const f of [523.25, 659.25, 783.99].map((x) => x * (i % 2 ? 1 : 0.75))) { const o = c.createOscillator(); o.type = "sine"; o.frequency.value = f; const g = c.createGain(); this.env(g, t0 + dt, 0.005, 0.12, 1.6); o.connect(g).connect(this.master); o.start(t0 + dt); o.stop(t0 + dt + 1.8); } });
  }
  musicBox() { // Toreador march fragment, music-box timbre
    if (!this.enabled || this.mbPlaying) return; this.mbPlaying = true; const c = this.ctx, t0 = c.currentTime + 0.1;
    const notes = [[67, 1], [69, 0.5], [67, 0.5], [64, 1], [64, 1], [64, 0.5], [62, 0.5], [64, 0.5], [65, 0.5], [64, 2], [65, 1], [62, 0.5], [67, 0.5], [64, 2], [60, 1], [57, 0.5], [62, 0.5], [55, 2]];
    let t = t0; for (let rep = 0; rep < 2; rep++) for (const [n, d] of notes) { const f = 440 * Math.pow(2, (n + 12 - 69) / 12); for (const h of [1, 2.01, 3.98]) { const o = c.createOscillator(); o.type = "sine"; o.frequency.value = f * h; const g = c.createGain(); this.env(g, t, 0.003, 0.09 / h, 0.9 * d); o.connect(g).connect(this.master); o.start(t); o.stop(t + d + 1); } t += d * 0.42; }
    setTimeout(() => (this.mbPlaying = false), (t - t0) * 1000);
  }
  heartbeat(intensity) { if (!this.enabled || intensity <= 0.05) return; const c = this.ctx, t = c.currentTime; for (const [dt, v] of [[0, 1], [0.16, 0.7]]) { const o = c.createOscillator(); o.frequency.setValueAtTime(58, t + dt); o.frequency.exponentialRampToValueAtTime(38, t + dt + 0.12); const g = c.createGain(); this.env(g, t + dt, 0.01, 0.5 * v * intensity, 0.14); o.connect(g).connect(this.master); o.start(t + dt); o.stop(t + dt + 0.2); } }
  setFan(v) { if (this.fanGain) this.fanGain.gain.setTargetAtTime(v * 0.08, this.ctx.currentTime, 0.2); }
  staticBurst(dur = 0.4, vol = 0.12) { if (!this.enabled) return; const c = this.ctx, t = c.currentTime; const n = this.src(); const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); n.connect(g).connect(this.master); n.start(t, Math.random()); n.stop(t + dur); }
}
