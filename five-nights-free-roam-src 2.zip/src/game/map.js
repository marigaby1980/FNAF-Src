import * as THREE from "three";

export const CELL = 0.5, GW = 84, GH = 100, WALL_H = 3.0;
export const T = { VOID: 0, FLOOR: 1, WALL: 2, WINDOW: 3 };

export const ROOMS = [
  { id: "restroom", name: "Restrooms", r: [1, 0.5, 10.5, 7.5], floor: "smalltile", wall: "tile", cam: 9 },
  { id: "stage", name: "Show Stage", r: [11, 3, 21, 7.5], floor: "wood", wall: "party", cam: 1 },
  { id: "backstage", name: "Backstage", r: [21.5, 0.5, 30, 7.5], floor: "concrete", wall: "block", cam: 8 },
  { id: "kitchen", name: "Kitchen", r: [30.5, 3, 38, 7.5], floor: "smalltile", wall: "tile", cam: 4 },
  { id: "easthall", name: "East Hall", r: [38.5, 3, 41, 31], floor: "checker", wall: "main" },
  { id: "dining", name: "Dining Area", r: [4, 8, 28.5, 22], floor: "checker", wall: "main", cam: 2 },
  { id: "party4", name: "Party Room A", r: [29, 8, 38, 17], floor: "carpet", wall: "party", cam: 3 },
  { id: "party5", name: "Party Room B", r: [29, 17.5, 38, 24.5], floor: "carpet", wall: "party", cam: 5 },
  { id: "closet", name: "Supply Closet", r: [0.5, 8, 3.5, 13.5], floor: "concrete", wall: "block", cam: 10 },
  { id: "cove", name: "Pirate Cove", r: [0.5, 14, 3.5, 21.5], floor: "wood", wall: "party", cam: 6 },
  { id: "westhall", name: "West Hall", r: [0.5, 22.5, 5, 40], floor: "checker", wall: "main", cam: 7 },
  { id: "arcade", name: "Arcade", r: [5.5, 22.5, 28.5, 40], floor: "carpet2", wall: "main", cam: 11 },
  { id: "ballpit", name: "Ball Pit", r: [29, 25, 38, 32], floor: "carpet", wall: "party", cam: 12 },
  { id: "party12", name: "Party Room C", r: [29, 32.5, 40, 46], floor: "carpet", wall: "party" },
  { id: "storage", name: "Parts & Service", r: [0.5, 40.5, 10, 49], floor: "concrete", wall: "block" },
  { id: "southhall", name: "South Hall", r: [10.5, 40.5, 28.5, 43], floor: "checker", wall: "main" },
  { id: "wcorr", name: "West Corridor", r: [10.5, 43.5, 16.5, 49], floor: "checker", wall: "main", cam: 13 },
  { id: "office", name: "Security Office", r: [17, 43.5, 23, 49], floor: "checker", wall: "party" },
  { id: "ecorr", name: "East Corridor", r: [23.5, 43.5, 28.5, 49], floor: "checker", wall: "main", cam: 14 },
];
// [x0,z0,x1,z1, kind]
export const DOORS = [
  [7, 7.5, 8.5, 8], [11, 7.5, 21, 8, "wide"], [21, 4, 21.5, 5.5], [24, 7.5, 25.5, 8], [30, 5, 30.5, 6.5],
  [33, 7.5, 34.5, 8], [38, 4, 38.5, 5.5], [38, 21, 38.5, 22.5], [38, 28, 38.5, 29.5],
  [28.5, 10, 29, 15, "wide"], [28.5, 19, 29, 20.5], [33, 17, 34.5, 17.5],
  [3.5, 10, 4, 11.5], [3.5, 15, 4, 21, "cove"], [4, 22, 5, 22.5], [5, 26, 5.5, 28],
  [8, 22, 11, 22.5, "wide"], [22, 22, 25, 22.5, "wide"], [28.5, 27, 29, 29], [28.5, 35, 29, 37], [28.5, 41, 29, 42.5],
  [1.5, 40, 3.5, 40.5], [10, 41, 10.5, 42.5], [18, 40, 21, 40.5, "wide"],
  [10.5, 43, 16.5, 43.5, "open"], [23.5, 43, 28.5, 43.5, "open"],
  [16.5, 45.5, 17, 47.5, "sec", "L"], [23, 45.5, 23.5, 47.5, "sec", "R"],
];
export const WINDOWS = [[18, 43, 22, 43.5]];

// Camera spots: [x,z,lookX,lookZ]
export const CAMS = {
  1: [26.5, 17, 16, 5], 2: [5, 9, 18, 18], 3: [37.5, 16.5, 31, 9.5], 4: [37.5, 7, 32, 3.5], 5: [37.5, 24, 30, 18],
  6: [9, 18.5, 1.5, 17.5], 7: [4.6, 39.5, 2, 24], 8: [29.5, 7, 23, 1.5], 9: [10, 7, 2, 1.5], 10: [3, 13, 1, 8.5],
  11: [28, 39.5, 12, 26], 12: [37.5, 31.5, 30.5, 26], 13: [11, 48.5, 15, 44], 14: [28, 48.5, 24, 44],
};
export const CAM_NAMES = { 1: "Show Stage", 2: "Dining Area", 3: "Party Room A", 4: "Kitchen", 5: "Party Room B", 6: "Pirate Cove", 7: "West Hall", 8: "Backstage", 9: "Restrooms", 10: "Supply Closet", 11: "Arcade", 12: "Ball Pit", 13: "W. Corridor", 14: "E. Corridor" };

// light fixtures: [x,z,kind]  kind: warm | fluo | dim | broken | stage
export const FIXTURES = [
  [5.5, 4, "fluo"], [16, 5.5, "stage"], [26, 4, "fluo"], [34, 5, "broken"], [39.75, 9, "dim"], [39.75, 24, "dim"],
  [10.5, 12, "warm"], [20.5, 12, "warm"], [10.5, 19, "warm"], [20.5, 19, "dim"], [33.5, 12.5, "warm"], [33.5, 21, "dim"],
  [2, 10.5, "broken"], [2.5, 17.5, "dim"], [2.75, 31, "fluo"], [11, 28, "warm"], [22, 28, "warm"], [16.5, 35.5, "warm"],
  [33.5, 28.5, "dim"], [34.5, 39, "warm"], [5, 45, "broken"], [19.5, 41.8, "fluo"], [13.5, 46, "dim"], [20, 45.2, "office"], [26, 46, "dim"],
];

// Breaker boxes [x, z, wallFacing(yaw)]
export const BREAKERS = [
  { id: "backstage", x: 29.75, z: 3.5, yaw: -Math.PI / 2, room: "Backstage" },
  { id: "kitchen", x: 37.75, z: 6.5, yaw: -Math.PI / 2, room: "Kitchen" },
  { id: "closet", x: 0.75, z: 11, yaw: Math.PI / 2, room: "Supply Closet" },
  { id: "storage", x: 0.75, z: 46, yaw: Math.PI / 2, room: "Parts & Service" },
  { id: "party12", x: 39.75, z: 43, yaw: -Math.PI / 2, room: "Party Room C" },
];

const cr = (m) => Math.round(m * 2);

export class Grid {
  constructor() {
    const N = GW * GH;
    this.type = new Uint8Array(N); this.room = new Int16Array(N).fill(-1); this.carved = new Uint8Array(N);
    this.lintel = new Float32Array(N); this.prop = new Uint8Array(N); this.secDoor = new Int8Array(N).fill(-1);
    this.height = new Float32Array(N);
    ROOMS.forEach((r, i) => { const [x0, z0, x1, z1] = r.r; for (let z = cr(z0); z < cr(z1); z++) for (let x = cr(x0); x < cr(x1); x++) { this.type[this.i(x, z)] = 1; this.room[this.i(x, z)] = i; } });
    this.secDoors = [];
    DOORS.forEach((d) => {
      const [x0, z0, x1, z1, kind, side] = d; const cells = [];
      for (let z = cr(z0); z < cr(z1); z++) for (let x = cr(x0); x < cr(x1); x++) {
        const k = this.i(x, z); this.type[k] = 1; this.carved[k] = 1; cells.push(k);
        this.lintel[k] = kind === "open" ? 0 : kind === "wide" ? 2.55 : kind === "cove" ? 2.7 : 2.3;
      }
      if (kind === "sec") { const id = this.secDoors.length; cells.forEach((k) => (this.secDoor[k] = id)); this.secDoors.push({ side, cells, closed: false, x: (x0 + x1) / 2, z: (z0 + z1) / 2, anim: 0 }); }
    });
    // assign carved rooms
    for (let pass = 0; pass < 4; pass++) for (let k = 0; k < N; k++) if (this.carved[k] && this.room[k] < 0) {
      const x = k % GW, z = (k / GW) | 0;
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = this.i(x + dx, z + dz); if (n >= 0 && this.room[n] >= 0 && (!this.carved[n] || pass > 0)) { this.room[k] = this.room[n]; break; } }
    }
    for (let z = 0; z < GH; z++) for (let x = 0; x < GW; x++) {
      const k = this.i(x, z); if (this.type[k] !== 0) continue;
      let near = false; for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) { const n = this.i(x + dx, z + dz); if (n >= 0 && this.type[n] === 1) near = true; }
      if (near) this.type[k] = 2;
    }
    WINDOWS.forEach(([x0, z0, x1, z1]) => { for (let z = cr(z0); z < cr(z1); z++) for (let x = cr(x0); x < cr(x1); x++) this.type[this.i(x, z)] = 3; });
  }
  i(x, z) { return x < 0 || z < 0 || x >= GW || z >= GH ? -1 : z * GW + x; }
  cellAt(wx, wz) { return this.i(Math.floor(wx / CELL), Math.floor(wz / CELL)); }
  roomAt(wx, wz) { const k = this.cellAt(wx, wz); return k < 0 ? -1 : this.room[k]; }
  blocked(k) { if (k < 0) return true; if (this.type[k] !== 1 || this.prop[k]) return true; const s = this.secDoor[k]; return s >= 0 && this.secDoors[s].closed; }
  solidWall(k) { return k < 0 || this.type[k] === 2 || this.type[k] === 3 || (this.secDoor[k] >= 0 && this.secDoors[this.secDoor[k]].closed); }
  blockRect(x0, z0, x1, z1, h = 0) {
    for (let z = Math.floor(z0 / CELL); z <= Math.floor((z1 - 0.001) / CELL); z++) for (let x = Math.floor(x0 / CELL); x <= Math.floor((x1 - 0.001) / CELL); x++) { const k = this.i(x, z); if (k >= 0 && !this.carved[k]) this.prop[k] = 1; }
  }
  setHeight(x0, z0, x1, z1, h) { for (let z = Math.floor(z0 / CELL); z <= Math.floor((z1 - 0.001) / CELL); z++) for (let x = Math.floor(x0 / CELL); x <= Math.floor((x1 - 0.001) / CELL); x++) { const k = this.i(x, z); if (k >= 0) this.height[k] = h; } }
  heightAt(wx, wz) { const k = this.cellAt(wx, wz); return k < 0 ? 0 : this.height[k]; }
  // circle collision
  collides(wx, wz, r) {
    const x0 = Math.floor((wx - r) / CELL), x1 = Math.floor((wx + r) / CELL), z0 = Math.floor((wz - r) / CELL), z1 = Math.floor((wz + r) / CELL);
    for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
      const k = this.i(x, z); if (!this.blocked(k)) continue;
      const cx = Math.max(x * CELL, Math.min(wx, (x + 1) * CELL)), cz = Math.max(z * CELL, Math.min(wz, (z + 1) * CELL));
      if ((cx - wx) ** 2 + (cz - wz) ** 2 < r * r) return true;
    }
    return false;
  }
  los(ax, az, bx, bz) {
    const d = Math.hypot(bx - ax, bz - az), n = Math.ceil(d / 0.2);
    for (let s = 1; s < n; s++) { const t = s / n; if (this.solidWall(this.cellAt(ax + (bx - ax) * t, az + (bz - az) * t))) return false; }
    return true;
  }
  // walkability map with clearance
  buildNav() {
    const N = GW * GH; this.walk = new Uint8Array(N);
    for (let z = 0; z < GH; z++) for (let x = 0; x < GW; x++) {
      const k = this.i(x, z); if (this.blocked(k)) continue; let ok = 1;
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = this.i(x + dx, z + dz); if (n < 0 || (this.type[n] !== 1) || this.prop[n]) { ok = 2; } }
      this.walk[k] = ok; // 1 = clear, 2 = near wall (walkable but costly)
    }
  }
  path(ax, az, bx, bz) {
    const s = this.nearestWalk(this.cellAt(ax, az)), g = this.nearestWalk(this.cellAt(bx, bz)); if (s < 0 || g < 0) return null;
    const N = GW * GH; const gS = new Float32Array(N).fill(1e9), came = new Int32Array(N).fill(-1), closed = new Uint8Array(N);
    const heap = []; const push = (k, f) => { heap.push([f, k]); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = i * 2 + 1, r = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
    const gx = g % GW, gz = (g / GW) | 0; const hfn = (k) => Math.hypot((k % GW) - gx, ((k / GW) | 0) - gz);
    gS[s] = 0; push(s, hfn(s)); let iter = 0;
    while (heap.length && iter++ < 12000) {
      const [, k] = pop(); if (k === g) break; if (closed[k]) continue; closed[k] = 1; const x = k % GW, z = (k / GW) | 0;
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dz) continue; const n = this.i(x + dx, z + dz); if (n < 0 || !this.walk[n] || this.blocked(n)) continue;
        if (dx && dz && (!this.walk[this.i(x + dx, z)] || !this.walk[this.i(x, z + dz)] || this.blocked(this.i(x + dx, z)) || this.blocked(this.i(x, z + dz)))) continue;
        const c = gS[k] + (dx && dz ? 1.414 : 1) * (this.walk[n] === 2 ? 2.2 : 1);
        if (c < gS[n]) { gS[n] = c; came[n] = k; push(n, c + hfn(n)); }
      }
    }
    if (came[g] < 0 && g !== s) return null;
    const cells = []; for (let k = g; k !== -1; k = came[k]) { cells.push(k); if (k === s) break; }
    cells.reverse();
    const pts = cells.map((k) => ({ x: (k % GW + 0.5) * CELL, z: (((k / GW) | 0) + 0.5) * CELL }));
    // string pull
    const out = [pts[0]]; let i = 0;
    while (i < pts.length - 1) { let j = pts.length - 1; while (j > i + 1 && !this.clearLine(pts[i], pts[j])) j--; out.push(pts[j]); i = j; }
    return out;
  }
  clearLine(a, b) { const d = Math.hypot(b.x - a.x, b.z - a.z), n = Math.ceil(d / 0.15); for (let s = 0; s <= n; s++) { const t = s / n; const k = this.cellAt(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t); if (k < 0 || this.walk[k] !== 1 || this.blocked(k)) return false; } return true; }
  nearestWalk(k) {
    if (k >= 0 && this.walk[k] && !this.blocked(k)) return k; const x0 = k % GW, z0 = (k / GW) | 0;
    for (let r = 1; r < 8; r++) for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) { const n = this.i(x0 + dx, z0 + dz); if (n >= 0 && this.walk[n] && !this.blocked(n)) return n; }
    return -1;
  }
  randomFloorInRoom(ri, R = Math.random) {
    const [x0, z0, x1, z1] = ROOMS[ri].r;
    for (let t = 0; t < 40; t++) { const x = x0 + 0.6 + R() * (x1 - x0 - 1.2), z = z0 + 0.6 + R() * (z1 - z0 - 1.2); const k = this.cellAt(x, z); if (this.walk[k] === 1) return { x, z }; }
    return { x: (x0 + x1) / 2, z: (z0 + z1) / 2 };
  }
}

/* --------- Geometry --------- */
class GeoAcc {
  constructor() { this.p = []; this.n = []; this.uv = []; this.c = []; }
  quad(a, b, c, d, n, uva, uvb, uvc, uvd, ca = 1, cb = 1, cc = 1, cd = 1) {
    // a b c d counter-clockwise when viewed from normal side
    for (const [v, t, col] of [[a, uva, ca], [b, uvb, cb], [c, uvc, cc], [a, uva, ca], [c, uvc, cc], [d, uvd, cd]]) { this.p.push(...v); this.n.push(...n); this.uv.push(...t); this.c.push(col, col, col); }
  }
  geo() { const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(this.p, 3)); g.setAttribute("normal", new THREE.Float32BufferAttribute(this.n, 3)); g.setAttribute("uv", new THREE.Float32BufferAttribute(this.uv, 2)); g.setAttribute("color", new THREE.Float32BufferAttribute(this.c, 3)); g.computeBoundingSphere(); return g; }
}

export function buildMapMeshes(grid, mats) {
  const group = new THREE.Group(); const H = WALL_H;
  const walls = {}, floors = {}; const ceil = new GeoAcc(); const lint = new GeoAcc();
  const acc = (o, k) => (o[k] || (o[k] = new GeoAcc()));
  // corner AO: distance to nearest non-floor
  const aoCorner = (cx, cz) => { // corner index coords
    let best = 9; for (let dz = -3; dz <= 2; dz++) for (let dx = -3; dx <= 2; dx++) { const k = grid.i(cx + dx, cz + dz); const solid = k < 0 || grid.type[k] !== 1; if (solid) { const px = Math.max(cx + dx, Math.min(cx, cx + dx + 1)), pz = Math.max(cz + dz, Math.min(cz, cz + dz + 1)); best = Math.min(best, Math.hypot(px - cx, pz - cz)); } }
    const d = best * CELL; return 0.42 + 0.58 * Math.min(1, Math.pow(d / 1.2, 0.8));
  };
  const ao = new Float32Array((GW + 1) * (GH + 1)); for (let z = 0; z <= GH; z++) for (let x = 0; x <= GW; x++) ao[z * (GW + 1) + x] = aoCorner(x, z);
  const A = (x, z) => ao[z * (GW + 1) + x];
  for (let z = 0; z < GH; z++) for (let x = 0; x < GW; x++) {
    const k = grid.i(x, z); if (grid.type[k] !== 1) continue; const room = ROOMS[grid.room[k]] || ROOMS[5];
    const X0 = x * CELL, X1 = X0 + CELL, Z0 = z * CELL, Z1 = Z0 + CELL;
    const f = acc(floors, room.floor);
    f.quad([X0, 0, Z1], [X1, 0, Z1], [X1, 0, Z0], [X0, 0, Z0], [0, 1, 0], [X0, -Z1], [X1, -Z1], [X1, -Z0], [X0, -Z0], A(x, z + 1), A(x + 1, z + 1), A(x + 1, z), A(x, z));
    ceil.quad([X0, H, Z0], [X1, H, Z0], [X1, H, Z1], [X0, H, Z1], [0, -1, 0], [X0, Z0], [X1, Z0], [X1, Z1], [X0, Z1], 0.8 + A(x, z) * 0.2, 0.8 + A(x + 1, z) * 0.2, 0.8 + A(x + 1, z + 1) * 0.2, 0.8 + A(x, z + 1) * 0.2);
    const w = acc(walls, room.wall);
    const dirs = [[0, -1], [0, 1], [-1, 0], [1, 0]];
    for (const [dx, dz] of dirs) {
      const nk = grid.i(x + dx, z + dz); const nt = nk < 0 ? 0 : grid.type[nk];
      if (nt === 1) {
        // lintel face if neighbor is carved and I'm not (or different lintel)
        if (grid.carved[nk] && !grid.carved[k] && grid.lintel[nk] > 0) addWall(w, x, z, dx, dz, grid.lintel[nk], H);
        continue;
      }
      if (nt === 3) { addWall(w, x, z, dx, dz, 0, 1.0); addWall(w, x, z, dx, dz, 2.1, H); }
      else addWall(w, x, z, dx, dz, 0, H);
    }
    if (grid.carved[k] && grid.lintel[k] > 0) { const y = grid.lintel[k]; lint.quad([X0, y, Z0], [X1, y, Z0], [X1, y, Z1], [X0, y, Z1], [0, -1, 0], [X0, Z0], [X1, Z0], [X1, Z1], [X0, Z1]); }
  }
  function addWall(g, x, z, dx, dz, y0, y1) {
    const X0 = x * CELL, X1 = X0 + CELL, Z0 = z * CELL, Z1 = Z0 + CELL; const v0 = y0 / 3, v1 = y1 / 3;
    const cb = y0 < 0.01 ? 0.55 : 1, ct = y1 > H - 0.01 ? 0.7 : 1;
    if (dz === -1) g.quad([X0, y0, Z0], [X1, y0, Z0], [X1, y1, Z0], [X0, y1, Z0], [0, 0, 1], [X0 / 2, v0], [X1 / 2, v0], [X1 / 2, v1], [X0 / 2, v1], cb, cb, ct, ct);
    if (dz === 1) g.quad([X1, y0, Z1], [X0, y0, Z1], [X0, y1, Z1], [X1, y1, Z1], [0, 0, -1], [-X1 / 2, v0], [-X0 / 2, v0], [-X0 / 2, v1], [-X1 / 2, v1], cb, cb, ct, ct);
    if (dx === -1) g.quad([X0, y0, Z1], [X0, y0, Z0], [X0, y1, Z0], [X0, y1, Z1], [1, 0, 0], [-Z1 / 2, v0], [-Z0 / 2, v0], [-Z0 / 2, v1], [-Z1 / 2, v1], cb, cb, ct, ct);
    if (dx === 1) g.quad([X1, y0, Z0], [X1, y0, Z1], [X1, y1, Z1], [X1, y1, Z0], [-1, 0, 0], [Z0 / 2, v0], [Z1 / 2, v0], [Z1 / 2, v1], [Z0 / 2, v1], cb, cb, ct, ct);
  }
  // window reveals
  for (let z = 0; z < GH; z++) for (let x = 0; x < GW; x++) {
    const k = grid.i(x, z); if (grid.type[k] !== 3) continue; const w = acc(walls, "main");
    const X0 = x * CELL, X1 = X0 + CELL, Z0 = z * CELL, Z1 = Z0 + CELL;
    for (const [dx, dz] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) { const nk = grid.i(x + dx, z + dz); if (nk >= 0 && grid.type[nk] === 2) addWall(w, x, z, dx, dz, 1.0, 2.1); }
    lint.quad([X0, 1.0, Z1], [X1, 1.0, Z1], [X1, 1.0, Z0], [X0, 1.0, Z0], [0, 1, 0], [X0, Z1], [X1, Z1], [X1, Z0], [X0, Z0]);
    lint.quad([X0, 2.1, Z0], [X1, 2.1, Z0], [X1, 2.1, Z1], [X0, 2.1, Z1], [0, -1, 0], [X0, Z0], [X1, Z0], [X1, Z1], [X0, Z1]);
  }
  const meshes = [];
  for (const k in floors) { const m = new THREE.Mesh(floors[k].geo(), mats.floor[k]); m.receiveShadow = true; group.add(m); meshes.push(m); }
  for (const k in walls) { const m = new THREE.Mesh(walls[k].geo(), mats.wall[k]); m.receiveShadow = true; m.castShadow = true; group.add(m); meshes.push(m); }
  const cm = new THREE.Mesh(ceil.geo(), mats.ceiling); cm.receiveShadow = true; group.add(cm);
  const lm = new THREE.Mesh(lint.geo(), mats.trim); group.add(lm);
  return { group, meshes };
}
