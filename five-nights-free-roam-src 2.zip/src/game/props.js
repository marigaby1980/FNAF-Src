import * as THREE from "three";
import { RoundedBoxGeometry } from "./RoundedBox.js";
import { FIXTURES, BREAKERS, WALL_H } from "./map.js";
import { buildAnimatronic, animateRig } from "./characters.js";
import { rng } from "./noise.js";

export function buildProps(grid, M, T) {
  const root = new THREE.Group(); const R = rng(1984);
  const out = { group: root, interact: [], fixtures: [], fans: [], doors: [], breakers: [], buttons: {}, crt: [], spots: [] };
  const add = (m, p, r = 0, parent = root, shadow = true) => { m.position.set(p[0], p[1], p[2]); m.rotation.y = r; m.castShadow = shadow; m.receiveShadow = true; parent.add(m); return m; };
  const box = (w, h, d, mat, x, y, z, r = 0, parent) => add(new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat), [x, y, z], r, parent);
  const rbox = (w, h, d, rad, mat, x, y, z, r = 0, parent) => add(new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, rad), mat), [x, y, z], r, parent);
  const cyl = (rt, rb, h, mat, x, y, z, seg = 20, parent) => add(new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat), [x, y, z], 0, parent);
  const grp = (x, y, z, r = 0, parent = root) => { const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = r; parent.add(g); return g; };
  const plane = (w, h, mat, x, y, z, r = 0, parent) => add(new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat), [x, y, z], r, parent, false);

  /* ---------- instanced chairs ---------- */
  const chairMats = []; const tmp = new THREE.Object3D();
  const chair = (x, z, r) => chairMats.push([x, z, r]);
  const flushChairs = () => {
    const parts = [
      [new RoundedBoxGeometry(0.44, 0.06, 0.42, 2, 0.02), M.plasticRed, [0, 0.46, 0]],
      [new RoundedBoxGeometry(0.44, 0.42, 0.05, 2, 0.02), M.plasticRed, [0, 0.72, -0.2]],
      [new THREE.CylinderGeometry(0.015, 0.015, 0.46, 6), M.chrome, [0.19, 0.23, 0.18]], [new THREE.CylinderGeometry(0.015, 0.015, 0.46, 6), M.chrome, [-0.19, 0.23, 0.18]],
      [new THREE.CylinderGeometry(0.015, 0.015, 0.95, 6), M.chrome, [0.19, 0.47, -0.19]], [new THREE.CylinderGeometry(0.015, 0.015, 0.95, 6), M.chrome, [-0.19, 0.47, -0.19]],
    ];
    for (const [g, mat, off] of parts) {
      const im = new THREE.InstancedMesh(g, mat, chairMats.length); im.castShadow = true; im.receiveShadow = true;
      chairMats.forEach(([x, z, r], i) => { tmp.position.set(x, 0, z); tmp.rotation.set(0, r, 0); tmp.updateMatrix(); const o = new THREE.Matrix4().makeTranslation(off[0], off[1], off[2]); im.setMatrixAt(i, tmp.matrix.clone().multiply(o)); });
      root.add(im);
    }
  };
  const hats = []; const plates = [];

  /* ---------- DINING ---------- */
  for (const x of [10.5, 16, 21.5]) for (const z of [12.4, 18.2]) {
    rbox(1.12, 0.06, 3.5, 0.02, M.cloth, x, 0.76, z); box(1.14, 0.34, 3.52, M.cloth, x, 0.59, z).castShadow = true;
    for (let i = 0; i < 4; i++) { const dz = -1.2 + i * 0.8; chair(x - 0.8, z + dz, Math.PI / 2); chair(x + 0.8, z + dz, -Math.PI / 2); hats.push([x - 0.3, z + dz]); hats.push([x + 0.3, z + dz + 0.1]); plates.push([x - 0.3, z + dz + 0.2], [x + 0.3, z + dz - 0.15]); }
    grid.blockRect(x - 0.95, z - 1.9, x + 0.95, z + 1.9);
  }
  // booths along south wall
  for (let bx = 12; bx < 21; bx += 3) {
    rbox(2.6, 0.45, 0.6, 0.06, M.vinyl, bx + 1.3, 0.3, 21.55); rbox(2.6, 0.75, 0.2, 0.06, M.vinyl, bx + 1.3, 0.85, 21.9);
    rbox(2.2, 0.05, 0.7, 0.02, M.darkWood, bx + 1.3, 0.75, 20.9); cyl(0.05, 0.12, 0.72, M.chrome, bx + 1.3, 0.36, 20.9, 10);
  }
  grid.blockRect(12, 20.4, 21, 22);
  // party hats instanced
  { const g = new THREE.ConeGeometry(0.06, 0.18, 14); M.hat.forEach((mat, mi) => { const list = hats.filter((_, i) => i % M.hat.length === mi); const im = new THREE.InstancedMesh(g, mat, list.length); list.forEach(([x, z], i) => { tmp.position.set(x, 0.88, z); tmp.rotation.set(0, 0, (R() - 0.5) * 0.2); tmp.updateMatrix(); im.setMatrixAt(i, tmp.matrix); }); im.castShadow = true; root.add(im); }); }
  { const g = new THREE.CylinderGeometry(0.11, 0.08, 0.02, 20); const im = new THREE.InstancedMesh(g, M.plasticWhite, plates.length); plates.forEach(([x, z], i) => { tmp.position.set(x, 0.8, z); tmp.rotation.set(0, 0, 0); tmp.updateMatrix(); im.setMatrixAt(i, tmp.matrix); }); root.add(im); }

  /* ---------- STAGE ---------- */
  box(10, 0.6, 3.3, M.stageFront, 16, 0.3, 4.65); box(10, 0.04, 3.3, M.floor.wood, 16, 0.62, 4.65);
  { const g = new THREE.CylinderGeometry(2.6, 2.6, 0.6, 40, 1, false, -Math.PI / 2, Math.PI); const m = add(new THREE.Mesh(g, M.stageFront), [16, 0.3, 6.3]); m.rotation.y = 0;
    const top = new THREE.Mesh(new THREE.CircleGeometry(2.6, 40, 0, Math.PI), M.floor.wood); top.rotation.x = -Math.PI / 2; top.position.set(16, 0.605, 6.3); root.add(top); top.receiveShadow = true; }
  grid.setHeight(11, 3, 21, 6.3, 0.6);
  for (let z = 6.3; z < 8.9; z += 0.25) for (let x = 13.4; x < 18.6; x += 0.25) if (Math.hypot(x - 16, z - 6.3) < 2.5) grid.setHeight(x, z, x + 0.25, z + 0.25, 0.6);
  // backdrop curtain with folds
  { const g = new THREE.PlaneGeometry(10, 3, 120, 1); const p = g.attributes.position; for (let i = 0; i < p.count; i++) p.setZ(i, Math.sin(p.getX(i) * 7) * 0.06 + Math.sin(p.getX(i) * 2.3) * 0.03); g.computeVertexNormals();
    const m = new THREE.Mesh(g, M.curtain); m.position.set(16, 1.5, 3.12); m.receiveShadow = true; root.add(m); }
  plane(5.2, 1.3, M.signs.signCelebrate, 16, 2.45, 3.25);
  for (const sx of [11.6, 20.4]) { rbox(0.8, 1.3, 0.6, 0.03, M.speaker, sx, 1.25, 3.9); for (const y of [0.95, 1.45]) { const c = new THREE.Mesh(new THREE.CircleGeometry(0.22, 24), M.darkMetal); c.position.set(sx, y, 4.21); root.add(c); } }
  // mic stand + guitar
  cyl(0.012, 0.012, 1.4, M.chrome, 17.1, 1.3, 6.0, 8); cyl(0.15, 0.15, 0.02, M.chrome, 17.1, 0.63, 6.0);
  { const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.lineTo(-0.28, -0.55); sh.lineTo(-0.16, -0.58); sh.lineTo(0, -0.26); sh.lineTo(0.16, -0.58); sh.lineTo(0.28, -0.55); sh.closePath();
    const gt = grp(11.2, 0.95, 4.4, 0.4); gt.visible = false; gt.rotation.z = 0.15; const body = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: 0.05, bevelEnabled: true, bevelSize: 0.01, bevelThickness: 0.01 }), new THREE.MeshPhysicalMaterial({ color: 0xa3141a, roughness: 0.25, clearcoat: 1 })); body.castShadow = true; gt.add(body);
    box(0.05, 0.6, 0.03, M.darkWood, 0, 0.3, 0.03, 0, gt); box(0.08, 0.12, 0.03, M.plasticBlack, 0, 0.64, 0.03, 0, gt); }
  // stage light cans
  for (const sx of [13, 16, 19]) { const g = grp(sx, 2.8, 6.5); cyl(0.12, 0.15, 0.3, M.plasticBlack, 0, 0, 0, 16, g).rotation.x = 0.6; }

  /* ---------- PIRATE COVE ---------- */
  box(3, 0.3, 7.5, M.stageFront, 2, 0.15, 17.75); box(3, 0.02, 7.5, M.floor.wood, 2, 0.31, 17.75); grid.setHeight(0.5, 14, 3.5, 21.5, 0.3);
  for (const [z0, z1] of [[15, 17.85], [18.15, 21]]) { const w = z1 - z0; const g = new THREE.PlaneGeometry(w, 2.7, 60, 1); const p = g.attributes.position; for (let i = 0; i < p.count; i++) p.setZ(i, Math.sin(p.getX(i) * 9) * 0.05); g.computeVertexNormals(); const m = new THREE.Mesh(g, M.curtain); m.position.set(3.7, 1.35, (z0 + z1) / 2); m.rotation.y = Math.PI / 2; m.castShadow = true; m.receiveShadow = true; root.add(m); }
  { const g = grp(5.4, 0, 16.2, Math.PI / 2 + 0.3); box(0.9, 0.5, 0.04, M.signs.signCove, 0, 1.1, 0, 0, g); const f = box(0.95, 0.55, 0.03, M.darkWood, 0, 1.1, -0.03, 0, g); cyl(0.02, 0.02, 0.9, M.darkWood, -0.35, 0.45, -0.03, 6, g); cyl(0.02, 0.02, 0.9, M.darkWood, 0.35, 0.45, -0.03, 6, g); }
  grid.blockRect(5.1, 15.8, 5.7, 16.6);

  /* ---------- RESTROOMS ---------- */
  for (let i = 0; i < 5; i++) { const x = 1.6 + i * 1.3; box(0.05, 1.8, 1.6, M.plasticWhite, x, 1.05, 1.3); }
  for (let i = 0; i < 4; i++) { const x = 2.25 + i * 1.3; rbox(0.4, 0.45, 0.55, 0.12, M.plasticWhite, x, 0.23, 0.9); rbox(0.44, 0.4, 0.2, 0.05, M.plasticWhite, x, 0.65, 0.62); const d = box(0.05, 1.6, 0.6, M.plasticWhite, x - 0.2, 1.0, 2.35); d.rotation.y = 0.6 + R() * 0.6; }
  box(6.6, 0.05, 1.6, M.plasticWhite, 4.2, 1.96, 1.3).visible = false;
  grid.blockRect(1, 0.5, 7, 2.2);
  for (let i = 0; i < 3; i++) { const z = 3.5 + i * 1.2; rbox(0.5, 0.2, 0.6, 0.05, M.plasticWhite, 1.3, 0.85, z); cyl(0.07, 0.1, 0.8, M.plasticWhite, 1.25, 0.4, z, 12); }
  box(0.02, 0.9, 3.6, new THREE.MeshStandardMaterial({ color: 0x9aa0a0, metalness: 1, roughness: 0.12 }), 1.02, 1.6, 4.7); grid.blockRect(1, 3, 1.6, 6.2);
  box(0.12, 2.2, 3.2, M.plasticWhite, 6.0, 1.1, 5.9); grid.blockRect(5.9, 4.3, 6.1, 7.5);

  /* ---------- KITCHEN ---------- */
  box(6.6, 0.9, 0.7, M.darkMetal, 34.2, 0.45, 3.4); box(6.7, 0.05, 0.75, M.metal, 34.2, 0.92, 3.4);
  rbox(0.9, 2.0, 0.75, 0.03, M.metal, 31.1, 1.0, 3.45); box(1.2, 0.5, 0.9, M.darkMetal, 35.5, 2.3, 3.5);
  for (const [x, r] of [[34.6, 0.12], [35.1, 0.1], [36.4, 0.14]]) cyl(r, r, 0.14, M.darkMetal, x, 1.02, 3.4, 16);
  box(3.2, 0.9, 0.8, M.darkMetal, 34.2, 0.45, 5.45); box(3.3, 0.05, 0.9, M.metal, 34.2, 0.92, 5.45);
  for (let i = 0; i < 5; i++) cyl(0.08, 0.06, 0.1, M.plasticWhite, 33 + i * 0.6, 1.0, 5.4 + (R() - 0.5) * 0.3, 12);
  grid.blockRect(30.5, 3, 38, 3.8); grid.blockRect(32.6, 5.0, 35.8, 5.9);

  /* ---------- BACKSTAGE ---------- */
  const shelf = (x, z, w, r = 0, levels = 3) => { const g = grp(x, 0, z, r); for (let l = 0; l < levels; l++) box(w, 0.04, 0.5, M.darkMetal, 0, 0.3 + l * 0.6, 0, 0, g); for (const sx of [-w / 2, w / 2]) for (const sz of [-0.23, 0.23]) box(0.04, 0.3 + levels * 0.6, 0.04, M.darkMetal, sx, (0.3 + levels * 0.6) / 2, sz, 0, g); return g; };
  const bs = shelf(25.5, 0.85, 5.5);
  ["freddy", "bonnie", "chica", "fredbear"].forEach((k, i) => { const rig = buildAnimatronic(k, T); const h = rig.head; h.removeFromParent(); h.position.set(-2 + i * 1.3, 0.94 - (k === "bonnie" ? 0.05 : 0), 0); h.rotation.set(0.1, (R() - 0.5) * 0.6, (R() - 0.5) * 0.2); h.scale.setScalar(0.95); bs.add(h); if (rig.setGlow) h.traverse((o) => { if (o.material === rig.eyes?.[0]?.userData.glow.material) o.visible = false; }); });
  for (let i = 0; i < 6; i++) rbox(0.5, 0.35, 0.4, 0.02, M.cardboard, 23.2 + i * 0.8, 0.52 + (i % 2) * 0.6 + 0.6, 0.85);
  grid.blockRect(22.5, 0.5, 28.5, 1.2);
  box(2.4, 0.06, 1.0, M.darkWood, 26.5, 0.9, 6.3); for (const [dx, dz] of [[-1.1, -0.4], [1.1, -0.4], [-1.1, 0.4], [1.1, 0.4]]) box(0.06, 0.9, 0.06, M.darkMetal, 26.5 + dx, 0.45, 6.3 + dz);
  { const endo = buildAnimatronic("freddy", T); endo.root.traverse((o) => { if (o.isMesh && o.material.sheen !== undefined && o.material.sheen > 0) o.visible = false; }); endo.root.position.set(26.5, 0.94, 6.3); endo.root.rotation.set(-Math.PI / 2, 0, 0.3); endo.root.scale.setScalar(0.8); root.add(endo.root); }
  grid.blockRect(25.2, 5.7, 27.8, 6.9);
  for (let i = 0; i < 4; i++) rbox(0.6, 0.5, 0.5, 0.02, M.cardboard, 22.3 + (i % 2) * 0.7, 0.25 + ((i / 2) | 0) * 0.5, 6.9);
  grid.blockRect(21.9, 6.5, 23.1, 7.5);

  /* ---------- PARTY ROOMS ---------- */
  const roundTable = (x, z) => { rbox(1.3, 0.05, 1.3, 0.3, M.cloth, x, 0.75, z); cyl(0.66, 0.66, 0.3, M.cloth, x, 0.6, z, 32); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + 0.4; chair(x + Math.sin(a) * 0.95, z + Math.cos(a) * 0.95, a + Math.PI); } for (let i = 0; i < 3; i++) hats.push([x + (R() - 0.5) * 0.6, z + (R() - 0.5) * 0.6]); grid.blockRect(x - 1.0, z - 1.0, x + 1.0, z + 1.0); };
  const balloons = (x, z, n = 4) => { for (let i = 0; i < n; i++) { const bx = x + (R() - 0.5) * 0.5, bz = z + (R() - 0.5) * 0.5, by = 1.9 + R() * 0.5; const b = add(new THREE.Mesh(new THREE.SphereGeometry(0.16, 20, 14), M.balloon[i % 4]), [bx, by, bz]); b.scale.y = 1.2; const s = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, by - 0.8, 4), M.plasticWhite); s.position.set((bx + x) / 2, (by + 0.8) / 2, (bz + z) / 2); root.add(s); } };
  const present = (x, z, s = 0.4) => { const m = M.present[(R() * 3) | 0]; rbox(s, s * 0.8, s, 0.02, m, x, s * 0.4, z, R()); };
  roundTable(31.8, 11.2); roundTable(35.5, 14.2); balloons(31.8, 11.2); balloons(35.5, 14.2, 3); present(36.8, 9.2); present(37.2, 9.8, 0.3);
  roundTable(31.8, 20.2); roundTable(35.6, 22.3); balloons(35.6, 22.3); present(30, 23.6);
  roundTable(32.2, 36.2); roundTable(36.2, 40.5); balloons(32.2, 36.2, 5); present(38.8, 34, 0.5); present(38.9, 34.7, 0.3);
  rbox(1.0, 0.05, 3.4, 0.02, M.cloth, 32.2, 0.76, 42.5); box(1.02, 0.3, 3.42, M.cloth, 32.2, 0.6, 42.5); for (let i = 0; i < 4; i++) { chair(31.4, 41.2 + i * 0.85, Math.PI / 2); chair(33, 41.2 + i * 0.85, -Math.PI / 2); } grid.blockRect(31.3, 40.7, 33.1, 44.3);

  /* ---------- ARCADE ---------- */
  const cabinet = (x, z, r, i) => {
    const g = grp(x, 0, z, r); box(0.74, 1.8, 0.75, M.cabinet, 0, 0.9, 0, 0, g);
    const scr = plane(0.56, 0.44, M.arcade[i % M.arcade.length], 0, 1.35, 0.33, 0, g); scr.rotation.x = -0.18;
    box(0.74, 0.22, 0.2, M.marquee[i % 4], 0, 1.72, 0.3, 0, g); const cp = box(0.74, 0.08, 0.3, M.cabinet, 0, 1.0, 0.45, 0, g); cp.rotation.x = 0.25;
    cyl(0.018, 0.018, 0.08, M.plasticBlack, -0.15, 1.08, 0.45, 8, g); for (let b = 0; b < 3; b++) cyl(0.022, 0.022, 0.02, M.marquee[(b + i) % 4], 0.05 + b * 0.08, 1.05, 0.46, 12, g);
    out.crt.push(scr);
  };
  let ci = 0;
  for (let x = 12.5; x <= 20.5; x += 1) cabinet(x, 23.0, 0, ci++); grid.blockRect(12, 22.5, 21, 23.5);
  for (const x0 of [9, 22]) { for (let k = 0; k < 4; k++) { cabinet(x0 + k * 0.8, 29.2, Math.PI, ci++); cabinet(x0 + k * 0.8, 30.0, 0, ci++); } grid.blockRect(x0 - 0.45, 28.7, x0 + 2.85, 30.5); }
  // prize counter
  box(0.7, 1.0, 5, M.cabinet, 7.2, 0.5, 34); box(0.8, 0.05, 5.1, M.darkWood, 7.2, 1.02, 34); box(0.6, 1.0, 4.8, new THREE.MeshStandardMaterial({ color: 0x3a1f4a, roughness: 0.6 }), 7.2, 0.5, 34);
  const glassTop = box(0.7, 0.4, 5, M.glass, 7.2, 1.25, 34); glassTop.castShadow = false;
  const ps = shelf(5.85, 34, 4.6, Math.PI / 2, 4);
  ["freddy", "bonnie", "chica", "foxy"].forEach((k, i) => { for (let j = 0; j < 1; j++) { const pl = buildAnimatronic(k, T); pl.root.scale.setScalar(0.17); pl.root.position.set(-1.5 + i * 1.0, 0.93 + (i % 2) * 0.6, 0); pl.root.rotation.y = 0; animateRig(pl, 1, { speed: 0, state: "idle" }); ps.add(pl.root); } });
  plane(3, 0.75, M.signs.signPrize, 5.52, 2.55, 34, Math.PI / 2);
  grid.blockRect(5.5, 31.4, 7.6, 36.6);
  // central kiosk
  cyl(1.2, 1.25, 1.0, M.cabinet, 19.5, 0.5, 35.5, 40); cyl(1.3, 1.3, 0.06, M.darkWood, 19.5, 1.03, 35.5, 40); cyl(0.12, 0.12, 1.9, M.chrome, 19.5, 2.0, 35.5, 12);
  { const f = buildAnimatronic("fredbear", T); f.root.scale.setScalar(0.45); f.root.position.set(19.5, 1.06, 35.5); f.root.rotation.y = Math.PI * 0.85; animateRig(f, 1, { speed: 0, state: "pose" }); root.add(f.root); }
  grid.blockRect(18.2, 34.2, 20.8, 36.8);
  for (const x of [26.5, 27.3]) { cyl(0.2, 0.25, 0.8, M.plasticRed, x, 0.4, 38.8, 16); const gm = add(new THREE.Mesh(new THREE.SphereGeometry(0.24, 20, 14), M.glass), [x, 1.02, 38.8]); gm.castShadow = false; for (let k = 0; k < 14; k++) add(new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), M.balls[k % 5]), [x + (R() - 0.5) * 0.3, 0.9 + R() * 0.15, 38.8 + (R() - 0.5) * 0.3]); }
  grid.blockRect(26.2, 38.5, 27.6, 39.1);

  /* ---------- BALL PIT ---------- */
  const pit = [30, 26, 35, 30.5];
  for (const [x, z, w, d] of [[32.5, 26, 5, 0.15], [32.5, 30.5, 5, 0.15], [30, 28.25, 0.15, 4.5], [35, 28.25, 0.15, 4.5]]) rbox(w, 0.55, d, 0.05, M.vinyl, x, 0.275, z);
  for (const [x, z] of [[30, 26], [35, 26], [30, 30.5], [35, 30.5]]) cyl(0.05, 0.05, 2.2, M.plasticRed, x, 1.1, z, 10);
  { const n = 700; const g = new THREE.SphereGeometry(0.075, 10, 8); M.balls.forEach((mat, mi) => { const cnt = n / 5; const im = new THREE.InstancedMesh(g, mat, cnt); for (let i = 0; i < cnt; i++) { tmp.position.set(pit[0] + 0.15 + R() * 4.7, 0.05 + R() * 0.42, pit[1] + 0.15 + R() * 4.2); tmp.updateMatrix(); im.setMatrixAt(i, tmp.matrix); } im.castShadow = false; im.receiveShadow = true; root.add(im); }); }
  { const curve = new THREE.CatmullRomCurve3([new THREE.Vector3(36.8, 2.3, 26.6), new THREE.Vector3(37.2, 1.7, 28), new THREE.Vector3(36.3, 1.1, 29.5), new THREE.Vector3(35.4, 0.6, 29.2)]); const t = new THREE.Mesh(new THREE.TubeGeometry(curve, 40, 0.38, 16, false), new THREE.MeshPhysicalMaterial({ color: 0x2c6fd8, roughness: 0.3, clearcoat: 1, side: THREE.DoubleSide })); t.castShadow = true; root.add(t); box(1.2, 0.08, 1.2, M.plasticRed, 36.8, 2.3, 26.4); for (const [dx, dz] of [[-0.55, -0.55], [0.55, -0.55], [-0.55, 0.55], [0.55, 0.55]]) cyl(0.05, 0.05, 2.3, M.plasticRed, 36.8 + dx, 1.15, 26.4 + dz, 8); }
  grid.blockRect(29.8, 25.8, 35.2, 30.7); grid.blockRect(35.4, 25.5, 38, 30.2);

  /* ---------- STORAGE / PARTS & SERVICE ---------- */
  shelf(1.1, 44.5, 5, Math.PI / 2); shelf(5, 48.6, 3.2);
  for (let i = 0; i < 10; i++) rbox(0.45 + R() * 0.2, 0.35, 0.4, 0.02, M.cardboard, 1.1, 0.5 + (i % 3) * 0.6, 42.4 + i * 0.42 + R() * 0.1, Math.PI / 2 + (R() - 0.5) * 0.2);
  grid.blockRect(0.5, 41.8, 1.5, 47.2); grid.blockRect(3.3, 48.2, 6.7, 49);
  { const fb = buildAnimatronic("fredbear", T); fb.root.position.set(8.4, 0, 48.2); fb.root.rotation.y = Math.PI + 0.35; animateRig(fb, 1, { speed: 0, state: "slumped" }); for (let i = 0; i < 40; i++) animateRig(fb, 0.1, { speed: 0, state: "slumped" }); root.add(fb.root); out.fredbear = fb; }
  grid.blockRect(7.6, 47.4, 9.4, 49);
  box(2.2, 0.06, 1.0, M.darkWood, 6, 0.9, 43.2); for (const [dx, dz] of [[-1, -0.4], [1, -0.4], [-1, 0.4], [1, 0.4]]) box(0.06, 0.9, 0.06, M.darkMetal, 6 + dx, 0.45, 43.2 + dz);
  { const r2 = buildAnimatronic("bonnie", T); const h = r2.head; h.removeFromParent(); h.position.set(5.6, 0.95, 43.2); h.rotation.set(0, 0.8, 1.3); root.add(h); }
  grid.blockRect(4.8, 42.6, 7.2, 43.8);
  plane(1.2, 0.6, M.signs.signParts, 10.02 + 0.3, 2.45, 41.75, Math.PI / 2);

  /* ---------- OFFICE ---------- */
  rbox(4.8, 0.06, 1.0, 0.01, M.darkWood, 20, 0.8, 48.45); box(4.8, 0.76, 0.9, new THREE.MeshStandardMaterial({ color: 0x1a1718, roughness: 0.7 }), 20, 0.4, 48.5);
  const crt = (x, y, z, s, r = 0) => { const g = grp(x, y, z, r); rbox(0.5 * s, 0.42 * s, 0.45 * s, 0.03, new THREE.MeshStandardMaterial({ color: 0x2a2826, roughness: 0.6 }), 0, 0.21 * s, 0, 0, g); const sc = plane(0.38 * s, 0.3 * s, M.crtStatic, 0, 0.22 * s, 0.226 * s, 0, g); out.crt.push(sc); for (let b = 0; b < 4; b++) cyl(0.01 * s, 0.01 * s, 0.01, M.plasticWhite, 0.18 * s, 0.1 * s + b * 0.035 * s, 0.226 * s, 8, g).rotation.x = Math.PI / 2; return g; };
  crt(18.2, 0.83, 48.35, 1.2, 0.25); crt(18.25, 1.34, 48.4, 0.95, 0.25); crt(18.9, 0.83, 48.5, 0.9, 0.1); crt(21.6, 0.83, 48.4, 0.95, -0.3); crt(21.5, 1.23, 48.45, 0.75, -0.3);
  { const g = grp(20.1, 0.83, 48.5, Math.PI); cyl(0.08, 0.1, 0.05, M.darkMetal, 0, 0.03, 0, 16, g); cyl(0.02, 0.02, 0.3, M.darkMetal, 0, 0.2, 0, 8, g); const head = grp(0, 0.4, 0, 0, g); const cage = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.008, 6, 32), M.darkMetal); head.add(cage); for (let k = 0; k < 8; k++) { const sp = new THREE.Mesh(new THREE.BoxGeometry(0.005, 0.4, 0.005), M.darkMetal); sp.rotation.z = k * Math.PI / 8; head.add(sp); } const blades = grp(0, 0, 0.02, 0, head); for (let k = 0; k < 3; k++) { const b = new THREE.Mesh(new THREE.CircleGeometry(0.16, 12, 0, 0.8), new THREE.MeshStandardMaterial({ color: 0x2a2a2c, metalness: 0.6, roughness: 0.4, side: THREE.DoubleSide })); b.rotation.z = k * Math.PI * 2 / 3; blades.add(b); } out.fans.push(blades); blades.userData.dyn = true; head.rotation.y = 0; }
  for (let i = 0; i < 4; i++) { const p = box(0.21, 0.003, 0.29, M.paper, 19.4 + R() * 1.4, 0.834, 48.2 + R() * 0.2); p.rotation.y = R() * 0.8 - 0.4; }
  cyl(0.04, 0.035, 0.1, new THREE.MeshStandardMaterial({ color: 0xc8c0b0, roughness: 0.4 }), 21.0, 0.88, 48.15, 14);
  rbox(0.22, 0.08, 0.18, 0.02, M.plasticBlack, 20.9, 0.87, 48.6);
  plane(0.9, 1.26, M.poster, 18.6, 1.9, 48.98, Math.PI); for (let i = 0; i < 5; i++) { const d = plane(0.3, 0.38, M.drawings[i], 19.6 + i * 0.42 + (R() - 0.5) * 0.08, 1.75 + (R() - 0.5) * 0.3, 48.97, Math.PI); d.rotation.z = (R() - 0.5) * 0.3; }
  { const g = grp(20, 0, 47.1, Math.PI); cyl(0.25, 0.25, 0.08, M.vinyl, 0, 0.48, 0, 20, g); rbox(0.44, 0.5, 0.08, 0.04, M.vinyl, 0, 0.8, -0.24, 0, g); cyl(0.03, 0.03, 0.45, M.chrome, 0, 0.23, 0, 8, g); }
  grid.blockRect(17.5, 47.9, 22.5, 49);
  // window
  { const gl = box(4, 1.1, 0.02, M.glass, 20, 1.55, 43.25); gl.castShadow = false; for (const x of [18, 20, 22]) box(0.06, 1.15, 0.5, M.trim, x, 1.55, 43.25); box(4.1, 0.06, 0.55, M.trim, 20, 1.02, 43.25); box(4.1, 0.06, 0.55, M.trim, 20, 2.1, 43.25); }
  plane(1.2, 0.6, M.signs.signOffice, 20, 2.5, 42.98, Math.PI);
  // security doors
  grid.secDoors.forEach((d, i) => {
    const x = d.side === "L" ? 16.75 : 23.25; const g = grp(x, 0, d.z, Math.PI / 2);
    for (const s of [-1, 1]) box(0.14, 2.3, 0.6, M.hazard, s * 1.07, 1.15, 0, 0, g);
    box(2.28, 0.25, 0.6, M.hazard, 0, 2.42, 0, 0, g);
    const panel = grp(0, 0, 0, 0, g); box(2.0, 2.3, 0.1, M.doorMetal, 0, 1.15, 0, 0, panel); const stripe = box(2.0, 0.28, 0.105, M.hazard, 0, 0.18, 0, 0, panel);
    panel.position.y = 2.35; d.mesh = panel; panel.userData.dyn = true; out.doors.push(d);
    // button panel inside office
    const bx = d.side === "L" ? 17.02 : 22.98, br = d.side === "L" ? Math.PI / 2 : -Math.PI / 2;
    const bp = grp(bx, 1.3, 44.75, br); box(0.22, 0.5, 0.04, M.darkMetal, 0, 0, 0, 0, bp);
    const doorBtn = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.04, 16), new THREE.MeshStandardMaterial({ color: 0x5a1010, emissive: 0xff2010, emissiveIntensity: 0.3 })); doorBtn.rotation.x = Math.PI / 2; doorBtn.position.set(0, 0.1, 0.03); bp.add(doorBtn);
    const lightBtn = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.04, 16), new THREE.MeshStandardMaterial({ color: 0x505050, emissive: 0xfff0d0, emissiveIntensity: 0.1 })); lightBtn.rotation.x = Math.PI / 2; lightBtn.position.set(0, -0.1, 0.03); bp.add(lightBtn);
    out.buttons[d.side] = { doorBtn, lightBtn };
    out.interact.push({ kind: "door", side: d.side, x: bx + (d.side === "L" ? 0.1 : -0.1), y: 1.3, z: 44.75, label: "Toggle door" });
    out.interact.push({ kind: "hallLight", side: d.side, x: bx + (d.side === "L" ? 0.1 : -0.1), y: 1.2, z: 44.75, label: "Hall light" });
  });
  out.interact.push({ kind: "cams", x: 20, y: 1.0, z: 48.1, label: "Use cameras" });

  /* ---------- POSTERS IN HALLS ---------- */
  const poster = (mat, x, y, z, r, w = 0.8, h = 1.1) => { const p = plane(w, h, mat, x, y, z, r); p.rotation.z = (R() - 0.5) * 0.05; };
  poster(M.poster, 0.52, 1.8, 30, Math.PI / 2); poster(M.drawings[0], 0.52, 1.6, 34, Math.PI / 2, 0.3, 0.38); poster(M.drawings[2], 0.52, 1.7, 34.5, Math.PI / 2, 0.3, 0.38);
  poster(M.poster, 40.98, 1.8, 12, -Math.PI / 2); poster(M.drawings[1], 40.98, 1.6, 18, -Math.PI / 2, 0.3, 0.38); poster(M.drawings[3], 40.98, 1.7, 18.5, -Math.PI / 2, 0.3, 0.38);
  poster(M.poster, 14, 1.8, 40.52, 0); poster(M.poster, 26, 1.8, 40.52, 0); poster(M.poster, 13.5, 1.8, 48.98, Math.PI); poster(M.poster, 26, 1.8, 48.98, Math.PI);
  poster(M.poster, 4.02, 1.9, 13, Math.PI / 2); poster(M.logo, 28.48, 2.0, 17.5, -Math.PI / 2, 0.8, 0.8); poster(M.logo, 16, 2.2, 21.98, Math.PI, 0.9, 0.9);
  for (let i = 0; i < 6; i++) poster(M.drawings[i % 5], 7 + i * 0.5, 1.6 + (R() - 0.5) * 0.3, 8.02, 0, 0.3, 0.38);

  /* ---------- BREAKERS ---------- */
  BREAKERS.forEach((b) => {
    const g = grp(b.x, 1.35, b.z, b.yaw); rbox(0.42, 0.58, 0.12, 0.01, new THREE.MeshStandardMaterial({ ...T.metal, color: 0x6a6e6a, metalness: 0.7, roughness: 1 }), 0, 0, 0, 0, g);
    box(0.36, 0.1, 0.02, M.hazard, 0, 0.2, 0.065, 0, g);
    const lever = grp(0, -0.05, 0.07, 0, g); box(0.04, 0.2, 0.04, M.plasticRed, 0, 0.08, 0.02, 0, lever); lever.rotation.x = -0.5; lever.userData.dyn = true;
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.018, 10, 8), M.ledGreen); led.position.set(0.14, -0.2, 0.07); g.add(led); led.userData.dyn = true;
    const bb = { ...b, mesh: g, lever, led, cooldown: 0, jam: 0 }; out.breakers.push(bb);
    out.interact.push({ kind: "breaker", ref: bb, x: b.x, y: 1.35, z: b.z, label: "Reset breaker (hold)" });
  });

  /* ---------- FIXTURES ---------- */
  FIXTURES.forEach(([x, z, kind], i) => {
    const g = grp(x, WALL_H, z); let mat;
    if (kind === "warm" || kind === "office" || kind === "dim") {
      mat = M.fixtureOn.clone(); cyl(0.01, 0.01, 0.5, M.darkMetal, 0, -0.25, 0, 6, g);
      const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.32, 0.22, 24, 1, true), new THREE.MeshStandardMaterial({ color: 0x1f2a22, metalness: 0.6, roughness: 0.5, side: THREE.DoubleSide })); sh.position.y = -0.58; g.add(sh);
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.07, 14, 10), mat); bulb.position.y = -0.64; g.add(bulb);
    } else if (kind === "stage") { mat = M.fixtureOn.clone(); }
    else {
      mat = M.fixtureFluo.clone(); box(1.25, 0.08, 0.32, M.plasticWhite, 0, -0.04, 0, 0, g); const tube = box(1.15, 0.02, 0.24, mat, 0, -0.085, 0, 0, g); tube.castShadow = false;
    }
    out.fixtures.push({ x, z, kind, mat, base: mat.emissiveIntensity, y: kind === "fluo" || kind === "broken" ? WALL_H - 0.15 : kind === "stage" ? 2.7 : WALL_H - 0.72 });
  });

  flushChairs();
  bakeStatic(root);
  // hats added after round tables
  { const g = new THREE.ConeGeometry(0.06, 0.18, 14); const extra = hats.slice(48); M.hat.forEach((mat, mi) => { const list = extra.filter((_, i) => i % M.hat.length === mi); if (!list.length) return; const im = new THREE.InstancedMesh(g, mat, list.length); list.forEach(([x, z], i) => { tmp.position.set(x, 0.87, z); tmp.rotation.set(0, 0, 0); tmp.updateMatrix(); im.setMatrixAt(i, tmp.matrix); }); root.add(im); }); }
  return out;
}

export function bakeStatic(root) {
  root.updateMatrixWorld(true);
  const groups = new Map(); const remove = [];
  const walk = (o) => {
    if (o.userData.dyn) return;
    if (!o.visible) { remove.push(o); return; }
    if (o.isMesh && !o.isInstancedMesh && o.geometry && o.material && !Array.isArray(o.material)) {
      const key = o.material.uuid + (o.castShadow ? "s" : "n");
      if (!groups.has(key)) groups.set(key, { mat: o.material, shadow: o.castShadow, items: [] });
      groups.get(key).items.push(o); remove.push(o);
    }
    for (const c of o.children) walk(c);
  };
  for (const c of root.children) walk(c);
  for (const { mat, shadow, items } of groups.values()) {
    let total = 0; const geos = items.map((m) => { let g = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone(); g.applyMatrix4(m.matrixWorld); total += g.attributes.position.count; return g; });
    const P = new Float32Array(total * 3), N = new Float32Array(total * 3), U = new Float32Array(total * 2); let o = 0;
    for (const g of geos) { const n = g.attributes.position.count; P.set(g.attributes.position.array, o * 3); if (g.attributes.normal) N.set(g.attributes.normal.array, o * 3); if (g.attributes.uv) U.set(g.attributes.uv.array.subarray(0, n * 2), o * 2); o += n; g.dispose(); }
    const bg = new THREE.BufferGeometry(); bg.setAttribute("position", new THREE.BufferAttribute(P, 3)); bg.setAttribute("normal", new THREE.BufferAttribute(N, 3)); bg.setAttribute("uv", new THREE.BufferAttribute(U, 2)); bg.computeBoundingSphere();
    const mesh = new THREE.Mesh(bg, mat); mesh.castShadow = shadow; mesh.receiveShadow = true; mesh.matrixAutoUpdate = false; root.add(mesh);
  }
  // detach originals but keep dynamic descendants attached to their (now invisible) parents
  for (const m of remove) { if (m.children.some((c) => c.userData.dyn || hasDyn(c))) { m.geometry = new THREE.BufferGeometry(); } else m.parent && m.parent.remove(m); }
}
function hasDyn(o) { if (o.userData.dyn) return true; return o.children.some(hasDyn); }
