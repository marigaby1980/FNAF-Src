import * as THREE from "three";

function rep(set, r) { for (const k of ["map", "normalMap", "roughnessMap"]) if (set[k]) { set[k] = set[k].clone(); set[k].needsUpdate = true; set[k].repeat.set(r[0], r[1]); } return set; }
export function buildMaterials(T) {
  const M = {};
  const std = (o) => new THREE.MeshStandardMaterial(o);
  M.floor = {
    checker: std({ ...rep({ ...T.checker }, [1 / 1.2, 1 / 1.2]), vertexColors: true, roughness: 1, normalScale: new THREE.Vector2(0.8, 0.8), envMapIntensity: 0.6 }),
    smalltile: std({ ...rep({ ...T.smalltile }, [1, 1]), vertexColors: true, roughness: 1, envMapIntensity: 0.5 }),
    concrete: std({ ...rep({ ...T.concrete }, [1 / 3, 1 / 3]), vertexColors: true, roughness: 1 }),
    wood: std({ ...rep({ ...T.wood }, [1 / 2, 1 / 2]), vertexColors: true, roughness: 1, envMapIntensity: 0.5 }),
    carpet: std({ ...rep({ ...T.carpet }, [1 / 2, 1 / 2]), vertexColors: true, roughness: 1 }),
    carpet2: std({ ...rep({ ...T.carpet2 }, [1 / 2, 1 / 2]), vertexColors: true, roughness: 1 }),
  };
  const wallMat = (t) => std({ ...t, vertexColors: true, roughness: 1, normalScale: new THREE.Vector2(1, 1) });
  M.wall = { main: wallMat(T.wallMain), party: wallMat(T.wallParty), tile: wallMat(T.wallTile), block: wallMat(T.wallBlock) };
  M.ceiling = std({ ...rep({ ...T.ceiling }, [1 / 1.2, 1 / 1.2]), vertexColors: true, roughness: 1 });
  M.trim = std({ color: 0x1b1716, roughness: 0.7 });
  M.metal = std({ ...T.metal, color: 0x9a9a9e, metalness: 0.85, roughness: 1 });
  M.darkMetal = std({ ...T.metal, color: 0x3a3a3e, metalness: 0.8, roughness: 1 });
  M.endo = std({ ...T.metal, color: 0x2a2a2d, metalness: 0.75, roughness: 1 });
  M.chrome = std({ color: 0xc8c8cc, metalness: 1, roughness: 0.25 });
  M.wood = std({ ...T.woodGrain, color: 0xffffff, roughness: 1 });
  M.darkWood = std({ ...T.woodGrain, color: 0x6a5a50, roughness: 1 });
  M.cloth = std({ ...T.cloth, roughness: 1, side: THREE.DoubleSide });
  M.plasticRed = std({ color: 0x7a1414, roughness: 0.45 });
  M.vinyl = new THREE.MeshPhysicalMaterial({ color: 0x5c0f14, roughness: 0.35, clearcoat: 0.6, clearcoatRoughness: 0.4, normalMap: T.fur.normalMap, normalScale: new THREE.Vector2(0.15, 0.15) });
  M.plasticWhite = std({ color: 0xd8d4ca, roughness: 0.5 });
  M.plasticBlack = std({ color: 0x141416, roughness: 0.45 });
  M.cabinet = std({ color: 0x1c1a2a, roughness: 0.55 });
  M.hazard = std({ ...T.hazard, metalness: 0.5, roughness: 1 });
  M.doorMetal = std({ ...T.metal, color: 0x4a4a50, metalness: 0.85, roughness: 1 });
  M.glass = new THREE.MeshPhysicalMaterial({ color: 0x88998f, metalness: 0, roughness: 0.08, transmission: 0, transparent: true, opacity: 0.18, envMapIntensity: 1.2, depthWrite: false });
  M.curtain = std({ ...T.curtain, roughness: 0.95, side: THREE.DoubleSide });
  M.poster = std({ map: T.poster, roughness: 0.8 });
  M.drawings = T.drawings.map((t) => std({ map: t, roughness: 0.9, side: THREE.DoubleSide }));
  M.paper = std({ color: 0xe6e0d0, roughness: 0.9 });
  M.screenOff = std({ color: 0x0b0e0c, roughness: 0.15, metalness: 0.2 });
  M.crtStatic = new THREE.MeshBasicMaterial({ map: T.static, color: 0x6a8a74 });
  M.arcade = T.arcade.map((t) => new THREE.MeshBasicMaterial({ map: t, color: 0x8a8a8a }));
  M.marquee = [0xff4d6d, 0x3ee6c1, 0xffd23f, 0x6c8cff].map((c) => new THREE.MeshStandardMaterial({ color: 0x111111, emissive: c, emissiveIntensity: 0.55 }));
  M.fixtureOn = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2d8, emissiveIntensity: 3.0 });
  M.fixtureFluo = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xe4fff2, emissiveIntensity: 3.0 });
  M.fixtureOff = std({ color: 0x8a8a84, roughness: 0.4 });
  M.ledRed = new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 0.2, 0.15) });
  M.ledGreen = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.2, 3, 0.4) });
  M.ledWhite = new THREE.MeshBasicMaterial({ color: new THREE.Color(2.5, 2.4, 2.2) });
  M.balls = [0xd8342c, 0x2c6fd8, 0xe8c02a, 0x2aa84a, 0xd84a9c].map((c) => std({ color: c, roughness: 0.3 }));
  M.balloon = [0xd8342c, 0x2c6fd8, 0xe8c02a, 0x9a3fd8].map((c) => new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.25, clearcoat: 1 }));
  M.hat = [0xd8342c, 0x2c6fd8, 0xe8c02a, 0x9a3fd8, 0x2aa84a].map((c) => std({ color: c, roughness: 0.6 }));
  M.signs = {};
  for (const k of ["signCove", "signCelebrate", "signOffice", "signParts", "signPrize"]) M.signs[k] = std({ map: T[k], roughness: 0.7, emissive: 0xffffff, emissiveMap: T[k], emissiveIntensity: 0.04 });
  M.logo = std({ map: T.logo, roughness: 0.8 });
  M.stageFront = std({ color: 0x2a0f35, roughness: 0.8 });
  M.speaker = std({ color: 0x101012, roughness: 0.8 });
  M.present = [0xc03a3a, 0x3a7ac0, 0x7ac03a].map((c) => std({ color: c, roughness: 0.7 }));
  M.cardboard = std({ ...T.concrete, color: 0xb08a5a, roughness: 1 });
  return M;
}
