import * as THREE from "three";

const VS = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;
const quadGeo = new THREE.PlaneGeometry(2, 2);
function pass(frag, uniforms) { const m = new THREE.ShaderMaterial({ vertexShader: VS, fragmentShader: frag, uniforms, depthTest: false, depthWrite: false }); const mesh = new THREE.Mesh(quadGeo, m); mesh.frustumCulled = false; const sc = new THREE.Scene(); sc.add(mesh); return { m, sc }; }
const CAM = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

const BRIGHT = `uniform sampler2D t; uniform float thr; varying vec2 vUv;
void main(){ vec3 c = texture2D(t, vUv).rgb; float l = max(max(c.r,c.g),c.b); float k = smoothstep(thr, thr*2.5, l); gl_FragColor = vec4(c*k, 1.0); }`;
const BLUR = `uniform sampler2D t; uniform vec2 dir; varying vec2 vUv;
void main(){ vec3 s = texture2D(t, vUv).rgb*0.227;
 s += texture2D(t, vUv+dir*1.384).rgb*0.316; s += texture2D(t, vUv-dir*1.384).rgb*0.316;
 s += texture2D(t, vUv+dir*3.230).rgb*0.070; s += texture2D(t, vUv-dir*3.230).rgb*0.070; gl_FragColor = vec4(s,1.0); }`;
const COMP = `uniform sampler2D tScene, tB1, tB2; uniform float time, exposure, cctv, nv, fear, stat, flash, ca, sat, vig, bloom, dead;
varying vec2 vUv;
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233))) * 43758.5453); }
vec3 aces(vec3 x){ const float a=2.51,b=0.03,c=2.43,d=0.59,e=0.14; return clamp((x*(a*x+b))/(x*(c*x+d)+e),0.0,1.0); }
void main(){
  vec2 uv = vUv;
  if (cctv > 0.0) { vec2 cc = uv - 0.5; float r2 = dot(cc,cc); uv = 0.5 + cc*(1.0 + 0.12*r2*cctv); uv.x += (hash(vec2(floor(uv.y*180.0), floor(time*20.0)))-0.5)*0.004*cctv; }
  vec2 d = (uv-0.5); float cak = ca*(0.4+dot(d,d)*3.0) + fear*0.006;
  vec3 col;
  col.r = texture2D(tScene, uv + d*cak).r; col.g = texture2D(tScene, uv).g; col.b = texture2D(tScene, uv - d*cak).b;
  col += (texture2D(tB1, uv).rgb*0.6 + texture2D(tB2, uv).rgb*0.9) * bloom;
  col *= exposure;
  if (nv > 0.0) { float l = dot(col, vec3(0.3,0.59,0.11)); vec3 n = vec3(0.55,0.95,0.75)*pow(l*1.7, 0.8); col = mix(col, n, nv*0.72); }
  col = aces(col);
  float l = dot(col, vec3(0.299,0.587,0.114));
  col = mix(vec3(l), col, sat);
  col = mix(col, col*vec3(0.92,1.0,1.06), smoothstep(0.35,0.0,l)*0.6);
  col = pow(col, vec3(1.0/2.2));
  float v = smoothstep(0.95, 0.25, length((vUv-0.5)*vec2(1.15,1.0))); col *= mix(1.0-vig, 1.0, v);
  if (cctv > 0.0) {
    float cl = dot(col, vec3(0.3,0.59,0.11)); col = mix(col, vec3(cl*0.9, cl*1.05, cl*0.95), 0.55*cctv);
    col *= 0.86 + 0.14*sin(uv.y*900.0); col += (hash(uv*vec2(640.0,480.0)+time)-0.5)*0.07*cctv;
    float band = smoothstep(0.0,0.02, abs(fract(uv.y*0.7 - time*0.23)-0.5)); col *= 0.93 + 0.07*band;
    if (uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0) col = vec3(0.0);
  }
  col += (hash(vUv*vec2(1731.0,977.0)+fract(time*7.0))-0.5)*0.03;
  col = mix(col, vec3(hash(floor(vUv*vec2(320.0,180.0))+floor(time*30.0))), stat);
  col = mix(col, col + vec3(0.35,0.0,0.0)*(1.0-v), fear*0.5);
  col = mix(col, vec3(1.0,0.96,0.9), flash);
  col *= 1.0 - dead;
  gl_FragColor = vec4(col, 1.0);
}`;

export class Post {
  constructor(renderer) {
    this.r = renderer; this.w = 0; this.h = 0;
    this.bright = pass(BRIGHT, { t: { value: null }, thr: { value: 1.0 } });
    this.blur = pass(BLUR, { t: { value: null }, dir: { value: new THREE.Vector2() } });
    this.comp = pass(COMP, { tScene: { value: null }, tB1: { value: null }, tB2: { value: null }, time: { value: 0 }, exposure: { value: 1.0 }, cctv: { value: 0 }, nv: { value: 0 }, fear: { value: 0 }, stat: { value: 0 }, flash: { value: 0 }, ca: { value: 0.004 }, sat: { value: 0.85 }, vig: { value: 0.55 }, bloom: { value: 0.5 }, dead: { value: 0 } });
    this.u = this.comp.m.uniforms;
  }
  setSize(w, h) {
    w = Math.max(2, Math.floor(w)); h = Math.max(2, Math.floor(h)); if (w === this.w && h === this.h) return; this.w = w; this.h = h;
    const opt = { type: THREE.HalfFloatType, depthBuffer: false };
    this.rt?.dispose(); this.rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: 4 });
    [this.a1, this.b1, this.a2, this.b2].forEach((t) => t?.dispose());
    this.a1 = new THREE.WebGLRenderTarget(w >> 1, h >> 1, opt); this.b1 = new THREE.WebGLRenderTarget(w >> 1, h >> 1, opt);
    this.a2 = new THREE.WebGLRenderTarget(w >> 3, h >> 3, opt); this.b2 = new THREE.WebGLRenderTarget(w >> 3, h >> 3, opt);
  }
  q(p, target) { this.r.setRenderTarget(target); this.r.render(p.sc, CAM); }
  blurTo(src, tmp, w, h, scale) {
    const b = this.blur.m.uniforms; b.t.value = src.texture; b.dir.value.set(scale / w, 0); this.q(this.blur, tmp);
    b.t.value = tmp.texture; b.dir.value.set(0, scale / h); this.q(this.blur, src);
  }
  render(scene, camera, vp, time) {
    const r = this.r; const pr = r.getPixelRatio(); this.setSize(vp.w * pr, vp.h * pr);
    r.setRenderTarget(this.rt); r.clear(); r.render(scene, camera);
    this.bright.m.uniforms.t.value = this.rt.texture; this.q(this.bright, this.a1);
    this.blurTo(this.a1, this.b1, this.w >> 1, this.h >> 1, 1.0);
    this.blur.m.uniforms.t.value = this.a1.texture; this.blur.m.uniforms.dir.value.set(0, 0); this.q(this.blur, this.a2);
    this.blurTo(this.a2, this.b2, this.w >> 3, this.h >> 3, 1.5); this.blurTo(this.a2, this.b2, this.w >> 3, this.h >> 3, 2.5);
    this.u.tScene.value = this.rt.texture; this.u.tB1.value = this.a1.texture; this.u.tB2.value = this.a2.texture; this.u.time.value = time;
    r.setRenderTarget(null); r.setViewport(vp.x, vp.y, vp.w, vp.h); r.setScissor(vp.x, vp.y, vp.w, vp.h); r.setScissorTest(true);
    r.render(this.comp.sc, CAM); r.setScissorTest(false);
  }
}
