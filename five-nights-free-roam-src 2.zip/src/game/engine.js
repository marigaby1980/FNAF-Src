import * as THREE from "three";
import { buildTextures } from "./textures.js";
import { buildMaterials } from "./materials.js";
import { Grid, buildMapMeshes, ROOMS, CAMS, CAM_NAMES, BREAKERS, CELL } from "./map.js";
import { buildProps } from "./props.js";
import { buildAnimatronic, buildGuard, animateRig, SPECS } from "./characters.js";
import { Post } from "./post.js";
import { Audio } from "./audio.js";

export const KINDS = ["freddy", "bonnie", "chica", "foxy"];
const START = { freddy: [16, 4.6, 0], bonnie: [13.9, 4.7, 0.15], chica: [18.1, 4.7, -0.15], foxy: [1.9, 17.8, Math.PI / 2] };
export const BAL = {
  guardWalk: 3.0, guardSprint: 6.2, staminaMax: 4.5, staminaRegen: 0.36, exhaustLock: 0.3,
  battDrain: 0.85, battRecharge: 3.2, powerBase: 0.085, powerDoor: 0.62, powerCams: 0.22, powerHall: 0.3,
  breakerGain: 16, breakerHold: 3.0, breakerCooldown: 70, catchDist: 1.15,
  litSlow: 0.5, stunTime: 2.6, stunImmune: 5, litToStun: 1.05, switchCd: 7, dashSpeed: 8.2, dashTime: 2.1,
  abilityCd: { freddy: 30, bonnie: 28, chica: 24, foxy: 15 },
};
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const angDiff = (a, b) => { let d = b - a; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return d; };

function envMap(renderer) {
  const s = new THREE.Scene(); s.background = new THREE.Color(0x020203);
  const box = new THREE.Mesh(new THREE.BoxGeometry(20, 6, 20), new THREE.MeshBasicMaterial({ color: 0x050506, side: THREE.BackSide })); s.add(box);
  for (const [x, z, c] of [[-4, -3, 0xffc890], [4, 2, 0xd8ffe8], [0, 6, 0xffc890]]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(2, 0.6), new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(1.4) })); p.position.set(x, 2.9, z); p.rotation.x = Math.PI / 2; s.add(p); }
  const pm = new THREE.PMREMGenerator(renderer); const rt = pm.fromScene(s, 0.02); pm.dispose(); return rt.texture;
}
function cookieTex() {
  const cv = document.createElement("canvas"); cv.width = cv.height = 256; const ctx = cv.getContext("2d");
  const g = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  g.addColorStop(0, "#fff"); g.addColorStop(0.18, "#f4f0ea"); g.addColorStop(0.24, "#fffdf6"); g.addColorStop(0.3, "#8a8680"); g.addColorStop(0.55, "#5a5652"); g.addColorStop(0.62, "#6e6a64"); g.addColorStop(1, "#000");
  ctx.fillStyle = g; ctx.fillRect(0, 0, 256, 256); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
}

/* ============================ INPUT ============================ */
class Input {
  constructor(el) {
    this.keys = new Set(); this.pressed = new Set(); this.mdx = 0; this.mdy = 0; this.mouseDown = false; this.el = el; this.locked = false;
    this.kd = (e) => { if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Tab"].includes(e.code)) e.preventDefault(); if (!this.keys.has(e.code)) this.pressed.add(e.code); this.keys.add(e.code); };
    this.ku = (e) => this.keys.delete(e.code);
    this.mm = (e) => { if (this.locked) { this.mdx += e.movementX; this.mdy += e.movementY; } };
    this.md = () => { this.mouseDown = true; this.pressed.add("Mouse0"); };
    this.mu = () => (this.mouseDown = false);
    this.pl = () => (this.locked = document.pointerLockElement === this.el);
    this.blur = () => this.keys.clear();
    addEventListener("keydown", this.kd); addEventListener("keyup", this.ku); addEventListener("mousemove", this.mm); el.addEventListener("mousedown", this.md); addEventListener("mouseup", this.mu); document.addEventListener("pointerlockchange", this.pl); addEventListener("blur", this.blur);
  }
  down(c) { return this.keys.has(c); }
  hit(c) { return this.pressed.has(c); }
  endFrame() { this.pressed.clear(); this.mdx = 0; this.mdy = 0; }
  lock() { try { const p = this.el.requestPointerLock?.(); p?.catch?.(() => {}); } catch (e) {} }
  unlock() { if (document.pointerLockElement) document.exitPointerLock(); }
  // headless/test driver: advance n frames (render only last)
  step(n = 1, dt = 1 / 30) { const R = this.render; this.render = () => {}; for (let i = 0; i < n - 1; i++) this.frame(dt); this.render = R; this.frame(dt); return true; }
  dispose() { removeEventListener("keydown", this.kd); removeEventListener("keyup", this.ku); removeEventListener("mousemove", this.mm); this.el.removeEventListener("mousedown", this.md); removeEventListener("mouseup", this.mu); document.removeEventListener("pointerlockchange", this.pl); removeEventListener("blur", this.blur); }
}
function gamepadIntent() {
  const gp = navigator.getGamepads ? [...navigator.getGamepads()].find(Boolean) : null; if (!gp) return null;
  const dz = (v) => (Math.abs(v) < 0.15 ? 0 : v);
  return { mx: dz(gp.axes[0]), mz: -dz(gp.axes[1]), turn: dz(gp.axes[2]) * 2.6, pitch: dz(gp.axes[3]), ability: gp.buttons[0]?.pressed, next: gp.buttons[5]?.pressed, prev: gp.buttons[4]?.pressed };
}

/* ============================ ENGINE ============================ */
export class Engine {
  constructor(container, onHud) {
    this.container = container; this.onHud = onHud;
    const r = (this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" }));
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5)); r.setSize(container.clientWidth, container.clientHeight);
    r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFSoftShadowMap; r.shadowMap.autoUpdate = false; r.toneMapping = THREE.NoToneMapping; r.autoClear = true;
    container.appendChild(r.domElement); r.domElement.style.display = "block";
    this.input = new Input(r.domElement); this.audio = new Audio();
    this.T = buildTextures(); this.M = buildMaterials(this.T);
    const scene = (this.scene = new THREE.Scene()); scene.fog = new THREE.FogExp2(0x040405, 0.05); scene.background = new THREE.Color(0x010102);
    scene.environment = envMap(r);
    this.grid = new Grid(); const mm = buildMapMeshes(this.grid, this.M); scene.add(mm.group);
    this.props = buildProps(this.grid, this.M, this.T); scene.add(this.props.group);
    this.grid.buildNav();
    // lights
    this.hemi = new THREE.HemisphereLight(0x8a9aa8, 0x201812, 0.05); scene.add(this.hemi);
    this.pool = []; for (let i = 0; i < 8; i++) { const l = new THREE.PointLight(0xffffff, 0, 12, 2); scene.add(l); this.pool.push(l); }
    const fl = (this.flash = new THREE.SpotLight(0xfff0da, 0, 26, 0.44, 0.5, 1.6)); fl.castShadow = true; fl.shadow.mapSize.set(1024, 1024); fl.shadow.bias = -0.0004; fl.shadow.normalBias = 0.03; fl.shadow.camera.near = 0.2; fl.map = cookieTex(); scene.add(fl); scene.add(fl.target);
    const st = (this.stageSpot = new THREE.SpotLight(0xcdb8ff, 40, 16, 0.72, 0.55, 1.5)); st.position.set(16, 2.95, 9.8); st.target.position.set(16, 1.0, 4.4); st.castShadow = true; st.shadow.mapSize.set(1024, 1024); st.shadow.bias = -0.0005; st.shadow.normalBias = 0.03; scene.add(st); scene.add(st.target);
    this.hallLights = {}; for (const [side, x] of [["L", 14.8], ["R", 25.2]]) { const h = new THREE.SpotLight(0xfff2d0, 0, 10, 0.8, 0.7, 1.5); h.position.set(side === "L" ? 16.2 : 23.8, 2.8, 46.5); h.target.position.set(x, 0, 46.5); scene.add(h); scene.add(h.target); this.hallLights[side] = h; }
    this.fixtures = this.props.fixtures.map((f, i) => ({ ...f, on: 1, flick: 0, seed: i * 13.7, dead: false }));
    // characters
    this.anims = {}; for (const k of KINDS) { const R = buildAnimatronic(k, this.T); scene.add(R.root); this.anims[k] = { rig: R, kind: k }; }
    this.colors = { shirt: 0x8e3fbf, pants: 0x2f5bc0, skin: 0xe8c4a0, hair: 0xc9a050 };
    this.guardRig = buildGuard(this.T, this.colors); scene.add(this.guardRig.root);
    // volumetric beam (seen by others)
    const beamGeo = new THREE.ConeGeometry(2.6, 9, 32, 1, true); beamGeo.translate(0, -4.5, 0); beamGeo.rotateX(-Math.PI / 2);
    this.beam = new THREE.Mesh(beamGeo, new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false,
      uniforms: { k: { value: 0.12 } },
      vertexShader: `varying float vz; varying vec3 vN; varying vec3 vV; void main(){ vz = -position.z/9.0; vec4 mv = modelViewMatrix*vec4(position,1.0); vN = normalize(normalMatrix*normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `uniform float k; varying float vz; varying vec3 vN; varying vec3 vV; void main(){ float e = pow(abs(dot(vN, vV)), 1.5); float a = k * e * pow(1.0 - clamp(vz,0.0,1.0), 2.0); gl_FragColor = vec4(vec3(1.0,0.95,0.85)*a, 1.0); }` }));
    scene.add(this.beam);
    // first-person flashlight
    this.fpCam = new THREE.PerspectiveCamera(72, 1, 0.05, 60); this.fpCam.rotation.order = "YXZ"; scene.add(this.fpCam);
    const fpl = new THREE.Group(); const body = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.028, 0.22, 16), new THREE.MeshStandardMaterial({ color: 0x151517, roughness: 0.35, metalness: 0.4 })); body.rotation.x = Math.PI / 2; fpl.add(body);
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.026, 0.06, 16), body.material); head.rotation.x = Math.PI / 2; head.position.z = -0.13; fpl.add(head);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.031, 0.004, 6, 20), new THREE.MeshStandardMaterial({ color: 0x9a9aa0, metalness: 1, roughness: 0.3 })); ring.position.z = -0.16; fpl.add(ring);
    this.fpLens = new THREE.Mesh(new THREE.CircleGeometry(0.029, 20), new THREE.MeshBasicMaterial({ color: 0x222222 })); this.fpLens.position.z = -0.161; this.fpLens.rotation.y = Math.PI; fpl.add(this.fpLens);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.05, 0.1), new THREE.MeshStandardMaterial({ color: 0x3a2a22, roughness: 0.8 })); grip.position.set(0.004, -0.028, 0.03); fpl.add(grip);
    fpl.position.set(0.24, -0.25, -0.45); fpl.rotation.set(0.05, 0.1, 0); fpl.scale.setScalar(0.85); this.fpCam.add(fpl); this.fpFlash = fpl;
    this.animCam = new THREE.PerspectiveCamera(68, 1, 0.05, 60); this.cctvCam = new THREE.PerspectiveCamera(62, 4 / 3, 0.05, 60); this.menuCam = new THREE.PerspectiveCamera(50, 1, 0.05, 80);
    this.posts = [new Post(r), new Post(r)];
    this.time = 0; this.mode = "menu"; this.state = "menu"; this.menuView = "stage";
    this.resetWorld();
    this.resize = () => { const w = container.clientWidth, h = container.clientHeight; r.setSize(w, h); };
    addEventListener("resize", this.resize);
    this.last = performance.now(); this.hudT = 0; this.running = true;
    const loop = () => { if (!this.running) return; this.raf = requestAnimationFrame(loop); const now = performance.now(); const dt = Math.min(0.05, (now - this.last) / 1000); this.last = now; this.frame(dt); };
    this.manual = !!navigator.webdriver;
    if (!this.manual) this.raf = requestAnimationFrame(loop);
    window.__eng = this;
  }
  // headless/test driver: advance n frames (render only last)
  step(n = 1, dt = 1 / 30) { const R = this.render; this.render = () => {}; for (let i = 0; i < n - 1; i++) this.frame(dt); this.render = R; this.frame(dt); return true; }
  dispose() { this.running = false; cancelAnimationFrame(this.raf); this.input.dispose(); removeEventListener("resize", this.resize); this.renderer.dispose(); this.renderer.domElement.remove(); }

  /* ---------------- world/match state ---------------- */
  resetWorld() {
    for (const k of KINDS) {
      const a = this.anims[k], [x, z, yaw] = START[k];
      Object.assign(a, { x, z, yaw, y: this.grid.heightAt(x, z), lit: 0, stun: 0, immune: 0, dash: 0, speed: 0, path: null, pathT: 0, stepAcc: 0, twitchT: 0, seen: false, lookYaw: 0 });
      a.rig.root.position.set(x, a.y, z); a.rig.root.rotation.y = yaw; animateRig(a.rig, 1, { speed: 0, state: "idle" }); a.rig.setGlow(false);
    }
    this.guard = { x: 20, z: 46.4, yaw: Math.PI, pitch: 0, speed: 0, stamina: BAL.staminaMax, exhausted: false, flashOn: false, battery: 100, onCams: false, cam: 1, alive: true, hold: 0, holdTarget: null, bob: 0, stepAcc: 0, blackout: 0, sprinting: false, prompt: null, fear: 0 };
    this.guardRig.root.position.set(20, 0, 46.4);
    this.power = 100; this.powerOut = false; this.hall = { L: false, R: false };
    this.grid.secDoors.forEach((d) => { d.closed = false; d.anim = 0; d.mesh.position.y = 2.35; });
    this.props.breakers.forEach((b) => { b.cooldown = 0; b.jam = 0; b.led.material = this.M.ledGreen; b.lever.rotation.x = -0.5; });
    this.fixtures.forEach((f) => { f.dead = false; f.killT = 0; });
    this.ctl = { active: "freddy", switchCd: 3, abilityCd: 0, revealT: 0, pings: [], transT: 0, camPitch: -0.12 };
    this.clock = 0; this.hour = 0; this.messages = []; this.result = null; this.jump = null; this.flashT = 0; this.shake = 0;
    this.ai = { lastKnown: null, lastSeenT: -99, goal: null, switchT: 20, patrolT: 0, abilityT: 5 };
    this.gai = { state: "office", t: 0, goal: null, path: null, pathT: 0, flee: 0, officeT: 8, closeT: { L: 0, R: 0 } };
  }
  setColors(c) { this.colors = { ...this.colors, ...c }; this.guardRig.setColors(this.colors); }
  setMenuView(v) { this.menuView = v; }
  start(opts) {
    this.opts = { nightLen: 360, night: 1, ...opts }; this.mode = opts.mode; this.resetWorld(); this.state = "intro"; this.introT = 3.2;
    this.audio.init(); this.input.lock(); this.msg(this.mode === "soloAnim" ? "Hunt the guard before 6 AM" : "Survive until 6 AM", 4);
  }
  toMenu() { this.state = "menu"; this.mode = "menu"; this.input.unlock(); this.resetWorld(); }
  msg(t, d = 3, who = "all") { this.messages.push({ t, d, who }); if (this.messages.length > 4) this.messages.shift(); }

  humanRole() { return this.mode === "soloAnim" ? "anim" : "guard"; }

  /* ---------------- per-frame ---------------- */

  // Dev helper: studio turnaround of every character (front / side / back), used for visual QA.
  lineup(kinds = ["freddy", "bonnie", "chica", "foxy", "guard"], views = ["front", "side", "back"], bg = 0xdcdcdc) {
    const r = this.renderer; const sz = r.getSize(new THREE.Vector2()); const W = sz.x, H = sz.y;
    const sc = new THREE.Scene(); sc.background = new THREE.Color(bg); sc.environment = this.scene.environment;
    sc.add(new THREE.HemisphereLight(0xffffff, 0x777066, 1.1));
    const key = new THREE.DirectionalLight(0xfff4e6, 2.4); key.position.set(2.5, 4, 5); sc.add(key);
    const rim = new THREE.DirectionalLight(0xdfe8ff, 1.2); rim.position.set(-3, 3, -4); sc.add(rim);
    const cam = new THREE.PerspectiveCamera(28, 1, 0.1, 50);
    const rigs = kinds.map((k) => k === "guard" ? buildGuard(this.T, this.colors) : buildAnimatronic(k, this.T));
    const tpose = (R) => { R.shL.rotation.set(0, 0, -Math.PI / 2 + 0.06); R.shR.rotation.set(0, 0, Math.PI / 2 - 0.06); R.elL.rotation.set(0, 0, 0); R.elR.rotation.set(0, 0, 0); };
    r.setScissorTest(true); r.setClearColor(bg, 1); r.setViewport(0, 0, W, H); r.setScissor(0, 0, W, H); r.clear();
    const cw = W / views.length, ch = H / kinds.length; const tm = r.toneMapping; r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.0;
    rigs.forEach((R, i) => { sc.add(R.root); tpose(R);
      views.forEach((v, j) => { const ang = v === "front" ? 0 : v === "side" ? Math.PI / 2 : v === "back" ? Math.PI : -Math.PI / 2; R.root.rotation.y = -ang;
        cam.aspect = cw / ch; const dist = 8.4; cam.position.set(0, 1.2, dist); cam.lookAt(0, 1.08, 0); cam.updateProjectionMatrix();
        const x = j * cw, y = (kinds.length - 1 - i) * ch; r.setViewport(x, y, cw, ch); r.setScissor(x, y, cw, ch); r.render(sc, cam); });
      sc.remove(R.root); });
    r.toneMapping = tm; r.setScissorTest(false); r.setViewport(0, 0, W, H);
    return r.domElement.toDataURL("image/png");
  }
  frame(dt) {
    this.time += dt; const inp = this.input;
    if (this.state === "intro") { this.introT -= dt; if (this.introT <= 0) this.state = "play"; }
    const mouseOwner = this.mode !== "menu";
    this.paused = this.state === "play" && mouseOwner && !this.input.locked && !(this.guard.onCams && this.humanRole() === "guard") && !this.noPause;
    if ((this.state === "play" && !this.paused) || this.state === "intro") this.simulate(this.state === "intro" ? 0 : dt, dt);
    else if (this.state === "jumpscare") this.updateJump(dt);
    this.updateFixtures(dt);
    this.animateWorld(dt);
    this.render(dt);
    this.messages.forEach((m) => (m.d -= dt)); this.messages = this.messages.filter((m) => m.d > 0);
    this.hudT -= dt; if (this.hudT <= 0) { this.hudT = 0.1; this.onHud && this.onHud(this.hud()); }
    inp.endFrame();
  }

  simulate(dt, rdt) {
    const g = this.guard, ctl = this.ctl;
    // clock
    if (dt > 0) {
      this.clock += dt; const hr = Math.min(6, Math.floor(this.clock / (this.opts.nightLen / 6)));
      if (hr !== this.hour) { this.hour = hr; if (hr < 6) this.msg(`${hr} AM`, 2); }
      if (this.clock >= this.opts.nightLen) return this.endMatch("guard");
    }
    const gi = this.mode === "soloAnim" ? this.guardAI(dt) : this.guardInput();
    const ai = this.mode === "soloGuard" ? this.animAI(dt) : this.mode === "soloAnim" ? this.animInputKBM() : this.animInputP2();
    this.updateGuard(gi, dt, rdt);
    this.updateAnims(ai, dt);
    this.updatePower(dt);
    // catch check
    const a = this.anims[ctl.active];
    if (g.alive && a.stun <= 0 && ctl.transT <= 0) {
      const d = Math.hypot(a.x - g.x, a.z - g.z);
      if (d < BAL.catchDist && this.grid.los(a.x, a.z, g.x, g.z)) this.startJump(a);
    }
    // fear / heartbeat
    let near = 99; for (const k of KINDS) { const b = this.anims[k]; const d = Math.hypot(b.x - g.x, b.z - g.z); if (k === ctl.active || d < 4) near = Math.min(near, d); }
    g.fear = clamp(1 - (near - 1.5) / 9, 0, 1) * (this.grid.los(a.x, a.z, g.x, g.z) ? 1 : 0.5);
    this.heartT = (this.heartT || 0) - rdt; if (g.fear > 0.25 && this.heartT <= 0) { this.audio.heartbeat(g.fear); this.heartT = 1.1 - g.fear * 0.55; }
  }

  guardInput() {
    const i = this.input; const w = (c) => (i.down(c) ? 1 : 0);
    const split = this.mode === "split";
    return {
      mz: w("KeyW") - w("KeyS"), mx: w("KeyD") - w("KeyA"), look: [i.mdx * 0.0022, i.mdy * 0.0022], sprint: i.down("ShiftLeft") || (!split && i.down("ShiftRight")),
      flash: i.hit("KeyF") || i.hit("Mouse0"), interact: i.down("KeyE"), interactHit: i.hit("KeyE"), hallLight: i.down("KeyQ"),
      camExit: i.hit("KeyE") || i.hit("Escape") || i.hit("Space"), camNext: i.hit("KeyD") || (!split && i.hit("ArrowRight")), camPrev: i.hit("KeyA") || (!split && i.hit("ArrowLeft")),
      camNum: (() => { for (let n = 1; n <= 9; n++) if (i.hit("Digit" + n)) return n; if (i.hit("Digit0")) return 10; if (i.hit("Minus")) return 11; if (i.hit("Equal")) return 12; return 0; })(),
    };
  }
  animInputKBM() {
    const i = this.input; const w = (c) => (i.down(c) ? 1 : 0); let sw = null; for (let n = 1; n <= 4; n++) if (i.hit("Digit" + n)) sw = KINDS[n - 1];
    return { mz: w("KeyW") - w("KeyS"), mx: w("KeyD") - w("KeyA"), turn: i.mdx * 0.0022, pitch: i.mdy * 0.0018, ability: i.hit("KeyQ") || i.hit("Mouse0"), switchTo: sw, next: i.hit("Tab") };
  }
  animInputP2() {
    const i = this.input; const w = (c) => (i.down(c) ? 1 : 0); let sw = null; for (let n = 1; n <= 4; n++) if (i.hit("Numpad" + n)) sw = KINDS[n - 1];
    ["Digit7", "Digit8", "Digit9", "Digit0"].forEach((c, n) => { if (i.hit(c)) sw = KINDS[n]; });
    const gp = gamepadIntent(); const dt = 1 / 60;
    const it = { mz: w("ArrowUp") - w("ArrowDown"), mx: (w("Period") - w("Comma")), turn: (w("ArrowRight") - w("ArrowLeft")) * 2.6 * dt, pitch: 0, ability: i.hit("Enter") || i.hit("NumpadEnter"), switchTo: sw, next: i.hit("ShiftRight") || i.hit("Slash") };
    if (gp) { it.mz += gp.mz; it.mx += gp.mx; it.turn += gp.turn * dt; it.pitch = gp.pitch * dt; if (gp.ability && !this._gpA) it.ability = true; if (gp.next && !this._gpN) it.next = true; this._gpA = gp.ability; this._gpN = gp.next; }
    return it;
  }

  /* ---------------- guard ---------------- */
  updateGuard(it, dt, rdt) {
    const g = this.guard, grid = this.grid; if (!g.alive) return;
    const inOffice = ROOMS[grid.roomAt(g.x, g.z)]?.id === "office"; g.inOffice = inOffice;
    if (g.onCams) {
      if (it.camExit) { g.onCams = false; this.audio.click(); if (this.humanRole() === "guard") this.input.lock(); }
      const ids = Object.keys(CAMS).map(Number);
      if (it.camNext) { g.cam = ids[(ids.indexOf(g.cam) + 1) % ids.length]; this.camStatic = 0.35; this.audio.staticBurst(0.25, 0.06); }
      if (it.camPrev) { g.cam = ids[(ids.indexOf(g.cam) - 1 + ids.length) % ids.length]; this.camStatic = 0.35; this.audio.staticBurst(0.25, 0.06); }
      if (it.camNum && CAMS[it.camNum]) { g.cam = it.camNum; this.camStatic = 0.35; this.audio.staticBurst(0.25, 0.06); }
      if (this.powerOut) g.onCams = false;
      g.speed = 0; g.sprinting = false;
    } else {
      g.yaw -= it.look[0]; g.pitch = clamp(g.pitch - it.look[1], -1.2, 1.2);
      let mx = it.mx, mz = it.mz; const l = Math.hypot(mx, mz); if (l > 1) { mx /= l; mz /= l; }
      const moving = l > 0.01 && g.hold <= 0;
      if (g.exhausted && g.stamina > BAL.staminaMax * BAL.exhaustLock) g.exhausted = false;
      g.sprinting = it.sprint && moving && !g.exhausted && mz > 0;
      if (g.sprinting) { g.stamina -= dt; if (g.stamina <= 0) { g.stamina = 0; g.exhausted = true; this.msg("Out of breath", 1.5, "guard"); } }
      else g.stamina = Math.min(BAL.staminaMax, g.stamina + dt * BAL.staminaRegen * (moving ? 0.6 : 1));
      const sp = moving ? (g.sprinting ? BAL.guardSprint : BAL.guardWalk) * (g.exhausted ? 0.8 : 1) : 0;
      const fx = Math.sin(g.yaw), fz = Math.cos(g.yaw), rx = -Math.cos(g.yaw), rz = Math.sin(g.yaw);
      const vx = (fx * mz + rx * mx) * sp, vz = (fz * mz + rz * mx) * sp;
      this.moveBody(g, vx * dt, vz * dt, 0.28, "guard");
      g.speed = moving ? sp : 0;
      if (moving) { g.bob += dt * sp * 2.3; g.stepAcc += dt * sp; const stride = g.sprinting ? 1.6 : 1.3; if (g.stepAcc > stride) { g.stepAcc = 0; this.audio.step(g.x, g.z, g.sprinting ? 0.5 : 0.25); if (g.sprinting) this.ping(g.x, g.z, "footsteps"); } }
      // flashlight
      if (it.flash) { g.flashOn = !g.flashOn; this.audio.click(); }
      // interactions
      g.prompt = null; let best = null, bd = 1.7;
      for (const o of this.props.interact) {
        const d = Math.hypot(o.x - g.x, o.z - g.z); if (d > bd) continue;
        const ang = Math.atan2(o.x - g.x, o.z - g.z); if (Math.abs(angDiff(g.yaw, ang)) > 0.9 && d > 0.6) continue;
        if ((o.kind === "door" || o.kind === "cams" || o.kind === "hallLight") && !inOffice) continue;
        if (o.kind === "hallLight") continue;
        best = o; bd = d;
      }
      if (best) {
        if (best.kind === "door") {
          const d = grid.secDoors.find((s) => s.side === best.side); g.prompt = `E  ${d.closed ? "Open" : "Close"} ${best.side === "L" ? "left" : "right"} door   ·   Q  Hall light`;
          if (it.interactHit && !this.powerOut) this.toggleDoor(d); else if (it.interactHit) { this.msg("No power", 1.5, "guard"); this.audio.click(); }
          this.setHall(best.side, it.hallLight && !this.powerOut);
        } else if (best.kind === "cams") {
          g.prompt = this.powerOut ? "Cameras offline" : "E  Open cameras";
          if (it.interactHit && !this.powerOut) { g.onCams = true; this.camStatic = 0.5; this.audio.staticBurst(0.4, 0.08); this.input.unlock(); }
        } else if (best.kind === "breaker") {
          const b = best.ref;
          if (b.jam > 0) g.prompt = `Breaker jammed  ${Math.ceil(b.jam)}s`;
          else if (b.cooldown > 0) g.prompt = `Breaker cooling  ${Math.ceil(b.cooldown)}s`;
          else {
            g.prompt = "Hold E  Reset breaker";
            if (it.interact) { g.hold += dt; g.holdTarget = b; if (Math.random() < dt * 4) this.audio.buzz(b.x, b.z, 0.08);
              if (g.hold >= BAL.breakerHold) { g.hold = 0; this.resetBreaker(b); } }
          }
        }
      }
      if (!best || best.kind !== "breaker" || !it.interact) { g.hold = 0; g.holdTarget = null; }
      if (!best || best.kind !== "door") { if (!inOffice || !best) { this.setHall("L", false); this.setHall("R", false); } }
    }
    // battery
    const flashWorks = g.flashOn && g.battery > 0 && g.blackout <= 0;
    if (flashWorks) g.battery = Math.max(0, g.battery - BAL.battDrain * dt); else if (inOffice && !this.powerOut) g.battery = Math.min(100, g.battery + BAL.battRecharge * dt);
    if (g.battery <= 0 && g.flashOn) { g.flashOn = false; this.msg("Flashlight dead. Recharge in the office", 3, "guard"); }
    g.blackout = Math.max(0, g.blackout - dt);
    g.flashWorks = flashWorks;
    // flashlight stun
    const a = this.anims[this.ctl.active];
    if (flashWorks) {
      const eyeY = 1.62; const dx = a.x - g.x, dz = a.z - g.z, dy = (a.y + 1.3) - eyeY; const d = Math.hypot(dx, dz);
      const fx = Math.sin(g.yaw) * Math.cos(g.pitch), fy = Math.sin(g.pitch), fz = Math.cos(g.yaw) * Math.cos(g.pitch);
      const L = Math.hypot(dx, dy, dz); const cos = (dx * fx + dy * fy + dz * fz) / L;
      a.litNow = d < 10.5 && cos > Math.cos(0.3) && this.grid.los(g.x, g.z, a.x, a.z) && !g.onCams;
    } else a.litNow = false;
  }
  toggleDoor(d) { d.closed = !d.closed; this.audio.thud(0.8); if (d.closed) { const a = this.anims[this.ctl.active]; } }
  setHall(side, v) { if (this.hall[side] !== v) { this.hall[side] = v; if (v) this.audio.buzz(side === "L" ? 16 : 24, 46.5, 0.05); } }
  resetBreaker(b) {
    this.power = Math.min(100, this.power + BAL.breakerGain); b.cooldown = BAL.breakerCooldown; b.led.material = this.M.ledRed; b.lever.rotation.x = 0.5;
    this.audio.thud(0.5); this.msg(`Breaker reset  +${BAL.breakerGain}% power`, 2.5, "guard"); this.ping(b.x, b.z, "breaker");
    if (this.powerOut) { this.powerOut = false; this.msg("Power restored", 2.5); }
  }
  ping(x, z, kind) {
    const last = this.ctl.pings[this.ctl.pings.length - 1]; if (last && this.time - last.t < 0.5 && kind === "footsteps") return;
    this.ctl.pings.push({ x, z, t: this.time, kind }); if (this.ctl.pings.length > 6) this.ctl.pings.shift();
    if (this.mode === "soloGuard") { const a = this.anims[this.ctl.active]; if (Math.hypot(a.x - x, a.z - z) < (kind === "breaker" ? 30 : 20)) this.ai.lastKnown = { x: x + (Math.random() - 0.5) * 3, z: z + (Math.random() - 0.5) * 3, t: this.time }; }
  }
  updatePower(dt) {
    if (this.powerOut) { this.grid.secDoors.forEach((d) => (d.closed = false)); return; }
    const doors = this.grid.secDoors.filter((d) => d.closed).length; const halls = (this.hall.L ? 1 : 0) + (this.hall.R ? 1 : 0);
    this.usage = 1 + doors + (this.guard.onCams ? 1 : 0) + halls;
    this.power -= dt * (BAL.powerBase + doors * BAL.powerDoor + (this.guard.onCams ? BAL.powerCams : 0) + halls * BAL.powerHall);
    if (this.power <= 0) {
      this.power = 0; this.powerOut = true; this.guard.onCams = false; this.grid.secDoors.forEach((d) => (d.closed = false)); this.hall.L = this.hall.R = false;
      this.msg("POWER OUT. Reset a breaker!", 4); this.audio.thud(1); setTimeout(() => this.state === "play" && this.powerOut && this.audio.musicBox(), 1500);
      if (this.humanRole() === "guard") this.input.lock();
    }
    this.props.breakers.forEach((b) => { if (b.cooldown > 0) { b.cooldown -= dt; if (b.cooldown <= 0 && b.jam <= 0) { b.led.material = this.M.ledGreen; b.lever.rotation.x = -0.5; } } if (b.jam > 0) { b.jam -= dt; b.led.material = this.M.ledRed; if (b.jam <= 0 && b.cooldown <= 0) { b.led.material = this.M.ledGreen; b.lever.rotation.x = -0.5; } } });
  }

  moveBody(b, dx, dz, r, who) {
    const grid = this.grid; const blockers = [];
    if (who === "guard") for (const k of KINDS) { const a = this.anims[k]; if (k !== this.ctl.active || a.stun > 0) blockers.push(a); }
    else if (who) { for (const k of KINDS) if (k !== who) blockers.push(this.anims[k]); }
    const hit = (x, z) => grid.collides(x, z, r) || blockers.some((o) => Math.hypot(o.x - x, o.z - z) < r + 0.33);
    const n = Math.ceil(Math.hypot(dx, dz) / 0.12) || 1;
    for (let s = 0; s < n; s++) { const sx = dx / n, sz = dz / n; if (!hit(b.x + sx, b.z)) b.x += sx; if (!hit(b.x, b.z + sz)) b.z += sz; }
  }

  /* ---------------- animatronics ---------------- */
  updateAnims(it, dt) {
    const ctl = this.ctl; ctl.switchCd = Math.max(0, ctl.switchCd - dt); ctl.abilityCd = Math.max(0, ctl.abilityCd - dt); ctl.revealT = Math.max(0, ctl.revealT - dt); ctl.transT = Math.max(0, ctl.transT - dt);
    let want = it.switchTo; if (it.next) want = KINDS[(KINDS.indexOf(ctl.active) + 1) % 4];
    if (want && want !== ctl.active) {
      if (ctl.switchCd > 0) { if (this.mode !== "soloGuard") this.msg(`Switch ready in ${Math.ceil(ctl.switchCd)}s`, 1.2, "anim"); }
      else { const prev = this.anims[ctl.active]; prev.dash = 0; ctl.active = want; ctl.switchCd = BAL.switchCd; ctl.transT = 0.9; ctl.abilityCd = Math.max(ctl.abilityCd, 3); const a = this.anims[want]; this.animYawCam = a.yaw; if (this.mode !== "soloGuard") this.audio.staticBurst(0.6, 0.08); }
    }
    const a = this.anims[ctl.active];
    for (const k of KINDS) {
      const b = this.anims[k]; b.immune = Math.max(0, b.immune - dt);
      if (b.stun > 0) { b.stun -= dt; if (b.stun <= 0) { b.immune = BAL.stunImmune; } }
      if (k !== ctl.active) { b.speed = 0; b.lit = Math.max(0, b.lit - dt); continue; }
    }
    // lit / stun
    if (a.litNow && a.immune <= 0 && a.stun <= 0) { a.lit += dt; const need = a.kind === "freddy" ? BAL.litToStun * 1.7 : BAL.litToStun; if (a.lit >= need) { a.stun = BAL.stunTime; a.lit = 0; a.dash = 0; this.audio.zap(); this.msg(`${SPECS[a.kind].name} stunned!`, 2); } }
    else a.lit = Math.max(0, a.lit - dt * 0.6);
    if (ctl.transT > 0 || a.stun > 0) { a.speed = 0; }
    else {
      // movement
      a.yaw -= it.turn || 0; ctl.camPitch = clamp(ctl.camPitch - (it.pitch || 0), -0.6, 0.4);
      let mx = it.mx || 0, mz = it.mz || 0; const l = Math.hypot(mx, mz); if (l > 1) { mx /= l; mz /= l; }
      const diff = 0.9 + 0.03 * this.hour; let sp = SPECS[a.kind].speed * diff;
      if (a.dash > 0) { a.dash -= dt; sp = BAL.dashSpeed; if (a.litNow) a.dash = 0; }
      if (a.litNow && a.immune <= 0) sp *= a.kind === "freddy" ? 0.8 : BAL.litSlow;
      const fx = Math.sin(a.yaw), fz = Math.cos(a.yaw), rx = -Math.cos(a.yaw), rz = Math.sin(a.yaw);
      const ox = a.x, oz = a.z;
      this.moveBody(a, (fx * mz + rx * mx) * sp * dt, (fz * mz + rz * mx) * sp * dt, 0.34, a.kind);
      a.speed = Math.hypot(a.x - ox, a.z - oz) / Math.max(dt, 1e-4);
      a.stepAcc += a.speed * dt; if (a.stepAcc > (a.dash > 0 ? 1.4 : 1.05)) { a.stepAcc = 0; this.audio.clank(a.x, a.z, a.kind === "freddy" ? 1.2 : 1, a.kind === "freddy" ? 0.8 : 1); }
      if (it.ability) this.useAbility(a);
    }
    // eyes glow when active and hunting
    for (const k of KINDS) this.anims[k].rig.setGlow(k === ctl.active && this.anims[k].stun <= 0 && this.state !== "menu");
  }
  useAbility(a) {
    const ctl = this.ctl, g = this.guard; const human = this.mode !== "soloGuard";
    if (ctl.abilityCd > 0) { if (human) this.msg(`Ability ready in ${Math.ceil(ctl.abilityCd)}s`, 1.2, "anim"); return; }
    const k = a.kind, cd = BAL.abilityCd[k];
    if (k === "freddy") { ctl.revealT = 4.5; ctl.abilityCd = cd; this.audio.laugh(a.x, a.z); this.msg("You hear laughter...", 2.5, "guard"); if (!human) this.ai.lastKnown = { x: g.x, z: g.z, t: this.time }; }
    else if (k === "bonnie") {
      const d = Math.hypot(g.x - a.x, g.z - a.z);
      this.fixtures.forEach((f) => { if (Math.hypot(f.x - a.x, f.z - a.z) < 13) f.killT = 9; });
      if (d < 16) { g.blackout = 4.5; this.msg("Your flashlight dies!", 2, "guard"); }
      ctl.abilityCd = cd; this.audio.buzz(a.x, a.z, 0.4); this.audio.thud(0.4);
    } else if (k === "chica") {
      const b = this.props.breakers.find((b) => Math.hypot(b.x - a.x, b.z - a.z) < 3.2);
      if (!b) { if (human) this.msg("Get close to a breaker box", 1.5, "anim"); return; }
      b.jam = 45; b.led.material = this.M.ledRed; this.power = Math.max(0, this.power - 10); ctl.abilityCd = cd; this.audio.zap(); this.msg(`Something is tampering with the ${b.room} breaker`, 3, "guard");
    } else if (k === "foxy") { a.dash = BAL.dashTime; ctl.abilityCd = cd; this.audio.clank(a.x, a.z, 1.4); }
    if (human) this.msg(`${SPECS[k].ability}!`, 1.5, "anim");
  }

  /* ---------------- AI: animatronics director ---------------- */
  animAI(dt) {
    const ai = this.ai, ctl = this.ctl, g = this.guard, grid = this.grid; const a = this.anims[ctl.active];
    const it = { mx: 0, mz: 0, turn: 0, ability: false, switchTo: null };
    const d = Math.hypot(g.x - a.x, g.z - a.z);
    const facing = Math.abs(angDiff(a.yaw, Math.atan2(g.x - a.x, g.z - a.z))) < 1.2;
    const lit = g.flashWorks && d < 16;
    const sees = g.alive && grid.los(a.x, a.z, g.x, g.z) && (d < 3.5 || (facing && (d < 13 || lit)));
    if (sees) { ai.lastKnown = { x: g.x, z: g.z, t: this.time }; ai.lastSeenT = this.time; }
    if (ai.lastKnown && this.time - ai.lastKnown.t > 14) ai.lastKnown = null;
    // decide target
    let target = null, chase = false;
    if (sees) { target = { x: g.x, z: g.z }; chase = true; }
    else if (ai.lastKnown) target = ai.lastKnown;
    else {
      ai.patrolT -= dt;
      if (!ai.goal || ai.patrolT <= 0 || Math.hypot(ai.goal.x - a.x, ai.goal.z - a.z) < 1) {
        const r = Math.random(); let ri;
        if (r < 0.35) ri = ROOMS.findIndex((x) => ["wcorr", "ecorr", "southhall"].includes(x.id) && Math.random() < 0.5); // pressure the office
        if (ri == null || ri < 0) { const b = this.props.breakers[(Math.random() * this.props.breakers.length) | 0]; if (r < 0.6) ai.goal = { x: b.x + (b.yaw > 0 ? 1.2 : -1.2), z: b.z }; else { ri = (Math.random() * ROOMS.length) | 0; ai.goal = grid.randomFloorInRoom(ri); } }
        else ai.goal = grid.randomFloorInRoom(ri);
        ai.patrolT = 18 + Math.random() * 10;
      }
      target = ai.goal;
    }
    if (ai.lastKnown && Math.hypot(ai.lastKnown.x - a.x, ai.lastKnown.z - a.z) < 1.2 && !sees) ai.lastKnown = null;
    // office door camping: if target is inside office behind closed door, wait by door
    const tRoom = ROOMS[grid.roomAt(target.x, target.z)]?.id;
    if (tRoom === "office") { const open = grid.secDoors.filter((s) => !s.closed); if (!open.length) { const s = grid.secDoors[(this.time / 12 | 0) % 2]; target = { x: s.side === "L" ? 15.3 : 24.7, z: 46.5 }; } }
    // path follow
    a.pathT -= dt;
    if (!a.path || a.pathT <= 0) { a.path = grid.path(a.x, a.z, target.x, target.z); a.pathT = chase ? 0.35 : 1.2; a.pathI = 1; }
    let wp = target;
    if (a.path && a.path.length > 1) { while (a.pathI < a.path.length - 1 && Math.hypot(a.path[a.pathI].x - a.x, a.path[a.pathI].z - a.z) < 0.45) a.pathI++; wp = a.path[Math.min(a.pathI, a.path.length - 1)]; }
    if (chase && d < 5) wp = { x: g.x, z: g.z };
    const want = Math.atan2(wp.x - a.x, wp.z - a.z); const dy = angDiff(a.yaw, want);
    it.turn = -clamp(dy, -dt * 5, dt * 5);
    const dist = Math.hypot(wp.x - a.x, wp.z - a.z);
    it.mz = Math.abs(dy) < 1.0 && dist > 0.2 ? 1 : 0.15;
    // abilities
    ai.abilityT -= dt;
    if (ctl.abilityCd <= 0 && ai.abilityT <= 0) {
      if (a.kind === "foxy" && sees && d < 13 && d > 2.5) it.ability = true;
      if (a.kind === "bonnie" && sees && d < 12) it.ability = true;
      if (a.kind === "freddy" && this.time - ai.lastSeenT > 16) it.ability = true;
      if (a.kind === "chica" && this.props.breakers.some((b) => Math.hypot(b.x - a.x, b.z - a.z) < 3 && b.jam <= 0)) it.ability = true;
      if (it.ability) ai.abilityT = 2;
    }
    // switching
    ai.switchT -= dt;
    const ref = ai.lastKnown || (sees ? g : { x: 20, z: 46 });
    if (ctl.switchCd <= 0 && (a.stun > 0.5 || (!sees && ai.switchT <= 0))) {
      let best = null, bd = Math.hypot(ref.x - a.x, ref.z - a.z) - 7;
      for (const k of KINDS) { if (k === ctl.active) continue; const b = this.anims[k]; const dd = Math.hypot(ref.x - b.x, ref.z - b.z) + Math.random() * 4; if (dd < bd) { bd = dd; best = k; } }
      if (a.stun > 0.5 && !best) best = KINDS.filter((k) => k !== ctl.active)[(Math.random() * 3) | 0];
      if (best) { it.switchTo = best; ai.goal = null; }
      ai.switchT = 22 + Math.random() * 14;
    }
    return it;
  }

  /* ---------------- AI: guard ---------------- */
  guardAI(dt) {
    const g = this.guard, gai = this.gai, grid = this.grid; const a = this.anims[this.ctl.active];
    const it = { mx: 0, mz: 0, look: [0, 0], sprint: false, flash: false, interact: false, interactHit: false, hallLight: false, camExit: false, camNext: false, camPrev: false, camNum: 0 };
    if (g.onCams) { gai.camT = (gai.camT || 0) - dt; if (gai.camT <= 0) { it.camNext = true; gai.camT = 1.5; } gai.officeT -= dt; if (gai.officeT <= 0 || this.power < 30) it.camExit = true; return it; }
    const d = Math.hypot(a.x - g.x, a.z - g.z); const los = grid.los(g.x, g.z, a.x, a.z);
    const facing = Math.abs(angDiff(g.yaw, Math.atan2(a.x - g.x, a.z - g.z))) < 1.1;
    const sees = los && (d < 4 || (facing && d < 15)) && a.stun <= 0; const hears = a.speed > 0.5 && d < 9;
    const inOffice = g.inOffice;
    let target = null, aim = null;
    if (inOffice) {
      // door logic
      for (const s of grid.secDoors) {
        const dx = s.side === "L" ? 15.8 : 24.2; const dd = Math.hypot(a.x - dx, a.z - 46.5);
        if (dd < 5 && !s.closed && !this.powerOut && ROOMS[grid.roomAt(a.x, a.z)]?.id !== "office") { const pos = { x: s.side === "L" ? 17.3 : 22.7, z: 44.9 }; target = pos; aim = { x: s.side === "L" ? 16 : 24, z: 44.75 }; if (Math.hypot(pos.x - g.x, pos.z - g.z) < 0.9) { this.toggleDoor(s); } gai.closeT[s.side] = 4; }
        if (s.closed) { gai.closeT[s.side] -= dt; if (dd > 8 && gai.closeT[s.side] <= 0) { const pos = { x: s.side === "L" ? 17.3 : 22.7, z: 44.9 }; target = target || pos; if (Math.hypot(pos.x - g.x, pos.z - g.z) < 0.9) this.toggleDoor(s); } }
      }
    }
    if (!target) {
      if (sees || (hears && d < 5)) { gai.flee = 3.5; gai.threat = { x: a.x, z: a.z }; }
      gai.flee -= dt;
      if (gai.flee > 0 && !inOffice) {
        // choose flee point: room center far from threat
        if (!gai.fleeGoal || gai.pathT <= 0) {
          let best = null, bs = -1e9; for (let i = 0; i < ROOMS.length; i++) { const r = ROOMS[i].r; const c = { x: (r[0] + r[2]) / 2, z: (r[1] + r[3]) / 2 }; const s = Math.hypot(c.x - gai.threat.x, c.z - gai.threat.z) - Math.hypot(c.x - g.x, c.z - g.z) * 0.6 + (ROOMS[i].id === "office" ? 6 : 0); if (s > bs) { bs = s; best = c; } }
          gai.fleeGoal = best; gai.path = null;
        }
        target = gai.fleeGoal; it.sprint = g.stamina > 0.6;
        if (d < 7 && g.battery > 12 && sees) { aim = { x: a.x, z: a.z }; target = null; if (!g.flashOn) it.flash = true; it.mz = -0.6; }
      } else {
        gai.fleeGoal = null;
        if (g.flashOn && !sees && Math.random() < dt * 0.5) it.flash = true;
        const avail = this.props.breakers.filter((b) => b.cooldown <= 0 && b.jam <= 0);
        if (inOffice && this.power > 55 && gai.officeT > 0) { gai.officeT -= dt; target = { x: 20, z: 47.3 }; if (Math.hypot(g.x - 20, g.z - 47.3) < 0.6 && Math.random() < dt * 0.4 && !this.powerOut) { g.onCams = true; gai.officeT = 5; } }
        else if (avail.length && (this.power < 85 || !inOffice)) {
          avail.sort((p, q) => Math.hypot(p.x - g.x, p.z - g.z) - Math.hypot(q.x - g.x, q.z - g.z)); const b = avail[0]; const off = b.yaw > 0 ? 0.8 : -0.8; target = { x: b.x + off, z: b.z };
          if (Math.hypot(target.x - g.x, target.z - g.z) < 0.5) { aim = { x: b.x, z: b.z }; target = null; it.interact = true; }
        } else { target = { x: 20, z: 46.8 }; if (inOffice) gai.officeT = 10; }
      }
    }
    if (target) {
      gai.pathT = (gai.pathT || 0) - dt; if (!gai.path || gai.pathT <= 0 || gai.pathGoal !== target) { gai.path = grid.path(g.x, g.z, target.x, target.z); gai.pathT = 0.8; gai.pathI = 1; gai.pathGoal = target; }
      let wp = target; if (gai.path && gai.path.length > 1) { while (gai.pathI < gai.path.length - 1 && Math.hypot(gai.path[gai.pathI].x - g.x, gai.path[gai.pathI].z - g.z) < 0.45) gai.pathI++; wp = gai.path[Math.min(gai.pathI, gai.path.length - 1)]; }
      const want = Math.atan2(wp.x - g.x, wp.z - g.z); const dy = angDiff(g.yaw, want); it.look[0] = -clamp(dy, -dt * 6, dt * 6);
      it.mz = Math.abs(dy) < 0.9 && Math.hypot(wp.x - g.x, wp.z - g.z) > 0.15 ? 1 : 0;
      const dark = !this.fixtures.some((f) => f.on > 0.5 && Math.hypot(f.x - g.x, f.z - g.z) < 5);
      if (dark && !g.flashOn && g.battery > 30 && Math.random() < dt) it.flash = true;
    }
    if (aim) { const want = Math.atan2(aim.x - g.x, aim.z - g.z); it.look[0] = -clamp(angDiff(g.yaw, want), -dt * 7, dt * 7); const tp = aim === this.anims ? 0 : -0.05; it.look[1] = (g.pitch - tp) * 0.2; if (it.interact && !target) it.interact = true; }
    return it;
  }

  /* ---------------- jumpscare / end ---------------- */
  startJump(a) {
    const g = this.guard; g.alive = false; g.onCams = false; this.state = "jumpscare"; this.jump = { a, t: 0 };
    this.audio.scream(); this.shake = 1;
    const ang = Math.atan2(a.x - g.x, a.z - g.z); g.yaw = ang; g.pitch = 0.08;
    a.x = g.x + Math.sin(ang) * 1.3; a.z = g.z + Math.cos(ang) * 1.3; a.yaw = ang + Math.PI; g.pitch = 0.24;
  }
  updateJump(dt) {
    const j = this.jump; j.t += dt; this.shake = Math.max(0, 1 - j.t * 0.4);
    if (j.t > 1.9 && !this.result) this.endMatch("anim");
  }
  endMatch(winner) {
    this.result = { winner, hour: this.hour, power: Math.round(this.power), time: this.clock }; this.state = "end"; this.input.unlock();
    if (winner === "guard") { this.audio.chime(); }
  }

  /* ---------------- visuals ---------------- */
  updateFixtures(dt) {
    const bonnieKill = this.state !== "menu";
    for (const f of this.fixtures) {
      f.killT = Math.max(0, (f.killT || 0) - dt);
      let on = 1; const t = this.time + f.seed;
      if (f.kind === "broken") on = (Math.sin(t * 13) * Math.sin(t * 7.3) > 0.55 || (Math.sin(t * 0.7) > 0.8 && Math.random() > 0.3)) ? 1 : 0.02;
      else if (f.kind === "dim") on = 0.9 + 0.1 * Math.sin(t * 40) * (Math.sin(t * 0.3) > 0.9 ? 1 : 0);
      else { on = Math.random() < 0.004 ? 0.2 : 1; if (Math.sin(t * 0.21) > 0.985) on = Math.random() > 0.5 ? 1 : 0.05; }
      if (f.kind === "office" && this.powerOut) on = 0;
      if (f.killT > 0 && bonnieKill) on = f.killT < 1 ? (Math.random() > 0.5 ? 1 : 0) : 0;
      if (this.powerOut && f.kind !== "stage") on *= Math.random() < 0.02 ? 0.3 : 0; // power out: everything dark except flicker
      f.on = f.on + (on - f.on) * Math.min(1, dt * 30);
      f.mat.emissiveIntensity = f.base * f.on + 0.02;
    }
    for (const b of this.props.fans) b.rotation.z += dt * (this.powerOut ? 1 : 22);
    this.T.static.offset.set(Math.random(), Math.random());
    // doors anim
    for (const d of this.grid.secDoors) { const target = d.closed ? 0 : 1; d.anim += (target - d.anim) * Math.min(1, dt * 9); d.mesh.position.y = d.anim * 2.35; }
    const B = this.props.buttons; for (const side of ["L", "R"]) { const d = this.grid.secDoors.find((s) => s.side === side); B[side].doorBtn.material.emissiveIntensity = d.closed ? 2.5 : 0.15; B[side].lightBtn.material.emissiveIntensity = this.hall[side] ? 2.5 : 0.08; this.hallLights[side].intensity = this.hall[side] ? 30 : 0; }
    this.camStatic = Math.max(0, (this.camStatic || 0) - dt * 1.4);
  }
  animateWorld(dt) {
    const g = this.guard;
    for (const k of KINDS) {
      const a = this.anims[k]; const R = a.rig; const targetY = this.grid.heightAt(a.x, a.z); a.y += (targetY - a.y) * Math.min(1, dt * 8);
      R.root.position.set(a.x, a.y, a.z); R.root.rotation.y = a.yaw;
      let state = a.stun > 0 ? "stunned" : a.speed > 0.2 ? "walk" : "idle"; let lookYaw = 0, jaw = 0;
      if (this.jump && this.jump.a === a) { state = "jumpscare"; }
      else if (this.state !== "menu") {
        const dx = g.x - a.x, dz = g.z - a.z, d = Math.hypot(dx, dz);
        if (d < 9 && (k === this.ctl.active || d < 5) && this.grid.los(a.x, a.z, g.x, g.z)) { lookYaw = clamp(angDiff(a.yaw, Math.atan2(dx, dz)), -1.1, 1.1); if (k === this.ctl.active && d < 4) jaw = 0.25; }
      }
      animateRig(R, dt, { speed: a.speed, state, lookYaw, jaw, t: this.jump?.t });
    }
    // guard body
    const gr = this.guardRig; gr.root.position.set(g.x, 0, g.z); gr.root.rotation.y = g.yaw; gr.root.visible = true;
    animateRig(gr, dt, { speed: g.speed, state: g.sprinting ? "run" : "walk", lookYaw: 0 });
    gr.head.rotation.x = -g.pitch * 0.6;
    if (!g.alive && this.state === "end") { gr.root.rotation.z = 0; }
  }
  poolLights(cam) {
    const px = cam.position.x, pz = cam.position.z;
    const scored = this.fixtures.map((f) => ({ f, s: Math.hypot(f.x - px, f.z - pz) - (f.on > 0.3 ? 0 : 6) + (this.grid.los(px, pz, f.x, f.z) ? 0 : 4) })).sort((a, b) => a.s - b.s);
    const P = { warm: [0xffbd7a, 14, 11], dim: [0xffc690, 6, 9], fluo: [0xd6ffe6, 13, 12], broken: [0xd6ffe6, 11, 11], office: [0xffcf98, 9, 9], stage: [0xd8c0ff, 8, 12] };
    this.pool.forEach((l, i) => { const e = scored[i]; if (!e) { l.intensity = 0; return; } const f = e.f, p = P[f.kind]; l.color.setHex(p[0]); l.intensity = p[1] * f.on; l.distance = p[2]; l.position.set(f.x, f.y - 0.12, f.z); });
  }
  viewports() {
    const W = this.container.clientWidth, H = this.container.clientHeight;
    if (this.mode === "split" && this.state !== "menu") return [{ x: 0, y: 0, w: Math.floor(W / 2) - 1, h: H, role: "guard" }, { x: Math.floor(W / 2) + 1, y: 0, w: W - Math.floor(W / 2) - 1, h: H, role: "anim" }];
    return [{ x: 0, y: 0, w: W, h: H, role: this.state === "menu" ? "menu" : this.humanRole() }];
  }
  render(dt) {
    const r = this.renderer; r.setViewport(0, 0, this.container.clientWidth, this.container.clientHeight); r.setScissorTest(false); r.setRenderTarget(null); r.clear();
    const g = this.guard; const vps = this.viewports();
    // flashlight
    const eye = new THREE.Vector3(g.x, 1.62 + Math.sin(g.bob) * 0.03, g.z);
    const fwd = new THREE.Vector3(Math.sin(g.yaw) * Math.cos(g.pitch), Math.sin(g.pitch), Math.cos(g.yaw) * Math.cos(g.pitch));
    const fon = g.flashWorks && g.alive && !g.onCams && this.state !== "menu";
    const flick = g.battery < 15 ? (Math.random() < 0.1 ? 0.2 : 1) : 1;
    this.flash.intensity = fon ? 55 * flick : 0;
    if (this.state === "jumpscare" && this.jump) { const ja = this.jump.a; this.flash.intensity = 30 * (Math.random() < 0.15 ? 0.3 : 1); this.flash.position.set(g.x, 1.3, g.z); this.flash.target.position.set(ja.x, 1.9, ja.z); ja.rig.setGlow(true); } this.fpLens.material.color.setScalar(fon ? 6 * flick : 0.1); const rgt = new THREE.Vector3(-Math.cos(g.yaw), 0, Math.sin(g.yaw));
    this.flash.position.copy(eye).addScaledVector(rgt, 0.18).add(new THREE.Vector3(0, -0.18, 0)); this.flash.target.position.copy(eye).addScaledVector(fwd, 6);
    this.beam.visible = false; this.beam.position.copy(this.flash.position); this.beam.lookAt(this.flash.target.position);
    // guard camera
    const fc = this.fpCam; fc.position.copy(eye); fc.rotation.set(g.pitch, g.yaw + Math.PI, 0);
    if (this.shake > 0) { fc.rotation.x += (Math.random() - 0.5) * 0.06 * this.shake; fc.rotation.y += (Math.random() - 0.5) * 0.06 * this.shake; }
    this.fpFlash.position.set(0.24 + Math.sin(g.bob * 0.5) * 0.012, -0.25 + Math.abs(Math.cos(g.bob * 0.5)) * 0.01, -0.45);
    // anim camera (third person)
    const a = this.anims[this.ctl.active];
    const ay = a.yaw, pitch = this.ctl.camPitch; const back = 2.9, up = 2.3;
    const head = new THREE.Vector3(a.x, a.y + 1.95, a.z);
    const want = new THREE.Vector3(a.x - Math.sin(ay) * back * Math.cos(pitch) - Math.cos(ay) * 0.75, a.y + up - Math.sin(pitch) * 1.4, a.z - Math.cos(ay) * back * Math.cos(pitch) + Math.sin(ay) * 0.75);
    let t = 1; for (let s = 1; s <= 20; s++) { const p = head.clone().lerp(want, s / 20); if (this.grid.solidWall(this.grid.cellAt(p.x, p.z)) || p.y > 2.85) { t = Math.max(0.05, (s - 1.5) / 20); break; } }
    const cp = head.clone().lerp(want, t); this.animCam.position.lerp(cp, this.animCamInit ? Math.min(1, dt * 14) : 1); this.animCamInit = true;
    this.animCam.lookAt(a.x + Math.sin(ay) * 2.2, a.y + 1.45 + Math.sin(pitch) * 1.5, a.z + Math.cos(ay) * 2.2);
    // cctv
    const c = CAMS[g.cam]; const sweep = Math.sin(this.time * 0.35) * 0.35;
    this.cctvCam.position.set(c[0], 2.75, c[1]); const lx = c[2] - c[0], lz = c[3] - c[1]; const ang = Math.atan2(lx, lz) + sweep; this.cctvCam.lookAt(c[0] + Math.sin(ang) * 5, 1.0, c[1] + Math.cos(ang) * 5);
    // menu cam
    if (this.state === "menu") {
      const mc = this.menuCam; const tt = this.time;
      if (this.menuView === "guard") { this.guard.x = 16; this.guard.z = 16.2; this.guard.yaw = 0.25 + Math.sin(tt * 0.4) * 0.45; this.guard.speed = 0; mc.position.set(16.2, 1.45, 18.6); mc.lookAt(16, 1.05, 16.2); }
      else { mc.position.set(16 + Math.sin(tt * 0.12) * 3.2, 1.55 + Math.sin(tt * 0.2) * 0.1, 11.5 + Math.cos(tt * 0.12) * 0.8); mc.lookAt(16, 1.55, 4.6); this.guard.x = 20; this.guard.z = 46.4; }
    }
    r.shadowMap.needsUpdate = true;
    vps.forEach((vp, i) => {
      const post = this.posts[i]; const U = post.u; let cam;
      const guardView = vp.role === "guard", animView = vp.role === "anim", menu = vp.role === "menu";
      this.guardRig.root.visible = !guardView || g.onCams || !g.alive && false; this.fpFlash.visible = guardView && !g.onCams && g.alive;
      this.beam.visible = fon && !guardView; this.beam.material.uniforms.k.value = 0.1;
      U.cctv.value = 0; U.nv.value = 0; U.fear.value = 0; U.stat.value = 0; U.flash.value = 0; U.dead.value = 0; U.exposure.value = 1.0; U.sat.value = 0.86; U.vig.value = 0.6; U.ca.value = 0.002;
      this.hemi.intensity = 0.13; this.scene.fog.density = 0.045; this.stageSpot.intensity = this.powerOut ? 0 : 40;
      if (menu) { cam = this.menuCam; this.hemi.intensity = 0.08; U.exposure.value = 1.15; this.guardRig.root.visible = this.menuView === "guard"; if (this.menuView === "guard") this.hemi.intensity = 0.5; }
      else if (guardView) {
        if (g.onCams) { cam = this.cctvCam; U.cctv.value = 1; this.hemi.intensity = 0.55; U.exposure.value = 1.5; U.stat.value = Math.max(this.camStatic, 0.025 + (Math.hypot(a.x - c[0], a.z - c[1]) < 6 ? 0.12 : 0) * Math.random()); this.scene.fog.density = 0.03; }
        else { cam = this.fpCam; U.fear.value = g.fear * 0.6; U.exposure.value = 1.05; }
        if (this.state === "jumpscare") { U.fear.value = 0.45; U.ca.value = 0.0035; U.exposure.value = 1.2; }
        if (this.state === "end") U.dead.value = this.result?.winner === "anim" ? 0.9 : 0;
      } else if (animView) {
        cam = this.animCam; this.hemi.intensity = 0.7; U.nv.value = 0.55; U.exposure.value = 1.25; U.sat.value = 0.7; this.scene.fog.density = 0.035; U.stat.value = this.ctl.transT > 0 ? this.ctl.transT / 0.9 : 0;
        if (a.stun > 0) { U.stat.value = Math.max(U.stat.value, 0.25 + Math.random() * 0.2); U.sat.value = 0.2; }
        if (this.ctl.revealT > 0) this.guardRig.root.visible = true;
      }
      cam.aspect = vp.w / vp.h; cam.updateProjectionMatrix();
      this.poolLights(cam);
      post.render(this.scene, cam, vp, this.time);
      r.shadowMap.needsUpdate = false;
    });
  }

  /* ---------------- HUD snapshot ---------------- */
  hud() {
    const g = this.guard, ctl = this.ctl; const a = this.anims[ctl.active];
    const pings = ctl.pings.filter((p) => this.time - p.t < 2.5).map((p) => { const ang = angDiff(a.yaw, Math.atan2(p.x - a.x, p.z - a.z)); return { ang, dist: Math.hypot(p.x - a.x, p.z - a.z), age: this.time - p.t, kind: p.kind }; }).filter((p) => p.dist < (p.kind === "breaker" ? 32 : 22));
    let reveal = null; if (ctl.revealT > 0) reveal = { ang: angDiff(a.yaw, Math.atan2(g.x - a.x, g.z - a.z)), dist: Math.hypot(g.x - a.x, g.z - a.z) };
    const onCamAnims = g.onCams ? KINDS.filter((k) => { const b = this.anims[k]; const c = CAMS[g.cam]; return Math.hypot(b.x - c[0], b.z - c[1]) < 14 && this.grid.los(c[0], c[1], b.x, b.z); }) : [];
    return {
      state: this.state, mode: this.mode, introT: this.introT, hour: this.hour, clock: this.clock, nightLen: this.opts?.nightLen || 360, night: this.opts?.night || 1,
      guard: { power: this.power, powerOut: this.powerOut, usage: this.usage || 1, battery: g.battery, stamina: g.stamina / BAL.staminaMax, exhausted: g.exhausted, flashOn: g.flashOn && g.flashWorks, blackout: g.blackout, onCams: g.onCams, cam: g.cam, camName: CAM_NAMES[g.cam], prompt: g.prompt, hold: g.hold / BAL.breakerHold, doors: Object.fromEntries(this.grid.secDoors.map((d) => [d.side, d.closed])), inOffice: g.inOffice, room: ROOMS[this.grid.roomAt(g.x, g.z)]?.name, fear: g.fear, watched: onCamAnims },
      anim: { active: ctl.active, switchCd: ctl.switchCd, switchMax: BAL.switchCd, abilityCd: ctl.abilityCd, abilityMax: BAL.abilityCd[ctl.active], ability: SPECS[ctl.active].ability, abilityDesc: SPECS[ctl.active].abilityDesc, stun: a.stun, lit: a.litNow, dash: a.dash > 0, pings, reveal, room: ROOMS[this.grid.roomAt(a.x, a.z)]?.name, list: KINDS.map((k) => ({ k, name: SPECS[k].name, stun: this.anims[k].stun > 0, room: ROOMS[this.grid.roomAt(this.anims[k].x, this.anims[k].z)]?.name })), watched: g.onCams && KINDS.some((k) => k === ctl.active) && (() => { const c = CAMS[g.cam]; return Math.hypot(a.x - c[0], a.z - c[1]) < 14 && this.grid.los(c[0], c[1], a.x, a.z); })() },
      messages: this.messages.map((m) => ({ t: m.t, who: m.who })), result: this.result, locked: this.input.locked, paused: this.paused,
      viewports: this.viewports().map((v) => ({ ...v })),
    };
  }
}
