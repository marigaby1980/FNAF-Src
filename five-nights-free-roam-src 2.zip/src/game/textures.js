import * as THREE from "three";
import { fbm, vnoise, h2, clamp, smooth, mix, rng } from "./noise.js";

class TB {
  constructor(w, h) {
    this.w = w; this.h = h;
    this.c = new Float32Array(w * h * 3);
    this.hg = new Float32Array(w * h);
    this.r = new Float32Array(w * h).fill(0.8);
  }
  px(i, r, g, b, hh, ro) { const j = i * 3; this.c[j] = r; this.c[j + 1] = g; this.c[j + 2] = b; this.hg[i] = hh; this.r[i] = ro; }
  canvas() {
    const cv = document.createElement("canvas"); cv.width = this.w; cv.height = this.h;
    const ctx = cv.getContext("2d"); const id = ctx.createImageData(this.w, this.h); const d = id.data;
    for (let i = 0; i < this.w * this.h; i++) {
      d[i * 4] = clamp(this.c[i * 3], 0, 1) * 255; d[i * 4 + 1] = clamp(this.c[i * 3 + 1], 0, 1) * 255;
      d[i * 4 + 2] = clamp(this.c[i * 3 + 2], 0, 1) * 255; d[i * 4 + 3] = 255;
    }
    ctx.putImageData(id, 0, 0); return cv;
  }
  normal(str = 2, wrapY = true) {
    const { w, h, hg } = this; const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
    const ctx = cv.getContext("2d"); const id = ctx.createImageData(w, h); const d = id.data;
    const H = (x, y) => { x = (x + w) % w; y = wrapY ? (y + h) % h : clamp(y, 0, h - 1); return hg[y * w + x]; };
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const dx = (H(x + 1, y) - H(x - 1, y)) * str, dy = (H(x, y + 1) - H(x, y - 1)) * str;
      let nx = -dx, ny = dy, nz = 1; const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
      const i = (y * w + x) * 4; d[i] = (nx * 0.5 + 0.5) * 255; d[i + 1] = (ny * 0.5 + 0.5) * 255; d[i + 2] = (nz * 0.5 + 0.5) * 255; d[i + 3] = 255;
    }
    ctx.putImageData(id, 0, 0); return cv;
  }
  rough() {
    const cv = document.createElement("canvas"); cv.width = this.w; cv.height = this.h;
    const ctx = cv.getContext("2d"); const id = ctx.createImageData(this.w, this.h); const d = id.data;
    for (let i = 0; i < this.w * this.h; i++) { const v = clamp(this.r[i], 0, 1) * 255; d[i * 4] = v; d[i * 4 + 1] = v; d[i * 4 + 2] = 0; d[i * 4 + 3] = 255; }
    ctx.putImageData(id, 0, 0); return cv;
  }
}
export function tex(cv, srgb = true, rep = 1) {
  const t = new THREE.CanvasTexture(cv);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.anisotropy = 8; t.repeat.set(rep, rep); return t;
}
function pack(tb, nstr = 2, wrapY = true) {
  return { map: tex(tb.canvas()), normalMap: tex(tb.normal(nstr, wrapY), false), roughnessMap: tex(tb.rough(), false) };
}

/* ---------- FLOORS ---------- */
function checkerFloor() {
  const W = 512, tb = new TB(W, W), T = 128;
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const tx = (x / T) | 0, ty = (y / T) | 0, lx = x % T, ly = y % T;
    const e = Math.min(lx, ly, T - 1 - lx, T - 1 - ly);
    const white = (tx + ty) & 1;
    const n = fbm(x / W * 4, y / W * 4, 4, 4, 5, 3), n2 = fbm(x / W * 32, y / W * 32, 32, 32, 2, 9);
    const tone = h2(tx, ty, 5) * 0.08;
    const grime = smooth(0.42, 0.78, n);
    let r, g, b;
    if (white) { r = 0.74 - tone; g = 0.71 - tone; b = 0.64 - tone * 1.2; } else { r = 0.03 + tone * 0.2; g = 0.03 + tone * 0.2; b = 0.035 + tone * 0.2; }
    const k = 0.9 + n2 * 0.18; r *= k; g *= k; b *= k;
    const dm = grime * (white ? 0.55 : 0.35);
    r = mix(r, 0.2, dm); g = mix(g, 0.15, dm); b = mix(b, 0.1, dm);
    let hh = smooth(0, 5, e) * 0.8 + n2 * 0.05, ro = 0.16 + grime * 0.55 + n2 * 0.12;
    if (e < 2.5) { r = 0.13; g = 0.12; b = 0.1; ro = 0.95; hh = 0; }
    tb.px(y * W + x, r, g, b, hh, ro);
  }
  // scuff marks
  const R = rng(77);
  for (let s = 0; s < 70; s++) {
    let x = R() * W, y = R() * W; const a = R() * 6.28, L = 10 + R() * 60;
    for (let t = 0; t < L; t++) { const i = (((y | 0) + W) % W) * W + (((x | 0) + W) % W); tb.c[i * 3] *= 0.7; tb.c[i * 3 + 1] *= 0.7; tb.c[i * 3 + 2] *= 0.7; tb.r[i] = Math.min(1, tb.r[i] + 0.3); x += Math.cos(a); y += Math.sin(a); }
  }
  return pack(tb, 3);
}
function smallTile() {
  const W = 512, tb = new TB(W, W), T = 64;
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const tx = (x / T) | 0, ty = (y / T) | 0, lx = x % T, ly = y % T, e = Math.min(lx, ly, T - 1 - lx, T - 1 - ly);
    const red = (tx + ty) & 1; const n = fbm(x / W * 5, y / W * 5, 5, 5, 5, 11);
    const gr = smooth(0.45, 0.8, n);
    let r = red ? 0.46 : 0.78, g = red ? 0.14 : 0.75, b = red ? 0.1 : 0.68;
    const t = h2(tx, ty, 2) * 0.06; r -= t; g -= t; b -= t;
    r = mix(r, 0.25, gr * 0.5); g = mix(g, 0.2, gr * 0.5); b = mix(b, 0.14, gr * 0.5);
    let hh = smooth(0, 4, e), ro = 0.22 + gr * 0.5;
    if (e < 2) { r = 0.3; g = 0.28; b = 0.24; hh = 0; ro = 0.9; }
    tb.px(y * W + x, r, g, b, hh, ro);
  }
  return pack(tb, 2.5);
}
function concreteFloor() {
  const W = 512, tb = new TB(W, W);
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const n = fbm(x / W * 6, y / W * 6, 6, 6, 6, 21), n2 = fbm(x / W * 40, y / W * 40, 40, 40, 2, 4);
    const oil = smooth(0.62, 0.75, fbm(x / W * 3, y / W * 3, 3, 3, 4, 8));
    const crack = Math.abs(fbm(x / W * 4, y / W * 4, 4, 4, 4, 33) - 0.5) < 0.006 ? 1 : 0;
    let v = 0.3 + n * 0.16 + n2 * 0.05; v *= 1 - oil * 0.55; if (crack) v *= 0.4;
    tb.px(y * W + x, v * 1.0, v * 0.98, v * 0.93, n2 * 0.4 - crack * 0.5, 0.85 - oil * 0.5);
  }
  return pack(tb, 2);
}
function woodFloor() {
  const W = 512, tb = new TB(W, W), P = 64;
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const plank = (x / P) | 0, lx = x % P; const off = h2(plank, 1, 3) * W;
    const yy = (y + off) % W; const seam = ((yy / 256) | 0);
    const g = fbm(x / W * 64, yy / W * 2, 64, 2, 3, 7 + plank);
    const ring = Math.sin(g * 30 + lx * 0.05) * 0.5 + 0.5;
    const tone = h2(plank, seam, 9) * 0.12;
    let r = 0.3 + ring * 0.08 - tone, gg = 0.17 + ring * 0.05 - tone * 0.6, b = 0.09 + ring * 0.02 - tone * 0.3;
    const wear = smooth(0.5, 0.8, fbm(x / W * 3, y / W * 3, 3, 3, 4, 5)); r = mix(r, 0.2, wear * 0.4); gg = mix(gg, 0.14, wear * 0.4); b = mix(b, 0.1, wear * 0.4);
    let hh = 0.8 + ring * 0.1, ro = 0.4 + wear * 0.35;
    if (lx < 2 || (yy % 256) < 2) { r *= 0.3; gg *= 0.3; b *= 0.3; hh = 0; ro = 0.9; }
    tb.px(y * W + x, r, gg, b, hh, ro);
  }
  return pack(tb, 2);
}
function carpet(palette, seed) {
  const W = 512, tb = new TB(W, W);
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const n = fbm(x / W * 64, y / W * 64, 64, 64, 2, seed), m = fbm(x / W * 4, y / W * 4, 4, 4, 4, seed + 3);
    const b0 = palette.base; const k = 0.8 + n * 0.4 - smooth(0.5, 0.8, m) * 0.25;
    tb.px(y * W + x, b0[0] * k, b0[1] * k, b0[2] * k, n, 0.98);
  }
  const cv = tb.canvas(); const ctx = cv.getContext("2d"); const R = rng(seed * 13);
  // tile-safe drawing: draw each shape 9 times offset
  const draw = (fn) => { for (let ox = -1; ox <= 1; ox++) for (let oy = -1; oy <= 1; oy++) { ctx.save(); ctx.translate(ox * W, oy * W); fn(); ctx.restore(); } };
  for (let i = 0; i < 70; i++) {
    const x = R() * W, y = R() * W, col = palette.acc[(R() * palette.acc.length) | 0], a = R() * 6.28, s = 8 + R() * 18, kind = (R() * 3) | 0;
    draw(() => {
      ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.globalAlpha = 0.75; ctx.lineWidth = 3;
      if (kind === 0) { ctx.beginPath(); for (let t = 0; t <= 20; t++) { const px = (t - 10) * s * 0.12, py = Math.sin(t * 0.8) * s * 0.3; t ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke(); }
      else if (kind === 1) { ctx.beginPath(); ctx.moveTo(0, -s * 0.5); ctx.lineTo(s * 0.45, s * 0.4); ctx.lineTo(-s * 0.45, s * 0.4); ctx.closePath(); ctx.stroke(); }
      else { ctx.beginPath(); ctx.arc(0, 0, s * 0.25, 0, 6.28); ctx.fill(); }
      ctx.restore();
    });
  }
  const t = { map: tex(cv), normalMap: tex(tb.normal(1.2), false), roughnessMap: tex(tb.rough(), false) };
  return t;
}
function ceiling() {
  const W = 512, tb = new TB(W, W), T = 256;
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const lx = x % T, ly = y % T, e = Math.min(lx, ly, T - 1 - lx, T - 1 - ly);
    const sp = h2(x, y, 4) > 0.93 ? 0.85 : 1; const n = fbm(x / W * 3, y / W * 3, 3, 3, 5, 44);
    const stain = smooth(0.6, 0.72, n); let r = 0.62 * sp, g = 0.6 * sp, b = 0.55 * sp;
    r = mix(r, 0.42, stain * 0.8); g = mix(g, 0.33, stain * 0.8); b = mix(b, 0.2, stain * 0.8);
    let hh = 0.6 + (sp < 1 ? -0.2 : 0), ro = 0.95;
    if (e < 5) { r = 0.16; g = 0.16; b = 0.16; hh = e < 5 ? 1 : 0; ro = 0.5; }
    tb.px(y * W + x, r, g, b, hh, ro);
  }
  return pack(tb, 1.5);
}

/* ---------- WALLS: 512 x 768 = 2m x 3m ---------- */
function plasterAt(x, y, W, seed) {
  const n = fbm(x / W * 4, y / W * 4, 4, 12, 5, seed);
  const drip = fbm(x / W * 24, y / W * 1.2, 24, 4, 3, seed + 5);
  const rust = smooth(0.48, 0.72, n + (drip - 0.5) * 0.35);
  return { n, drip, rust };
}
function wallMain(kind) {
  const W = 512, H = 768, tb = new TB(W, H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const hm = 3 - (y + 0.5) / 256, yb = H - y; const i = y * W + x;
    const n2 = fbm(x / W * 32, y / W * 32, 32, 48, 2, 3);
    const g = fbm(x / W * 5, y / W * 5, 5, 8, 4, 19); const grime = smooth(0.5, 0.8, g);
    let r, gg, b, hh = 0.5, ro = 0.85;
    if (hm < 0.12) { r = 0.05; gg = 0.045; b = 0.045; hh = 1; ro = 0.55; if (hm > 0.105) hh = 0.5; }
    else if (hm < 1.0) {
      if (kind === "tile") { // white tile lower
        const T = 32, lx = x % T, ly = yb % T, e = Math.min(lx, ly, T - 1 - lx, T - 1 - ly);
        r = 0.72; gg = 0.72; b = 0.68; hh = smooth(0, 3, e); ro = 0.15 + grime * 0.4; if (e < 1.5) { r = 0.35; gg = 0.33; b = 0.3; ro = 0.9; }
      } else if (kind === "block") {
        const bh = 51, bw = 102.4, row = ((yb) / bh) | 0, off = row % 2 ? bw / 2 : 0, bx = ((x + off) / bw) | 0;
        const lx = (x + off) % bw, ly = yb % bh, e = Math.min(lx, ly, bw - lx, bh - ly);
        const t = h2(bx, row, 8) * 0.05; r = 0.36 - t; gg = 0.4 - t; b = 0.35 - t; hh = smooth(0, 3, e) * 0.7 + n2 * 0.3; ro = 0.9; if (e < 2) { r = 0.25; gg = 0.26; b = 0.24; hh = 0; }
      } else { // brick
        const bh = 18, bw = 64, row = ((yb) / bh) | 0, off = row % 2 ? 32 : 0, bx = (((x + off) % W) / bw) | 0;
        const lx = (x + off) % bw, ly = yb % bh, e = Math.min(lx, ly, bw - 1 - lx, bh - 1 - ly);
        const t = h2(bx, row, 3), t2 = h2(bx, row, 6);
        r = 0.27 + t * 0.1; gg = 0.12 + t * 0.045; b = 0.085 + t * 0.03; if (t2 > 0.85) { r *= 0.7; gg *= 0.75; b *= 0.8; }
        const k = 0.85 + n2 * 0.3; r *= k; gg *= k; b *= k; hh = smooth(0, 3, e) * 0.8 + n2 * 0.25; ro = 0.9;
        if (e < 2.2) { r = 0.3; gg = 0.28; b = 0.25; hh = 0; ro = 0.95; }
      }
      r = mix(r, 0.1, grime * 0.65); gg = mix(gg, 0.08, grime * 0.65); b = mix(b, 0.06, grime * 0.65);
    } else if (hm < 1.3333) {
      const S = W / 12, sx = (x / S) | 0, sy = ((hm - 1.0) / 0.16667) | 0, lx = x % S, ly = ((hm - 1.0) % 0.16667) * 256, e = Math.min(lx, ly, S - lx, 42.67 - ly);
      const wh = (sx + sy) & 1; r = wh ? 0.75 : 0.035; gg = wh ? 0.73 : 0.035; b = wh ? 0.67 : 0.04; hh = smooth(0, 3, e); ro = 0.2 + grime * 0.3;
      r = mix(r, 0.25, grime * 0.4); gg = mix(gg, 0.2, grime * 0.4); b = mix(b, 0.14, grime * 0.4);
      if (e < 1.5) { r = 0.2; gg = 0.19; b = 0.17; hh = 0; ro = 0.9; }
    } else if (hm < 1.38) { r = 0.36; gg = 0.05; b = 0.05; hh = hm < 1.345 || hm > 1.37 ? 0.3 : 1; ro = 0.4; }
    else {
      const p = plasterAt(x, y, W, kind === "party" ? 41 : 29);
      if (kind === "party") { r = 0.08; gg = 0.055; b = 0.12; const k = 0.85 + p.n * 0.3; r *= k; gg *= k; b *= k; r = mix(r, 0.14, p.rust * 0.5); gg = mix(gg, 0.08, p.rust * 0.5); b = mix(b, 0.05, p.rust * 0.5); ro = 0.8; }
      else if (kind === "tile") { const T = 32, lx = x % T, ly = yb % T, e = Math.min(lx, ly, T - 1 - lx, T - 1 - ly); r = 0.7; gg = 0.71; b = 0.66; hh = smooth(0, 3, e); ro = 0.18; if (e < 1.5) { r = 0.36; gg = 0.34; b = 0.3; ro = 0.9; hh = 0; } r = mix(r, 0.35, p.rust * 0.6); gg = mix(gg, 0.27, p.rust * 0.6); b = mix(b, 0.16, p.rust * 0.6); ro += p.rust * 0.4; }
      else if (kind === "block") { const bh = 51, bw = 102.4, row = (yb / bh) | 0, off = row % 2 ? bw / 2 : 0; const lx = (x + off) % bw, ly = yb % bh, e = Math.min(lx, ly, bw - lx, bh - ly); r = 0.42; gg = 0.45; b = 0.4; hh = smooth(0, 3, e) * 0.7 + n2 * 0.3; if (e < 2) { r = 0.3; gg = 0.31; b = 0.28; hh = 0; } r = mix(r, 0.28, p.rust * 0.7); gg = mix(gg, 0.22, p.rust * 0.7); b = mix(b, 0.14, p.rust * 0.7); ro = 0.92; }
      else { // rusty grunge plaster like reference
        r = 0.46; gg = 0.37; b = 0.27; const k = 0.8 + p.n * 0.35; r *= k; gg *= k; b *= k;
        r = mix(r, 0.36, p.rust); gg = mix(gg, 0.17, p.rust); b = mix(b, 0.07, p.rust);
        const dk = smooth(0.55, 0.85, p.drip) * 0.45; r *= 1 - dk; gg *= 1 - dk; b *= 1 - dk; hh = p.n * 0.6 + n2 * 0.2; ro = 0.9;
      }
      const top = smooth(2.3, 3.0, hm) * 0.45; r *= 1 - top; gg *= 1 - top; b *= 1 - top;
    }
    tb.px(i, r, gg, b, hh, ro);
  }
  const cv = tb.canvas();
  if (kind === "party") {
    const ctx = cv.getContext("2d"); const R = rng(99); const topY = 768 - 1.4 * 256;
    const star = (x, y, s, c) => { ctx.fillStyle = c; ctx.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? s * 0.42 : s; ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } ctx.closePath(); ctx.fill(); };
    for (let k = 0; k < 55; k++) {
      const x = R() * W, y = 10 + R() * (topY - 20); const c = ["#a88a3a", "#8e3f4e", "#3f6680", "#a8a290", "#5e4280"][(R() * 5) | 0];
      ctx.globalAlpha = 0.22 + R() * 0.22;
      if (R() < 0.45) { for (const ox of [-W, 0, W]) star(x + ox, y, 6 + R() * 8, c); }
      else { ctx.fillStyle = c; ctx.save(); ctx.translate(x, y); ctx.rotate(R() * 3); ctx.fillRect(-4, -1.5, 8, 3); ctx.restore(); }
    }
    ctx.globalAlpha = 1;
  }
  return { map: tex(cv), normalMap: tex(tb.normal(2.2), false), roughnessMap: tex(tb.rough(), false) };
}

/* ---------- MATERIAL DETAIL TEXTURES ---------- */
function fur() {
  const W = 512, tb = new TB(W, W);
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const f = fbm(x / W * 96, y / W * 12, 96, 12, 3, 5), f2 = fbm(x / W * 180, y / W * 30, 180, 30, 2, 8);
    const blot = smooth(0.55, 0.85, fbm(x / W * 4, y / W * 4, 4, 4, 5, 2));
    const worn = smooth(0.62, 0.8, fbm(x / W * 8, y / W * 8, 8, 8, 4, 12));
    let v = 0.78 + f * 0.25 + f2 * 0.12 - blot * 0.35;
    tb.px(y * W + x, v, v * (1 - worn * 0.05), v * (1 - worn * 0.1), f * 0.7 + f2 * 0.4, 0.8 + blot * 0.15);
  }
  return pack(tb, 3.5);
}
function metal() {
  const W = 256, tb = new TB(W, W); const R = rng(3);
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const s = fbm(x / W * 2, y / W * 64, 2, 64, 3, 5); const rust = smooth(0.62, 0.8, fbm(x / W * 5, y / W * 5, 5, 5, 4, 9));
    let v = 0.55 + s * 0.2; tb.px(y * W + x, mix(v, 0.3, rust), mix(v, 0.18, rust), mix(v * 1.02, 0.1, rust), s, 0.35 + s * 0.2 + rust * 0.5);
  }
  for (let k = 0; k < 40; k++) { let x = R() * W, y = R() * W; const a = R() * 6.28; for (let t = 0; t < 30; t++) { const i = ((((y | 0) % W) + W) % W) * W + ((((x | 0) % W) + W) % W); tb.c[i * 3] += 0.15; tb.c[i * 3 + 1] += 0.15; tb.c[i * 3 + 2] += 0.15; x += Math.cos(a); y += Math.sin(a); } }
  return pack(tb, 1);
}
function woodGrain() {
  const W = 256, tb = new TB(W, W);
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const g = fbm(x / W * 2, y / W * 32, 2, 32, 4, 3); const ring = Math.sin(g * 40) * 0.5 + 0.5;
    tb.px(y * W + x, 0.32 + ring * 0.1, 0.19 + ring * 0.06, 0.1 + ring * 0.03, ring, 0.5);
  }
  return pack(tb, 1);
}
function cloth() {
  const W = 256, tb = new TB(W, W);
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const w = (Math.sin(x * 1.6) * Math.sin(y * 1.6)) * 0.5 + 0.5; const st = smooth(0.6, 0.8, fbm(x / W * 4, y / W * 4, 4, 4, 4, 7));
    const v = 0.86 + w * 0.06; tb.px(y * W + x, mix(v, 0.6, st), mix(v, 0.52, st), mix(v * 0.97, 0.4, st), w, 0.9);
  }
  return pack(tb, 0.8);
}
function hazard() {
  const W = 256, H = 64, tb = new TB(W, H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const s = ((x + y) / 32 | 0) & 1; const n = fbm(x / W * 8, y / H * 2, 8, 2, 4, 5); const chip = n > 0.66;
    let r = s ? 0.78 : 0.04, g = s ? 0.55 : 0.04, b = s ? 0.06 : 0.04; if (chip) { r = 0.35; g = 0.33; b = 0.32; }
    tb.px(y * W + x, r * (0.85 + n * 0.2), g * (0.85 + n * 0.2), b, chip ? 0 : 1, chip ? 0.5 : 0.6);
  }
  return pack(tb, 2);
}

/* ---------- DRAWN CANVASES ---------- */
export function drawLogo(ctx, cx, cy, R) {
  ctx.save(); ctx.translate(cx, cy);
  ctx.fillStyle = "#f3ece0"; ctx.beginPath(); ctx.arc(0, 0, R, 0, 6.283); ctx.fill();
  ctx.lineWidth = R * 0.07; ctx.strokeStyle = "#5a2a78"; ctx.beginPath(); ctx.arc(0, 0, R * 0.93, 0, 6.283); ctx.stroke();
  // bear
  ctx.fillStyle = "#7a4a26";
  for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(s * R * 0.3, -R * 0.12, R * 0.13, 0, 6.283); ctx.fill(); }
  ctx.beginPath(); ctx.ellipse(0, R * 0.08, R * 0.33, R * 0.29, 0, 0, 6.283); ctx.fill();
  ctx.fillStyle = "#c79a6a"; ctx.beginPath(); ctx.ellipse(0, R * 0.2, R * 0.16, R * 0.11, 0, 0, 6.283); ctx.fill();
  ctx.fillStyle = "#1a1210"; ctx.beginPath(); ctx.ellipse(0, R * 0.14, R * 0.06, R * 0.04, 0, 0, 6.283); ctx.fill();
  for (const s of [-1, 1]) { ctx.fillStyle = "#f7f3ea"; ctx.beginPath(); ctx.arc(s * R * 0.12, R * 0.0, R * 0.06, 0, 6.283); ctx.fill(); ctx.fillStyle = "#26387a"; ctx.beginPath(); ctx.arc(s * R * 0.12, R * 0.01, R * 0.03, 0, 6.283); ctx.fill(); }
  ctx.fillStyle = "#1a1210"; ctx.fillRect(-R * 0.13, -R * 0.52, R * 0.26, R * 0.28); ctx.fillRect(-R * 0.22, -R * 0.26, R * 0.44, R * 0.05);
  ctx.fillStyle = "#6b2f8c"; ctx.fillRect(-R * 0.13, -R * 0.33, R * 0.26, R * 0.05);
  // text on arcs
  const arcText = (txt, rad, start, dir) => {
    ctx.save(); ctx.font = `800 ${R * 0.17}px Arial Black, Arial, sans-serif`; ctx.fillStyle = "#5a2a78"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    const step = (dir * 0.23); let a = start - step * (txt.length - 1) / 2;
    for (const ch of txt) { ctx.save(); ctx.rotate(a); ctx.translate(0, -rad * dir); if (dir < 0) ctx.rotate(0); ctx.fillText(ch, 0, 0); ctx.restore(); a += step; }
    ctx.restore();
  };
  arcText("FREDBEAR'S", R * 0.72, 0, 1);
  arcText("FAZZERIA", R * 0.72, 0, -1);
  ctx.restore();
}
function logoTex() { const cv = document.createElement("canvas"); cv.width = cv.height = 256; const ctx = cv.getContext("2d"); ctx.fillStyle = "#8e3fbf"; ctx.fillRect(0, 0, 256, 256); drawLogo(ctx, 128, 128, 127); return tex(cv); }
function shirtTex(hex) {
  const cv = document.createElement("canvas"); cv.width = 512; cv.height = 512; const ctx = cv.getContext("2d");
  ctx.fillStyle = hex; ctx.fillRect(0, 0, 512, 512);
  // subtle fabric noise
  const id = ctx.getImageData(0, 0, 512, 512); for (let i = 0; i < id.data.length; i += 4) { const n = (h2(i, 3, 1) - 0.5) * 18; id.data[i] += n; id.data[i + 1] += n; id.data[i + 2] += n; } ctx.putImageData(id, 0, 0);
  // logo on front (u around 0.75 for sphere/cylinder front = +Z) -> placed where front maps
  drawLogo(ctx, 384, 200, 70);
  const t = tex(cv); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
function bibTex() {
  const cv = document.createElement("canvas"); cv.width = 512; cv.height = 512; const ctx = cv.getContext("2d");
  ctx.fillStyle = "#ece6d8"; ctx.fillRect(0, 0, 512, 512); const R = rng(5);
  for (let i = 0; i < 70; i++) { ctx.fillStyle = ["#e0457b", "#3c9bd6", "#e8b62c", "#7cc04a"][(R() * 4) | 0]; ctx.beginPath(); ctx.arc(R() * 512, R() * 512, 4 + R() * 4, 0, 6.28); ctx.fill(); }
  ctx.textAlign = "center"; ctx.font = "900 120px Arial Black, Impact, sans-serif"; ctx.lineWidth = 16; ctx.strokeStyle = "#f6f1e6";
  ctx.lineWidth = 22; ctx.strokeStyle = "#4a2a78"; ctx.lineJoin = "round";
  const L = [["LET'S", 190], ["EAT!!", 320]]; const cols = ["#8b3fbf", "#e0457b", "#e88a1a", "#3c9bd6", "#7cc04a"];
  for (const [w, y] of L) { let x = 256 - ctx.measureText(w).width / 2; for (let k = 0; k < w.length; k++) { const ch = w[k], cw = ctx.measureText(ch).width; ctx.save(); ctx.translate(x + cw / 2, y); ctx.rotate((R() - 0.5) * 0.25); ctx.strokeText(ch, 0, 0); ctx.fillStyle = cols[k % 5]; ctx.fillText(ch, 0, 0); ctx.restore(); x += cw; } }
  // bib silhouette: straight shoulders, neck notch, rounded hem
  ctx.globalCompositeOperation = "destination-in"; ctx.fillStyle = "#fff"; ctx.beginPath();
  ctx.moveTo(20, 0); ctx.lineTo(180, 0); ctx.arc(256, 0, 76, Math.PI, 0, true); ctx.lineTo(492, 0); ctx.lineTo(492, 300);
  ctx.bezierCurveTo(492, 470, 380, 505, 256, 505); ctx.bezierCurveTo(132, 505, 20, 470, 20, 300); ctx.closePath(); ctx.fill();
  ctx.globalCompositeOperation = "source-over";
  const t = tex(cv); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
function bandPoster() {
  const cv = document.createElement("canvas"); cv.width = 512; cv.height = 720; const ctx = cv.getContext("2d");
  const g = ctx.createLinearGradient(0, 0, 0, 720); g.addColorStop(0, "#d9b04a"); g.addColorStop(1, "#b0662c"); ctx.fillStyle = g; ctx.fillRect(0, 0, 512, 720);
  ctx.fillStyle = "#8a3a1e"; for (let y = 0; y < 720; y += 36) for (let x = (y / 36 % 2) * 40; x < 512; x += 80) ctx.fillRect(x, y, 74, 30);
  ctx.globalAlpha = 0.5; ctx.fillStyle = "#e8c860"; ctx.fillRect(0, 0, 512, 720); ctx.globalAlpha = 1;
  const face = (cx, cy, body, belly, eye, kind) => {
    ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(cx, cy + 190, 90, 120, 0, 0, 6.28); ctx.fill();
    ctx.fillStyle = belly; ctx.beginPath(); ctx.ellipse(cx, cy + 205, 58, 80, 0, 0, 6.28); ctx.fill();
    ctx.fillStyle = body;
    if (kind === "bonnie") { for (const s of [-1, 1]) { ctx.beginPath(); ctx.ellipse(cx + s * 30, cy - 90, 20, 60, s * 0.15, 0, 6.28); ctx.fill(); } }
    if (kind === "freddy") { for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(cx + s * 58, cy - 48, 24, 0, 6.28); ctx.fill(); } }
    ctx.beginPath(); ctx.ellipse(cx, cy, 72, 66, 0, 0, 6.28); ctx.fill();
    ctx.fillStyle = belly; ctx.beginPath(); ctx.ellipse(cx, cy + 30, 46, 28, 0, 0, 6.28); ctx.fill();
    if (kind === "chica") { ctx.fillStyle = "#e7801e"; ctx.beginPath(); ctx.moveTo(cx - 30, cy + 14); ctx.lineTo(cx + 30, cy + 14); ctx.lineTo(cx, cy + 50); ctx.fill(); ctx.fillStyle = "#f3eee2"; ctx.fillRect(cx - 55, cy + 140, 110, 80); ctx.fillStyle = "#8b3fbf"; ctx.font = "900 26px Arial Black"; ctx.textAlign = "center"; ctx.fillText("LET'S", cx, cy + 172); ctx.fillText("EAT!!", cx, cy + 204); }
    for (const s of [-1, 1]) { ctx.fillStyle = "#f7f3ea"; ctx.beginPath(); ctx.ellipse(cx + s * 24, cy - 12, 16, 19, 0, 0, 6.28); ctx.fill(); ctx.fillStyle = eye; ctx.beginPath(); ctx.arc(cx + s * 24, cy - 9, 8, 0, 6.28); ctx.fill(); ctx.fillStyle = "#111"; ctx.beginPath(); ctx.arc(cx + s * 24, cy - 9, 4, 0, 6.28); ctx.fill(); }
    ctx.fillStyle = "#1a1210"; if (kind !== "chica") { ctx.beginPath(); ctx.ellipse(cx, cy + 16, 10, 7, 0, 0, 6.28); ctx.fill(); }
    ctx.fillStyle = "#f7f3ea"; if (kind !== "chica") for (let k = -2; k <= 2; k++) ctx.fillRect(cx + k * 11 - 4, cy + 42, 8, 10);
    if (kind === "freddy") { ctx.fillStyle = "#111"; ctx.fillRect(cx - 22, cy - 110, 44, 46); ctx.fillRect(cx - 34, cy - 68, 68, 8); ctx.beginPath(); ctx.moveTo(cx - 28, cy + 76); ctx.lineTo(cx, cy + 88); ctx.lineTo(cx - 28, cy + 100); ctx.moveTo(cx + 28, cy + 76); ctx.lineTo(cx, cy + 88); ctx.lineTo(cx + 28, cy + 100); ctx.fill(); }
    if (kind === "bonnie") { ctx.fillStyle = "#c0302a"; ctx.beginPath(); ctx.moveTo(cx - 26, cy + 76); ctx.lineTo(cx, cy + 88); ctx.lineTo(cx - 26, cy + 100); ctx.moveTo(cx + 26, cy + 76); ctx.lineTo(cx, cy + 88); ctx.lineTo(cx + 26, cy + 100); ctx.fill(); ctx.fillStyle = "#c93428"; ctx.beginPath(); ctx.moveTo(cx - 60, cy + 150); ctx.lineTo(cx - 150, cy + 300); ctx.lineTo(cx - 110, cy + 300); ctx.lineTo(cx - 60, cy + 220); ctx.fill(); }
  };
  face(100, 250, "#7a4fa0", "#b9b0d0", "#d8375f", "bonnie");
  face(412, 250, "#d9b52e", "#ece090", "#7a45b8", "chica");
  face(256, 230, "#7a4a26", "#c79a6a", "#2c55b8", "freddy");
  ctx.fillStyle = "#f7f0dc"; ctx.strokeStyle = "#5a2a78"; ctx.lineWidth = 10; ctx.font = "900 92px Impact, Arial Black"; ctx.textAlign = "center"; ctx.strokeText("CELEBRATE!", 256, 660); ctx.fillText("CELEBRATE!", 256, 660);
  // age/wear
  const id = ctx.getImageData(0, 0, 512, 720); for (let y = 0; y < 720; y++) for (let x = 0; x < 512; x++) { const i = (y * 512 + x) * 4; const n = fbm(x / 512 * 6, y / 512 * 6, 6, 9, 4, 3); const k = 0.65 + n * 0.45; id.data[i] *= k; id.data[i + 1] *= k * 0.96; id.data[i + 2] *= k * 0.85; } ctx.putImageData(id, 0, 0);
  const t = tex(cv); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
function drawing(seed) {
  const cv = document.createElement("canvas"); cv.width = 256; cv.height = 320; const ctx = cv.getContext("2d"); const R = rng(seed);
  ctx.fillStyle = "#efe9dc"; ctx.fillRect(0, 0, 256, 320); ctx.lineWidth = 5; ctx.lineCap = "round";
  const cols = ["#d1403a", "#3a6fd1", "#e0a81c", "#8a45c0", "#2e9a4a", "#1a1a1a"];
  const scrib = (fn) => { ctx.strokeStyle = cols[(R() * cols.length) | 0]; ctx.beginPath(); fn(); ctx.stroke(); };
  const cx = 128, cy = 150;
  scrib(() => ctx.arc(cx, cy, 44 + R() * 10, 0, 6.28)); scrib(() => { ctx.arc(cx - 16, cy - 8, 7, 0, 6.28); }); scrib(() => { ctx.arc(cx + 16, cy - 8, 7, 0, 6.28); });
  scrib(() => { ctx.moveTo(cx - 22, cy + 18); ctx.quadraticCurveTo(cx, cy + 34, cx + 22, cy + 18); });
  scrib(() => { ctx.moveTo(cx, cy + 50); ctx.lineTo(cx, cy + 130); ctx.moveTo(cx - 40, cy + 80); ctx.lineTo(cx + 40, cy + 80); ctx.moveTo(cx, cy + 130); ctx.lineTo(cx - 30, cy + 165); ctx.moveTo(cx, cy + 130); ctx.lineTo(cx + 30, cy + 165); });
  if (R() > 0.4) scrib(() => { ctx.arc(cx - 36, cy - 44, 14, 0, 6.28); ctx.moveTo(cx + 50, cy - 44); ctx.arc(cx + 36, cy - 44, 14, 0, 6.28); });
  ctx.fillStyle = cols[(R() * 4) | 0]; ctx.font = "bold 40px Comic Sans MS, cursive"; ctx.textAlign = "center"; ctx.fillText(["MY DAY!!", "ME!", "FREDDY", "HAPPY BDAY"][(R() * 4) | 0], 128, 50);
  ctx.fillStyle = "#e0a81c"; ctx.beginPath(); ctx.arc(220, 290, 22, 0, 6.28); ctx.fill();
  return tex(cv);
}
function signTex(lines, bg, fg, w = 512, h = 256) {
  const cv = document.createElement("canvas"); cv.width = w; cv.height = h; const ctx = cv.getContext("2d");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h); ctx.fillStyle = fg; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  lines.forEach(([t, size, y, font]) => { ctx.font = `${font || "900"} ${size}px Impact, Arial Black, sans-serif`; ctx.fillText(t, w / 2, y); });
  const id = ctx.getImageData(0, 0, w, h); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = (y * w + x) * 4; const k = 0.7 + fbm(x / w * 5, y / w * 5, 5, 5, 3, 2) * 0.4; id.data[i] *= k; id.data[i + 1] *= k; id.data[i + 2] *= k; } ctx.putImageData(id, 0, 0);
  const t = tex(cv); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
function curtainTex() {
  const W = 256, H = 512, tb = new TB(W, H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const n = fbm(x / W * 4, y / H * 8, 4, 8, 4, 6); const v = 0.8 + n * 0.3; tb.px(y * W + x, 0.2 * v, 0.07 * v, 0.28 * v, n, 0.9); }
  const cv = tb.canvas(); const ctx = cv.getContext("2d"); const R = rng(4);
  const star = (x, y, s) => { ctx.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? s * 0.42 : s; ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } ctx.closePath(); ctx.fill(); };
  ctx.fillStyle = "#d6b04a"; for (let i = 0; i < 26; i++) { const x = R() * W, y = R() * H, s = 6 + R() * 10; star(x, y, s); star(x - W, y, s); star(x + W, y, s); }
  return { map: tex(cv), normalMap: tex(tb.normal(1), false) };
}
function arcadeScreen(seed) {
  const cv = document.createElement("canvas"); cv.width = 128; cv.height = 128; const ctx = cv.getContext("2d"); const R = rng(seed);
  ctx.fillStyle = "#050510"; ctx.fillRect(0, 0, 128, 128);
  const pal = ["#ff4d6d", "#ffd23f", "#3ee6c1", "#6c8cff", "#ff9f1c", "#f4f4f4"];
  for (let i = 0; i < 40; i++) { ctx.fillStyle = pal[(R() * pal.length) | 0]; const x = (R() * 16 | 0) * 8, y = (R() * 16 | 0) * 8; ctx.fillRect(x, y, 6, 6); }
  ctx.fillStyle = "#ffd23f"; ctx.beginPath(); ctx.arc(64, 70, 16, 0.6, 5.7); ctx.lineTo(64, 70); ctx.fill();
  ctx.fillStyle = "#f4f4f4"; ctx.font = "bold 14px monospace"; ctx.fillText("1UP 00" + ((R() * 9000 + 1000) | 0), 8, 16);
  for (let y = 0; y < 128; y += 2) { ctx.fillStyle = "rgba(0,0,0,0.35)"; ctx.fillRect(0, y, 128, 1); }
  return tex(cv);
}
export function staticTex() {
  const cv = document.createElement("canvas"); cv.width = 128; cv.height = 128; const ctx = cv.getContext("2d"); const id = ctx.createImageData(128, 128);
  for (let i = 0; i < 128 * 128; i++) { const v = Math.random() * 255 * (0.5 + 0.5 * Math.sin(i / 128 * 0.9)); id.data[i * 4] = v * 0.8; id.data[i * 4 + 1] = v; id.data[i * 4 + 2] = v * 0.85; id.data[i * 4 + 3] = 255; }
  ctx.putImageData(id, 0, 0); return tex(cv);
}

export function buildTextures() {
  const T = {};
  T.checker = checkerFloor(); T.smalltile = smallTile(); T.concrete = concreteFloor(); T.wood = woodFloor();
  T.carpet = carpet({ base: [0.06, 0.05, 0.11], acc: ["#2aa198", "#c2417a", "#d8b43c", "#5a74c8"] }, 7);
  T.carpet2 = carpet({ base: [0.035, 0.035, 0.05], acc: ["#e0457b", "#3ee6c1", "#ffd23f", "#6c8cff", "#ff9f1c"] }, 13);
  T.ceiling = ceiling();
  T.wallMain = wallMain("main"); T.wallParty = wallMain("party"); T.wallTile = wallMain("tile"); T.wallBlock = wallMain("block");
  T.fur = fur(); T.metal = metal(); T.woodGrain = woodGrain(); T.cloth = cloth(); T.hazard = hazard();
  T.logo = logoTex(); T.bib = bibTex(); T.poster = bandPoster(); T.drawings = [1, 2, 3, 4, 5].map(drawing);
  T.curtain = curtainTex(); T.arcade = [1, 2, 3, 4, 5, 6].map(arcadeScreen); T.static = staticTex();
  T.signCove = signTex([["PIRATE COVE", 64, 70], ["SORRY!", 70, 150, "900"], ["OUT OF ORDER", 44, 210, "700"]], "#2a1030", "#e8d7a8");
  T.signCelebrate = signTex([["CELEBRATE!", 150, 128]], "#5a1d6e", "#f2d36b", 1024, 256);
  T.signOffice = signTex([["SECURITY", 90, 128]], "#1c1c1f", "#d8d2c4", 512, 256);
  T.signParts = signTex([["PARTS & SERVICE", 60, 90], ["EMPLOYEES ONLY", 40, 170, "700"]], "#262a26", "#d0c79c");
  T.signPrize = signTex([["PRIZE CORNER", 90, 128]], "#123a52", "#ffd66b", 1024, 256);
  T.shirtTex = shirtTex;
  return T;
}
